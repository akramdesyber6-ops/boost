import express from 'express';
import path from 'path';
import crypto from 'crypto';
import { createServer as createViteServer } from 'vite';
import {
  processMarzpayDeposit,
  verifyMarzpayTransactionStatus,
  getMarzpayCredentials,
  creditDepositIfExactMatch,
  parseMarzpayData,
} from './src/lib/marzpayGateway';
import {
  placeSmmOrder,
  checkSmmOrderStatus,
  getSmmCredentials,
} from './src/lib/smmGateway';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({
    verify: (req: any, res, buf) => {
      req.rawBody = buf;
    }
  }));

  // Health check
  app.get('/api/health', (req, res) => {
    const creds = getMarzpayCredentials();
    res.json({
      status: 'ok',
      service: 'VYRO Backend & Marzpay Gateway API',
      timestamp: new Date().toISOString(),
      marzpayConfigured: creds.isConfigured,
      gatewayBaseUrl: creds.baseUrl,
    });
  });

  // Marzpay Config endpoint for client gateway state
  app.get('/api/marzpay/config', (req, res) => {
    const creds = getMarzpayCredentials();
    res.json({
      status: 'ok',
      configured: creds.isConfigured,
      gateway: 'MarzPay Uganda (MTN MoMo & Airtel Money)',
      baseUrl: creds.baseUrl,
      keyHint: creds.apiKey ? `${creds.apiKey.slice(0, 4)}...${creds.apiKey.slice(-4)}` : null,
    });
  });

  /**
   * Marzpay Deposit Endpoint
   * Initiates Mobile Money (MTN / Airtel) or Card Deposit
   * Keeps MARZPAY_API_KEY & MARZPAY_API_SECRET secure on the server
   */
  app.post('/api/marzpay/deposit', async (req, res) => {
    try {
      const {
        amount,
        phone_number,
        phoneNumber,
        provider,
        user_id,
        userId,
        user_name,
        userName,
        email,
        reference,
        description,
        callback_url,
        callbackUrl,
      } = req.body || {};

      const targetPhone = phone_number || phoneNumber;
      const targetAmount = Number(amount);

      if (!targetAmount || targetAmount < 1000) {
        return res.status(400).json({
          success: false,
          error: 'Minimum deposit amount is UGX 1,000',
        });
      }

      if (!targetPhone || targetPhone.length < 9) {
        return res.status(400).json({
          success: false,
          error: 'A valid Ugandan phone number is required (MTN or Airtel).',
        });
      }

      const result = await processMarzpayDeposit({
        amount: targetAmount,
        phoneNumber: targetPhone,
        provider: provider || 'mtn_momo',
        userId: user_id || userId || 'usr_guest',
        userName: user_name || userName || 'VYRO User',
        email: email || 'user@vyro.app',
        reference,
        description,
        callbackUrl: callback_url || callbackUrl,
      });

      const statusCode = result.success ? 200 : result.mode === 'missing_keys' ? 401 : 400;
      return res.status(statusCode).json(result);
    } catch (err: any) {
      console.error('Marzpay deposit error:', err);
      res.status(500).json({
        success: false,
        error: err.message || 'Internal Server Error processing deposit',
      });
    }
  });

  /**
   * Marzpay Transaction Status Verification & Auto-Credit
   */
  app.get('/api/marzpay/verify/:reference', async (req, res) => {
    try {
      const { reference } = req.params;
      const expectedAmount = Number(req.query.expectedAmount || req.query.amount || 0);
      const userId = String(req.query.userId || '');
      const result = await verifyMarzpayTransactionStatus(reference, expectedAmount, userId);
      return res.json(result);
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  app.get('/api/marzpay/verify', async (req, res) => {
    try {
      const reference = String(req.query.reference || '');
      const expectedAmount = Number(req.query.expectedAmount || req.query.amount || 0);
      const userId = String(req.query.userId || '');
      const result = await verifyMarzpayTransactionStatus(reference, expectedAmount, userId);
      return res.json(result);
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  /**
   * Secure MarzPay Webhook Handler
   */
  app.post('/api/webhooks/marzpay', async (req: any, res) => {
    try {
      const payload = req.body || {};
      const creds = getMarzpayCredentials();
      const rawBody = req.rawBody ? req.rawBody.toString() : JSON.stringify(payload);

      // Verify HMAC SHA256 Signature or fallback to checking basic x-api-key header
      const signature = req.headers['x-signature'] || req.headers['x-webhook-signature'] || '';
      const apiKeyHeader = req.headers['x-api-key'] || '';
      
      let isVerified = false;
      if (signature) {
        const expectedSignatureHex = crypto.createHmac('sha256', creds.apiSecret).update(rawBody).digest('hex');
        const expectedSignatureB64 = crypto.createHmac('sha256', creds.apiSecret).update(rawBody).digest('base64');
        isVerified = signature === expectedSignatureHex || signature === expectedSignatureB64;
      } else if (apiKeyHeader === creds.apiKey) {
        isVerified = true;
      }
      
      if (!isVerified) {
        console.warn('[SECURITY] Invalid MarzPay webhook signature rejected.');
        return res.status(401).json({ success: false, error: 'Unauthorized: Invalid signature' });
      }

      console.log('[Express MarzPay Webhook Received]:', JSON.stringify(payload));
      const parsed = parseMarzpayData(payload);
      if (parsed.reference) {
        const creditResult = await creditDepositIfExactMatch({
          reference: parsed.reference,
          marzpayPayload: payload,
        });
        return res.json({
          received: true,
          status: 'acknowledged',
          credited: creditResult.credited,
          alreadyCredited: creditResult.alreadyCredited,
          timestamp: new Date().toISOString(),
        });
      }
      return res.json({ received: true, status: 'acknowledged' });
    } catch (err: any) {
      console.error('[Express MarzPay Webhook Error]:', err);
      res.json({ received: true, note: 'Error processed and acknowledged' });
    }
  });

  /**
   * SMM Panel Gateway (https://my.smm-panel.com)
   * Internal order execution - services are NOT exposed in user UI
   */
  app.post('/api/smm/order', async (req, res) => {
    try {
      const { platform, serviceType, link, quantity, campaignId, userId } = req.body || {};

      if (!platform || !serviceType || !link || !quantity) {
        return res.status(400).json({
          success: false,
          error: 'Missing required parameters (platform, serviceType, link, quantity)',
        });
      }

      const result = await placeSmmOrder({
        platform: String(platform),
        serviceType: String(serviceType),
        link: String(link).trim(),
        quantity: Number(quantity),
        campaignId,
        userId,
      });

      const statusCode = result.success ? 200 : 400;
      return res.status(statusCode).json(result);
    } catch (err: any) {
      console.error('SMM route error:', err);
      res.status(500).json({
        success: false,
        error: err.message || 'Internal Server Error placing SMM order',
      });
    }
  });

  app.get('/api/smm/status/:orderId', async (req, res) => {
    try {
      const { orderId } = req.params;
      const result = await checkSmmOrderStatus(orderId);
      return res.json(result);
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  app.get('/api/smm/status', async (req, res) => {
    try {
      const orderId = String(req.query.orderId || '');
      const result = await checkSmmOrderStatus(orderId);
      return res.json(result);
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  app.get('/api/smm/health', (req, res) => {
    const creds = getSmmCredentials();
    res.json({
      status: 'ok',
      gateway: 'my.smm-panel.com',
      apiUrl: creds.apiUrl,
      configured: creds.isConfigured,
      keyHint: creds.apiKey ? `${creds.apiKey.slice(0, 4)}...${creds.apiKey.slice(-4)}` : null,
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`VYRO Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
