import { recordPendingDeposit } from '../_lib/walletService';

function generateUUID(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

function isValidUUID(uuid: string): boolean {
  if (!uuid || typeof uuid !== 'string') return false;
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(uuid);
}

function normalizePhone(phone: string) {
  const digitsOnly = (phone || '').replace(/[^0-9]/g, '');
  let normalized = digitsOnly;
  if (digitsOnly.startsWith('256') && digitsOnly.length === 12) {
    normalized = digitsOnly;
  } else if (digitsOnly.startsWith('0') && digitsOnly.length === 10) {
    normalized = '256' + digitsOnly.slice(1);
  } else if (digitsOnly.length === 9) {
    normalized = '256' + digitsOnly;
  }
  return {
    e164: `+${normalized}`,
    national: normalized,
  };
}

export default async function handler(req: any, res: any) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status ? res.status(200).end() : res.writeHead(200).end();
  }

  const send = (code: number, data: any) => {
    if (typeof res.status === 'function') {
      return res.status(code).json(data);
    } else {
      res.writeHead(code, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify(data));
    }
  };

  if (req.method !== 'POST') {
    return send(405, { success: false, error: 'Method Not Allowed. Use POST.' });
  }

  try {
    let body = req.body;
    if (typeof body === 'string') {
      try {
        body = JSON.parse(body);
      } catch {
        body = {};
      }
    }

    const { amount, phoneNumber, phone_number, provider, reference, description, userId, user_id, userName, user_name } = body || {};
    const rawPhone = phoneNumber || phone_number || '';

    const intAmount = parseInt(String(amount || 0), 10);
    if (!intAmount || intAmount < 1000) {
      return send(400, { success: false, error: 'Minimum deposit amount is UGX 1,000' });
    }
    if (intAmount > 10000000) {
      return send(400, { success: false, error: 'Maximum deposit amount is UGX 10,000,000' });
    }

    if (!rawPhone || rawPhone.trim().length < 8) {
      return send(400, { success: false, error: 'A valid Ugandan mobile money phone number is required (e.g. 077... or +256...)' });
    }

    const phone = normalizePhone(rawPhone);
    // MarzPay strictly requires the transaction reference to be a valid UUID v4
    const validUuid = (reference && isValidUUID(reference)) ? reference : generateUUID();

    // Record pending deposit in Firebase RTDB
    await recordPendingDeposit({
      reference: validUuid,
      userId: userId || user_id || 'anonymous',
      userName: userName || user_name || 'VYRO Customer',
      expectedAmount: intAmount,
      phoneNumber: phone.e164,
      provider: provider || 'mtn_momo',
      status: 'pending',
      credited: false,
      createdAt: new Date().toISOString(),
    });

    const apiKey = (
      process.env.MARZPAY_API_KEY ||
      process.env.MARZPAY_KEY ||
      process.env.MARZ_API_KEY ||
      process.env.MARZPAY_PUBLIC_KEY ||
      process.env.VITE_MARZPAY_API_KEY ||
      ''
    ).trim();

    const apiSecret = (
      process.env.MARZPAY_API_SECRET ||
      process.env.MARZPAY_SECRET ||
      process.env.MARZ_API_SECRET ||
      process.env.MARZPAY_SECRET_KEY ||
      process.env.VITE_MARZPAY_API_SECRET ||
      ''
    ).trim();

    const baseUrl = (
      process.env.MARZPAY_BASE_URL ||
      'https://wallet.wearemarz.com/api/v1'
    ).trim().replace(/\/+$/, '');

    // Fallback sandbox simulation if keys are missing
    if (!apiKey || !apiSecret) {
      return send(200, {
        success: true,
        reference: validUuid,
        status: 'pending',
        mode: 'simulated_pending_keys',
        message: `[Sandbox] Mock USSD Prompt sent to ${phone.e164}. Enter your Mobile Money PIN on your phone to complete payment.`,
        data: {
          note: 'MARZPAY_API_KEY and MARZPAY_API_SECRET not set in environment.',
          amount: intAmount,
          phone: phone.e164,
          provider: provider || 'mtn_momo',
        },
      });
    }

    // Official MarzPay Collect Money Payload
    // MarzPay expects: amount (int), phone_number (+256...), reference (UUID4), country (UG), description
    const callbackUrl = `${process.env.APP_URL || 'https://vyroboost.vercel.app'}/api/webhooks/marzpay`;
    const requestBody: any = {
      amount: intAmount,
      phone_number: phone.e164,
      reference: validUuid,
      country: 'UG',
      description: description || `Deposit UGX ${intAmount.toLocaleString()} to VYRO Wallet`,
    };
    if (callbackUrl) {
      requestBody.callback_url = callbackUrl;
    }

    const authHeader = `Basic ${typeof btoa === 'function' ? btoa(`${apiKey}:${apiSecret}`) : Buffer.from(`${apiKey}:${apiSecret}`).toString('base64')}`;
    const headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      'Authorization': authHeader,
    };

    let response = await fetch(`${baseUrl}/collect-money`, {
      method: 'POST',
      headers,
      body: JSON.stringify(requestBody),
    });

    if (response.status === 404) {
      response = await fetch(`${baseUrl}/collections`, {
        method: 'POST',
        headers,
        body: JSON.stringify(requestBody),
      });
    }

    const rawText = await response.text();
    let data: any = {};
    try {
      data = JSON.parse(rawText);
    } catch {
      data = { rawResponse: rawText };
    }

    if (response.ok) {
      const returnedRef = data.reference || data.uuid || data.tx_ref || data.data?.reference || data.data?.uuid || validUuid;
      const isFailed = data.status === 'failed' || data.success === false;

      return send(200, {
        success: !isFailed,
        reference: returnedRef,
        status: isFailed ? 'failed' : 'pending',
        message: data.message || `USSD prompt dispatched to ${phone.e164}. Enter your Mobile Money PIN on your phone to complete payment.`,
        checkoutUrl: data.checkout_url || data.payment_url || data.link || data.checkoutUrl,
        mode: 'live',
        data,
      });
    } else {
      const detailedErrors = data.errors
        ? Object.entries(data.errors)
            .map(([_, msgs]: [string, any]) => (Array.isArray(msgs) ? msgs.join(', ') : String(msgs)))
            .join('; ')
        : '';
      const errorMsg = detailedErrors || data.message || data.error || data.detail || `MarzPay returned error code ${response.status}`;
      return send(400, {
        success: false,
        reference: validUuid,
        status: 'failed',
        mode: 'live',
        message: errorMsg,
        error: errorMsg,
        data,
      });
    }
  } catch (err: any) {
    return send(500, {
      success: false,
      error: err?.message || 'Failed to process MarzPay deposit',
    });
  }
}
