export default async function handler(req: any, res: any) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status ? res.status(200).end() : res.writeHead(200).end();
  }

  const send = (code: number, data: any) => {
    if (typeof res.status === 'function') {
      return res.status(code).json(data);
    } else {
      res.writeHead(code, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify(data));
    }
  };

  try {
    const apiKey = (
      process.env.MARZPAY_API_KEY ||
      process.env.MARZPAY_KEY ||
      process.env.MARZ_API_KEY ||
      process.env.MARZPAY_PUBLIC_KEY ||
      process.env.VITE_MARZPAY_API_KEY ||
      ''
    ).trim();

    const apiSecret = (
      process.env.MARZPAY_API_SECRET ||
      process.env.MARZPAY_SECRET ||
      process.env.MARZ_API_SECRET ||
      process.env.MARZPAY_SECRET_KEY ||
      process.env.VITE_MARZPAY_API_SECRET ||
      ''
    ).trim();

    const baseUrl = (
      process.env.MARZPAY_BASE_URL ||
      'https://wallet.wearemarz.com/api/v1'
    ).trim().replace(/\/+$/, '');

    return send(200, {
      status: 'ok',
      configured: Boolean(apiKey && apiSecret),
      gateway: 'MarzPay Uganda (MTN MoMo & Airtel Money)',
      baseUrl,
      keyHint: apiKey ? `${apiKey.slice(0, 4)}...${apiKey.slice(-4)}` : null,
    });
  } catch (err: any) {
    return send(500, { status: 'error', error: err?.message || 'Error checking MarzPay config' });
  }
}
