import { creditDepositIfExactMatch, getDepositRecord } from '../_lib/walletService';

export default async function handler(req: any, res: any) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status ? res.status(200).end() : res.writeHead(200).end();
  }

  const send = (code: number, data: any) => {
    if (typeof res.status === 'function') {
      return res.status(code).json(data);
    } else {
      res.writeHead(code, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify(data));
    }
  };

  try {
    const reference = (
      req.query?.reference ||
      req.url?.split('reference=')[1]?.split('&')[0] ||
      ''
    ).trim();

    const expectedAmount = Number(
      req.query?.expectedAmount ||
      req.query?.amount ||
      req.url?.split('expectedAmount=')[1]?.split('&')[0] ||
      0
    );

    const userId = (
      req.query?.userId ||
      req.url?.split('userId=')[1]?.split('&')[0] ||
      ''
    ).trim();

    if (!reference || reference === 'verify') {
      return send(400, { success: false, error: 'Transaction reference is required' });
    }

    // 1. Fast path: check if this transaction was already credited in Firebase RTDB
    const depositRecord = await getDepositRecord(reference);
    if (depositRecord && depositRecord.credited) {
      return send(200, {
        success: true,
        reference,
        status: 'completed',
        credited: true,
        alreadyCredited: true,
        verifiedAmount: depositRecord.creditedAmount || depositRecord.expectedAmount,
        message: 'Deposit verified and credited to your wallet.',
        data: depositRecord,
      });
    }

    const apiKey = (
      process.env.MARZPAY_API_KEY ||
      process.env.MARZPAY_KEY ||
      process.env.MARZ_API_KEY ||
      process.env.MARZPAY_PUBLIC_KEY ||
      process.env.VITE_MARZPAY_API_KEY ||
      ''
    ).trim();

    const apiSecret = (
      process.env.MARZPAY_API_SECRET ||
      process.env.MARZPAY_SECRET ||
      process.env.MARZ_API_SECRET ||
      process.env.MARZPAY_SECRET_KEY ||
      process.env.VITE_MARZPAY_API_SECRET ||
      ''
    ).trim();

    const baseUrl = (
      process.env.MARZPAY_BASE_URL ||
      'https://wallet.wearemarz.com/api/v1'
    ).trim().replace(/\/+$/, '');

    if (!apiKey || !apiSecret) {
      return send(200, {
        success: true,
        reference,
        status: 'pending',
        credited: false,
        message: 'Transaction is awaiting Mobile Money PIN confirmation on phone.',
      });
    }

    const authHeader = `Basic ${typeof btoa === 'function' ? btoa(`${apiKey}:${apiSecret}`) : Buffer.from(`${apiKey}:${apiSecret}`).toString('base64')}`;
    const headers = {
      'Accept': 'application/json',
      'Authorization': authHeader,
      'x-api-key': apiKey,
      'x-api-secret': apiSecret,
    };

    const verifyEndpoints = [
      `${baseUrl}/collect-money/${reference}`,
      `${baseUrl}/transactions/${reference}`,
      `${baseUrl}/collections/${reference}/status`,
      `${baseUrl}/collections/${reference}`,
    ];

    for (const endpoint of verifyEndpoints) {
      try {
        const response = await fetch(endpoint, { headers });
        if (response.ok) {
          const data = await response.json();

          // Credit wallet strictly and idempotently if exact amount was received by MarzPay
          const creditResult = await creditDepositIfExactMatch({
            reference,
            expectedAmount: expectedAmount || depositRecord?.expectedAmount,
            userId: userId || depositRecord?.userId,
            marzpayPayload: data,
          });

          return send(200, {
            success: creditResult.success,
            reference: data.reference || data.data?.reference || reference,
            status: creditResult.status,
            credited: creditResult.credited,
            alreadyCredited: creditResult.alreadyCredited,
            verifiedAmount: creditResult.verifiedAmount,
            expectedAmount: creditResult.expectedAmount,
            receivedAmount: creditResult.receivedAmount,
            newBalance: creditResult.newBalance,
            message: creditResult.message || data.message || `Transaction status: ${creditResult.status}`,
            data,
          });
        }
      } catch {
        // try next endpoint
      }
    }

    return send(200, {
      success: true,
      reference,
      status: 'pending',
      credited: false,
      message: 'Transaction is awaiting Mobile Money PIN confirmation on phone.',
    });
  } catch (err: any) {
    return send(500, { success: false, error: err?.message || 'Error checking verification status' });
  }
}
