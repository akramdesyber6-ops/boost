interface SmmService {
  service: string | number;
  name: string;
  type?: string;
  category?: string;
  rate?: string | number;
  min?: string | number;
  max?: string | number;
  refill?: boolean;
}

const fallbackServices: SmmService[] = [
  { service: 101, name: 'TikTok Followers | Instant | Non-Drop [HQ]', category: 'TikTok Followers', rate: 1.1, min: 100, max: 250000, refill: true },
  { service: 102, name: 'TikTok Likes | High Quality Real Hearts [Fast]', category: 'TikTok Likes', rate: 0.5, min: 100, max: 500000, refill: true },
  { service: 103, name: 'TikTok Views | FYP High Retention Views', category: 'TikTok Views', rate: 0.25, min: 250, max: 1000000 },
  { service: 104, name: 'TikTok Custom Comments | Organic Positive', category: 'TikTok Comments', rate: 2.0, min: 20, max: 50000 },

  { service: 201, name: 'Instagram Followers | Real & Active [Refill 30D]', category: 'Instagram Followers', rate: 1.2, min: 100, max: 200000, refill: true },
  { service: 202, name: 'Instagram Likes | Real High Retention Hearts', category: 'Instagram Likes', rate: 0.6, min: 100, max: 300000, refill: true },
  { service: 203, name: 'Instagram Reels Views | Explore Algorithm Reach', category: 'Instagram Views', rate: 0.3, min: 250, max: 2000000 },

  { service: 301, name: 'YouTube Subscribers | Non-Drop Active Creators', category: 'YouTube Subscribers', rate: 2.8, min: 50, max: 100000, refill: true },
  { service: 302, name: 'YouTube Views | High Retention Recommended Views', category: 'YouTube Views', rate: 1.0, min: 500, max: 5000000 },
  { service: 303, name: 'YouTube Likes | Real Engagement', category: 'YouTube Likes', rate: 0.9, min: 100, max: 250000 },

  { service: 401, name: 'Facebook Page Likes & Followers | High Quality', category: 'Facebook Followers', rate: 1.5, min: 100, max: 200000, refill: true },
  { service: 402, name: 'Facebook Post Likes & Reactions', category: 'Facebook Likes', rate: 0.8, min: 100, max: 100000 },

  { service: 501, name: 'X / Twitter Followers | Organic Appearance [HQ]', category: 'Twitter Followers', rate: 1.6, min: 100, max: 150000, refill: true },
  { service: 502, name: 'X / Twitter Likes & Retweets', category: 'Twitter Likes', rate: 0.9, min: 100, max: 100000 },

  { service: 601, name: 'Telegram Channel Members | Non-Drop Stable', category: 'Telegram Members', rate: 1.0, min: 100, max: 100000, refill: true },
  { service: 602, name: 'Telegram Post Views | Instant', category: 'Telegram Views', rate: 0.2, min: 200, max: 500000 },

  { service: 701, name: 'WhatsApp Channel Members | Active Real Contacts', category: 'WhatsApp Members', rate: 2.2, min: 100, max: 50000, refill: true },
];

function selectBestService(services: SmmService[], platform: string, serviceType: string, qty: number): SmmService | null {
  const platLower = (platform || '').toLowerCase();
  const typeLower = (serviceType || '').toLowerCase();

  const platKeys: Record<string, string[]> = {
    tiktok: ['tiktok', 'tik tok', 'tt'],
    instagram: ['instagram', 'ig', 'insta'],
    youtube: ['youtube', 'yt', 'you tube'],
    facebook: ['facebook', 'fb'],
    x: ['twitter', ' x ', 'x [', 'x -', 'tweet'],
    telegram: ['telegram', 'tg'],
    whatsapp: ['whatsapp', 'wa '],
  };

  const typeKeys: Record<string, string[]> = {
    followers: ['follower', 'subscriber', 'sub', 'member'],
    likes: ['like', 'heart', 'reaction'],
    views: ['view', 'impression', 'reach', 'watch'],
    comments: ['comment', 'review'],
    shares: ['share', 'retweet', 'repost'],
    subscribers: ['subscriber', 'follower'],
    members: ['member', 'subscriber', 'join'],
  };

  const pFilters = platKeys[platLower] || [platLower];
  const tFilters = typeKeys[typeLower] || [typeLower];

  const matched = services.filter((s) => {
    const combined = `${s.name || ''} ${s.category || ''}`.toLowerCase();
    return pFilters.some((k) => combined.includes(k)) && tFilters.some((k) => combined.includes(k));
  });

  if (matched.length === 0) {
    const fallbackP = services.filter((s) => {
      const combined = `${s.name || ''} ${s.category || ''}`.toLowerCase();
      return pFilters.some((k) => combined.includes(k));
    });
    return fallbackP[0] || services[0] || null;
  }

  // Score candidate quality
  matched.sort((a, b) => {
    let scoreA = 0;
    let scoreB = 0;
    const nameA = (a.name || '').toLowerCase();
    const nameB = (b.name || '').toLowerCase();

    if (nameA.includes('real')) scoreA += 30;
    if (nameB.includes('real')) scoreB += 30;
    if (nameA.includes('non-drop') || nameA.includes('refill')) scoreA += 35;
    if (nameB.includes('non-drop') || nameB.includes('refill')) scoreB += 35;
    if (nameA.includes('hq') || nameA.includes('high quality')) scoreA += 20;
    if (nameB.includes('hq') || nameB.includes('high quality')) scoreB += 20;
    if (a.refill) scoreA += 20;
    if (b.refill) scoreB += 20;

    return scoreB - scoreA;
  });

  return matched[0];
}

export default async function handler(req: any, res: any) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status ? res.status(200).end() : res.writeHead(200).end();
  }

  const send = (code: number, data: any) => {
    if (typeof res.status === 'function') {
      return res.status(code).json(data);
    } else {
      res.writeHead(code, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify(data));
    }
  };

  if (req.method !== 'POST') {
    return send(405, { success: false, error: 'Method Not Allowed. Use POST.' });
  }

  try {
    let body = req.body;
    if (typeof body === 'string') {
      try {
        body = JSON.parse(body);
      } catch {
        body = {};
      }
    }

    const { platform, serviceType, link, quantity, campaignId, userId } = body || {};

    if (!platform || !serviceType) {
      return send(400, { success: false, error: 'Missing required platform or serviceType' });
    }

    if (!link || String(link).trim().length < 4) {
      return send(400, { success: false, error: 'A valid target profile/content URL is required' });
    }

    const targetQty = Number(quantity);
    if (!targetQty || targetQty < 10) {
      return send(400, { success: false, error: 'Quantity must be at least 10 units' });
    }

    const apiKey = (
      process.env.SMM_PANEL_API_KEY ||
      process.env.SMM_API_KEY ||
      process.env.MY_SMM_PANEL_KEY ||
      process.env.SMM_KEY ||
      process.env.VITE_SMM_PANEL_API_KEY ||
      ''
    ).trim();

    const apiUrl = (
      process.env.SMM_PANEL_API_URL ||
      process.env.SMM_API_URL ||
      'https://my.smm-panel.com/api/v2'
    ).trim().replace(/\/+$/, '');

    // Select optimal service
    let catalog = fallbackServices;
    if (apiKey) {
      try {
        const p = new URLSearchParams();
        p.append('key', apiKey);
        p.append('action', 'services');
        const sRes = await fetch(apiUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: p.toString(),
        });
        if (sRes.ok) {
          const list = await sRes.json();
          if (Array.isArray(list) && list.length > 0) {
            catalog = list;
          }
        }
      } catch (e) {
        // use fallback catalog
      }
    }

    const best = selectBestService(catalog, String(platform), String(serviceType), targetQty);
    const serviceId = best ? best.service : '101';
    const serviceName = best ? best.name : `${platform} ${serviceType} HQ`;

    // Simulated pending key if no api key configured
    if (!apiKey) {
      const simulatedOrderId = `SMM-${Date.now().toString().slice(-6)}`;
      return send(200, {
        success: true,
        orderId: simulatedOrderId,
        serviceIdUsed: serviceId,
        serviceNameUsed: serviceName,
        mode: 'simulated_pending_key',
        data: {
          note: 'SMM_PANEL_API_KEY pending in environment. Order queued locally with target service.',
          serviceId,
          serviceName,
        },
      });
    }

    // Live order dispatch
    const postBody = new URLSearchParams();
    postBody.append('key', apiKey);
    postBody.append('action', 'add');
    postBody.append('service', String(serviceId));
    postBody.append('link', String(link).trim());
    postBody.append('quantity', String(targetQty));

    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json',
      },
      body: postBody.toString(),
    });

    const data = await response.json().catch(() => ({}));

    if (response.ok && data.order) {
      return send(200, {
        success: true,
        orderId: data.order,
        serviceIdUsed: serviceId,
        serviceNameUsed: serviceName,
        mode: 'live',
        data,
      });
    } else {
      const errorMsg = data.error || `SMM Panel HTTP ${response.status}`;
      return send(400, {
        success: false,
        error: errorMsg,
        serviceIdUsed: serviceId,
        serviceNameUsed: serviceName,
        mode: 'live',
        data,
      });
    }
  } catch (err: any) {
    return send(500, {
      success: false,
      error: err?.message || 'Internal Server Error placing SMM order',
    });
  }
}
