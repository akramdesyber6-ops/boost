export default async function handler(req: any, res: any) {
  try {
    const apiKey = (
      process.env.SMM_PANEL_API_KEY ||
      process.env.SMM_API_KEY ||
      process.env.MY_SMM_PANEL_KEY ||
      process.env.SMM_KEY ||
      process.env.VITE_SMM_PANEL_API_KEY ||
      ''
    ).trim();

    const apiUrl = (
      process.env.SMM_PANEL_API_URL ||
      process.env.SMM_API_URL ||
      'https://my.smm-panel.com/api/v2'
    ).trim().replace(/\/+$/, '');

    const isConfigured = Boolean(apiKey);

    const payload = {
      status: 'ok',
      gateway: 'my.smm-panel.com',
      apiUrl,
      configured: isConfigured,
      keyHint: apiKey ? `${apiKey.slice(0, 4)}...${apiKey.slice(-4)}` : null,
      timestamp: new Date().toISOString(),
    };

    if (typeof res.status === 'function') {
      return res.status(200).json(payload);
    } else {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify(payload));
    }
  } catch (err: any) {
    const errPayload = { status: 'error', error: err?.message || 'Unknown error' };
    if (typeof res.status === 'function') {
      return res.status(500).json(errPayload);
    } else {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify(errPayload));
    }
  }
}
