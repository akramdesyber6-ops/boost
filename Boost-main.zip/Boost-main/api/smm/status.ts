export default async function handler(req: any, res: any) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status ? res.status(200).end() : res.writeHead(200).end();
  }

  const send = (code: number, data: any) => {
    if (typeof res.status === 'function') {
      return res.status(code).json(data);
    } else {
      res.writeHead(code, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify(data));
    }
  };

  try {
    const orderId = req.query?.orderId || req.url?.split('orderId=')[1]?.split('&')[0];

    if (!orderId) {
      return send(400, { success: false, error: 'orderId parameter is required' });
    }

    const apiKey = (
      process.env.SMM_PANEL_API_KEY ||
      process.env.SMM_API_KEY ||
      process.env.MY_SMM_PANEL_KEY ||
      process.env.SMM_KEY ||
      process.env.VITE_SMM_PANEL_API_KEY ||
      ''
    ).trim();

    const apiUrl = (
      process.env.SMM_PANEL_API_URL ||
      process.env.SMM_API_URL ||
      'https://my.smm-panel.com/api/v2'
    ).trim().replace(/\/+$/, '');

    if (!apiKey || String(orderId).startsWith('SMM-')) {
      return send(200, {
        success: true,
        status: 'In progress',
        remains: 0,
        startCount: 0,
      });
    }

    const body = new URLSearchParams();
    body.append('key', apiKey);
    body.append('action', 'status');
    body.append('order', String(orderId));

    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json',
      },
      body: body.toString(),
    });

    if (response.ok) {
      const data = await response.json();
      return send(200, {
        success: !data.error,
        status: data.status || 'Pending',
        remains: data.remains,
        startCount: data.start_count,
        error: data.error,
        data,
      });
    }

    return send(200, { success: true, status: 'In progress' });
  } catch (err: any) {
    return send(500, {
      success: false,
      error: err?.message || 'Internal error checking SMM status',
    });
  }
}
