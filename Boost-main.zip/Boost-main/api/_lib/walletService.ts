const FIREBASE_RTDB_URL = 'https://schoolos-36793-default-rtdb.firebaseio.com';

export interface PendingDepositRecord {
  reference: string;
  userId: string;
  userName?: string;
  expectedAmount: number;
  phoneNumber: string;
  provider?: string;
  status: 'pending' | 'completed' | 'failed' | 'amount_mismatch';
  credited: boolean;
  receivedAmount?: number;
  creditedAmount?: number;
  creditedAt?: string;
  createdAt: string;
  updatedAt?: string;
}

/**
 * Record a pending deposit in Firebase Realtime Database
 */
export async function recordPendingDeposit(record: PendingDepositRecord): Promise<boolean> {
  try {
    const res = await fetch(`${FIREBASE_RTDB_URL}/vyro/deposits/${record.reference}.json`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(record),
    });
    return res.ok;
  } catch (err) {
    console.warn('Failed to record pending deposit in Firebase RTDB:', err);
    return false;
  }
}

/**
 * Fetch a deposit record by UUID reference
 */
export async function getDepositRecord(reference: string): Promise<PendingDepositRecord | null> {
  try {
    const res = await fetch(`${FIREBASE_RTDB_URL}/vyro/deposits/${reference}.json`);
    if (res.ok) {
      const data = await res.json();
      return data || null;
    }
  } catch (err) {
    console.warn('Failed to fetch deposit record from Firebase RTDB:', err);
  }
  return null;
}

/**
 * Extract status and exact amount from any MarzPay API/Webhook response format
 */
export function parseMarzpayData(payload: any): {
  reference: string | null;
  status: 'completed' | 'failed' | 'pending';
  receivedAmount: number | null;
  provider: string | null;
  phoneNumber: string | null;
} {
  if (!payload) {
    return { reference: null, status: 'pending', receivedAmount: null, provider: null, phoneNumber: null };
  }

  // 1. Reference extraction
  const reference =
    payload.reference ||
    payload.uuid ||
    payload.transaction?.reference ||
    payload.transaction?.uuid ||
    payload.data?.transaction?.reference ||
    payload.data?.transaction?.uuid ||
    payload.data?.reference ||
    payload.data?.uuid ||
    null;

  // 2. Status extraction
  const rawStatus = (
    payload.event_type?.split('.')[1] ||
    payload.transaction?.status ||
    payload.data?.transaction?.status ||
    payload.data?.status ||
    payload.status ||
    payload.transaction_status ||
    payload.payment_status ||
    payload.data?.payment_status ||
    ''
  ).toLowerCase();

  let status: 'completed' | 'failed' | 'pending' = 'pending';
  if (
    rawStatus === 'completed' ||
    rawStatus === 'successful' ||
    rawStatus === 'success' ||
    rawStatus === 'paid'
  ) {
    status = 'completed';
  } else if (
    rawStatus === 'failed' ||
    rawStatus === 'declined' ||
    rawStatus === 'rejected' ||
    rawStatus === 'cancelled' ||
    rawStatus === 'expired'
  ) {
    status = 'failed';
  }

  // 3. Amount extraction (handling objects { raw: 50000, formatted: "50,000" } or strings or numbers)
  const rawAmt =
    payload.transaction?.amount?.raw ??
    payload.transaction?.amount ??
    payload.collection?.amount?.raw ??
    payload.collection?.amount ??
    payload.data?.transaction?.amount?.raw ??
    payload.data?.transaction?.amount ??
    payload.data?.collection?.amount?.raw ??
    payload.data?.collection?.amount ??
    payload.data?.amount?.raw ??
    payload.data?.amount ??
    payload.amount?.raw ??
    payload.amount ??
    null;

  let receivedAmount: number | null = null;
  if (typeof rawAmt === 'number') {
    receivedAmount = rawAmt;
  } else if (typeof rawAmt === 'string') {
    const cleaned = parseFloat(rawAmt.replace(/[^0-9.]/g, ''));
    if (!isNaN(cleaned)) receivedAmount = cleaned;
  }

  // 4. Provider & Phone
  const provider =
    payload.transaction?.provider ||
    payload.collection?.provider ||
    payload.data?.transaction?.provider ||
    null;

  const phoneNumber =
    payload.transaction?.phone_number ||
    payload.collection?.phone_number ||
    payload.data?.transaction?.phone_number ||
    null;

  return { reference, status, receivedAmount, provider, phoneNumber };
}

/**
 * Safely and idempotently credit a user's wallet in Firebase RTDB
 * ONLY if:
 * 1. MarzPay has confirmed payment received (status: completed/successful)
 * 2. The amount received matches the EXACT expected deposit amount
 * 3. The transaction has not been previously credited (prevent double-credit)
 */
export async function creditDepositIfExactMatch(params: {
  reference: string;
  expectedAmount?: number;
  userId?: string;
  marzpayPayload: any;
}): Promise<{
  success: boolean;
  status: 'completed' | 'failed' | 'pending' | 'amount_mismatch';
  credited: boolean;
  alreadyCredited: boolean;
  verifiedAmount?: number;
  receivedAmount?: number;
  expectedAmount?: number;
  newBalance?: number;
  message: string;
  error?: string;
}> {
  const { reference, expectedAmount, userId, marzpayPayload } = params;

  if (!reference) {
    return {
      success: false,
      status: 'failed',
      credited: false,
      alreadyCredited: false,
      message: 'Transaction reference is missing.',
      error: 'MISSING_REFERENCE',
    };
  }

  // Parse MarzPay data
  const parsed = parseMarzpayData(marzpayPayload);

  // If MarzPay reports still pending or failed
  if (parsed.status !== 'completed') {
    return {
      success: true,
      status: parsed.status,
      credited: false,
      alreadyCredited: false,
      receivedAmount: parsed.receivedAmount || undefined,
      message: parsed.status === 'failed'
        ? 'Transaction was declined, expired, or cancelled.'
        : 'Transaction is awaiting Mobile Money PIN approval on customer phone.',
    };
  }

  // Retrieve stored deposit record from Firebase RTDB
  let depositRecord = await getDepositRecord(reference);

  // If not found in vyro/deposits, try looking in vyro/transactions by providerReference
  if (!depositRecord) {
    try {
      const txnsRes = await fetch(`${FIREBASE_RTDB_URL}/vyro/transactions.json`);
      if (txnsRes.ok) {
        const txns = await txnsRes.json();
        if (txns && typeof txns === 'object') {
          const match: any = Object.values(txns).find(
            (t: any) => t && t.providerReference === reference
          );
          if (match) {
            depositRecord = {
              reference,
              userId: match.userId || userId || '',
              userName: match.userName || '',
              expectedAmount: match.amountUGX || expectedAmount || 0,
              phoneNumber: match.phoneNumber || parsed.phoneNumber || '',
              provider: match.paymentProvider || parsed.provider || '',
              status: match.status === 'completed' ? 'completed' : 'pending',
              credited: match.status === 'completed',
              createdAt: match.createdAt || new Date().toISOString(),
            };
          }
        }
      }
    } catch (e) {
      console.warn('Error querying transactions:', e);
    }
  }

  // Check if ALREADY credited (Strict Idempotency to prevent double-crediting)
  if (depositRecord && depositRecord.credited) {
    return {
      success: true,
      status: 'completed',
      credited: true,
      alreadyCredited: true,
      verifiedAmount: depositRecord.creditedAmount || depositRecord.expectedAmount,
      message: 'Deposit already verified and credited to wallet.',
    };
  }

  // Determine expected amount to verify against
  const targetExpected = Math.round(
    depositRecord?.expectedAmount || Number(expectedAmount) || 0
  );
  const receivedAmt = parsed.receivedAmount !== null ? Math.round(parsed.receivedAmount) : null;

  // STRICT EXACT AMOUNT CHECK:
  // Must have deposited the exact amount and been received by MarzPay
  if (targetExpected > 0 && receivedAmt !== null) {
    if (receivedAmt !== targetExpected) {
      console.warn(
        `[SECURITY ALERT] MarzPay deposit amount mismatch! Ref: ${reference}. Expected: UGX ${targetExpected}, Received: UGX ${receivedAmt}`
      );

      // Record mismatch in deposit record
      if (depositRecord) {
        await fetch(`${FIREBASE_RTDB_URL}/vyro/deposits/${reference}.json`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            status: 'amount_mismatch',
            credited: false,
            receivedAmount: receivedAmt,
            expectedAmount: targetExpected,
            updatedAt: new Date().toISOString(),
          }),
        }).catch(() => {});
      }

      return {
        success: false,
        status: 'amount_mismatch',
        credited: false,
        alreadyCredited: false,
        expectedAmount: targetExpected,
        receivedAmount: receivedAmt,
        message: `Security Warning: Amount mismatch. Expected UGX ${targetExpected.toLocaleString()}, but MarzPay received UGX ${receivedAmt.toLocaleString()}. Wallet has not been credited.`,
        error: 'AMOUNT_MISMATCH',
      };
    }
  }

  const creditAmount = targetExpected > 0 ? targetExpected : (receivedAmt || 0);
  if (creditAmount <= 0) {
    return {
      success: false,
      status: 'failed',
      credited: false,
      alreadyCredited: false,
      message: 'Invalid deposit amount received (0 UGX).',
      error: 'INVALID_AMOUNT',
    };
  }

  const targetUserId = depositRecord?.userId || userId;
  if (!targetUserId) {
    return {
      success: false,
      status: 'failed',
      credited: false,
      alreadyCredited: false,
      message: 'Could not determine user account to credit.',
      error: 'MISSING_USER_ID',
    };
  }

  try {
    // 1. Fetch current user from Firebase RTDB
    const userRes = await fetch(`${FIREBASE_RTDB_URL}/vyro/users/${targetUserId}.json`);
    if (!userRes.ok) {
      throw new Error(`Failed to fetch user ${targetUserId} from Firebase`);
    }
    const userData = await userRes.json();
    if (!userData) {
      throw new Error(`User ${targetUserId} not found in database`);
    }

    const currentBalance = Number(userData.balanceUGX || 0);
    const newBalance = currentBalance + creditAmount;
    const nowIso = new Date().toISOString();

    // 2. Atomically update user balance
    await fetch(`${FIREBASE_RTDB_URL}/vyro/users/${targetUserId}.json`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        balanceUGX: newBalance,
        hasMadeFirstTransaction: true,
      }),
    });

    // --- REFERRAL BONUS LOGIC ---
    if (!userData.hasMadeFirstTransaction && userData.referredBy) {
      try {
        const referredByCode = userData.referredBy;
        const usersRes = await fetch(`${FIREBASE_RTDB_URL}/vyro/users.json`);
        if (usersRes.ok) {
          const allUsers = await usersRes.json();
          let referrerEntry: [string, any] | undefined;
          if (allUsers && typeof allUsers === 'object') {
            referrerEntry = Object.entries(allUsers).find(
              ([_, u]: [string, any]) => u && u.referralCode === referredByCode
            );
          }
          
          if (referrerEntry) {
            const [referrerId, referrerData] = referrerEntry;
            const bonusPercent = 0.10; // 10% bonus
            const bonusAmount = Math.round(creditAmount * bonusPercent);
            
            if (bonusAmount > 0) {
              const refNewBalance = Number(referrerData.balanceUGX || 0) + bonusAmount;
              const refNewEarnings = Number(referrerData.referralEarningsUGX || 0) + bonusAmount;
              
              // Update Referrer
              await fetch(`${FIREBASE_RTDB_URL}/vyro/users/${referrerId}.json`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  balanceUGX: refNewBalance,
                  referralEarningsUGX: refNewEarnings,
                }),
              });

              // Add Referral Transaction
              const refTxnId = `txn_ref_${Date.now()}`;
              await fetch(`${FIREBASE_RTDB_URL}/vyro/transactions/${refTxnId}.json`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  id: refTxnId,
                  userId: referrerId,
                  amountUGX: bonusAmount,
                  currency: 'UGX',
                  type: 'referral_bonus',
                  paymentProvider: 'wallet',
                  providerReference: refTxnId,
                  status: 'completed',
                  createdAt: nowIso,
                }),
              });

              // Notify Referrer
              const refNotifId = `notif_ref_${Date.now()}`;
              await fetch(`${FIREBASE_RTDB_URL}/vyro/notifications/${refNotifId}.json`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  id: refNotifId,
                  userId: referrerId,
                  title: 'Referral Bonus Earned! 💸',
                  message: `You earned UGX ${bonusAmount.toLocaleString()} because a creator you invited made their first deposit!`,
                  read: false,
                  type: 'success',
                  createdAt: nowIso,
                }),
              });
              
              console.log(`[REFERRAL CREDITED] User ${referrerId} earned UGX ${bonusAmount} from referral of ${targetUserId}`);
            }
          }
        }
      } catch (refErr) {
        console.warn('Notice: Failed to process referral bonus:', refErr);
      }
    }
    // --- END REFERRAL BONUS LOGIC ---

    // 3. Mark deposit record as credited
    await fetch(`${FIREBASE_RTDB_URL}/vyro/deposits/${reference}.json`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        status: 'completed',
        credited: true,
        creditedAmount: creditAmount,
        receivedAmount: creditAmount,
        creditedAt: nowIso,
        updatedAt: nowIso,
      }),
    });

    // 4. Update matching transaction in vyro/transactions
    try {
      const txnsRes = await fetch(`${FIREBASE_RTDB_URL}/vyro/transactions.json`);
      if (txnsRes.ok) {
        const txns = await txnsRes.json();
        if (txns && typeof txns === 'object') {
          for (const [txnKey, txn] of Object.entries<any>(txns)) {
            if (txn && txn.providerReference === reference) {
              await fetch(`${FIREBASE_RTDB_URL}/vyro/transactions/${txnKey}.json`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  status: 'completed',
                  creditedAt: nowIso,
                }),
              });
              break;
            }
          }
        }
      }
    } catch (txnErr) {
      console.warn('Notice: transaction status sync in RTDB:', txnErr);
    }

    // 5. Create notification in vyro/notifications
    try {
      const notifId = `notif_${Date.now()}`;
      await fetch(`${FIREBASE_RTDB_URL}/vyro/notifications/${notifId}.json`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: notifId,
          userId: targetUserId,
          title: 'Deposit Confirmed 🎉',
          message: `UGX ${creditAmount.toLocaleString()} received by MarzPay and added to your wallet. Ref: ${reference}`,
          read: false,
          type: 'success',
          createdAt: nowIso,
        }),
      });
    } catch {}

    console.log(
      `[WALLET CREDITED] Successfully credited UGX ${creditAmount} to user ${targetUserId} (${userData.fullName}). Ref: ${reference}. New balance: UGX ${newBalance}`
    );

    return {
      success: true,
      status: 'completed',
      credited: true,
      alreadyCredited: false,
      verifiedAmount: creditAmount,
      receivedAmount: creditAmount,
      expectedAmount: targetExpected,
      newBalance,
      message: `Deposit verified! UGX ${creditAmount.toLocaleString()} credited to your wallet automatically.`,
    };
  } catch (err: any) {
    console.error('Failed to credit user balance in Firebase RTDB:', err);
    return {
      success: false,
      status: 'failed',
      credited: false,
      alreadyCredited: false,
      message: 'Failed to credit wallet balance: ' + (err.message || 'Database write error'),
      error: err.message,
    };
  }
}
