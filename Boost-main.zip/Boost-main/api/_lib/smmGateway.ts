/**
 * SMM Panel Gateway Integration (https://my.smm-panel.com)
 * Uses standard SMM Panel API v2.
 * 
 * CRITICAL ARCHITECTURAL RULE (per User Request):
 * - Services are fetched server-side from https://my.smm-panel.com.
 * - Services MUST NEVER be listed, rendered, or exposed anywhere in the client UI.
 * - The backend dynamically selects the highest quality service for each platform & goal.
 * - The user experiences the same clean, simple creator order flow.
 */

export interface SmmService {
  service: string | number;
  name: string;
  type?: string;
  category?: string;
  rate?: string | number;
  min?: string | number;
  max?: string | number;
  refill?: boolean;
  cancel?: boolean;
}

export interface PlaceSmmOrderParams {
  platform: string;
  serviceType: string;
  link: string;
  quantity: number;
  campaignId?: string;
  userId?: string;
}

export interface SmmOrderResult {
  success: boolean;
  orderId?: string | number;
  serviceIdUsed?: string | number;
  serviceNameUsed?: string;
  error?: string;
  mode: 'live' | 'simulated_pending_key';
  data?: any;
}

// In-memory cache for fetched SMM services
let cachedServices: SmmService[] | null = null;
let lastFetchTime = 0;
const CACHE_TTL_MS = 15 * 60 * 1000; // 15 minutes

export function getSmmCredentials() {
  const apiKey = (
    process.env.SMM_PANEL_API_KEY ||
    process.env.SMM_API_KEY ||
    process.env.MY_SMM_PANEL_KEY ||
    process.env.SMM_KEY ||
    process.env.VITE_SMM_PANEL_API_KEY ||
    ''
  ).trim();

  const apiUrl = (
    process.env.SMM_PANEL_API_URL ||
    process.env.SMM_API_URL ||
    'https://my.smm-panel.com/api/v2'
  ).trim().replace(/\/+$/, '');

  return {
    apiKey,
    apiUrl,
    isConfigured: Boolean(apiKey),
  };
}

/**
 * Fetch services catalog from https://my.smm-panel.com/api/v2
 * Keeps catalog entirely on server-side.
 */
export async function fetchSmmServicesCatalog(forceRefresh = false): Promise<SmmService[]> {
  const now = Date.now();
  if (!forceRefresh && cachedServices && now - lastFetchTime < CACHE_TTL_MS) {
    return cachedServices;
  }

  const { apiKey, apiUrl, isConfigured } = getSmmCredentials();

  if (!isConfigured) {
    return getFallbackServicesList();
  }

  try {
    const params = new URLSearchParams();
    params.append('key', apiKey);
    params.append('action', 'services');

    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json',
      },
      body: params.toString(),
    });

    if (response.ok) {
      const data = await response.json();
      if (Array.isArray(data) && data.length > 0) {
        cachedServices = data;
        lastFetchTime = now;
        return data;
      }
    } else {
      console.warn(`SMM Panel responded with status ${response.status}`);
    }
  } catch (err) {
    console.error('Failed to fetch services from my.smm-panel.com:', err);
  }

  return cachedServices || getFallbackServicesList();
}

/**
 * Smart Service Selector:
 * Automatically selects the highest-performing, most reliable service
 * for a platform and goal, without exposing service catalogs to users.
 */
export function selectBestServiceForPlatform(
  services: SmmService[],
  platform: string,
  serviceType: string,
  targetQuantity = 1000
): SmmService | null {
  if (!services || services.length === 0) return null;

  const platLower = platform.toLowerCase();
  const typeLower = serviceType.toLowerCase();

  const platformKeywords: Record<string, string[]> = {
    tiktok: ['tiktok', 'tik tok', 'tt'],
    instagram: ['instagram', 'ig', 'insta'],
    youtube: ['youtube', 'yt', 'you tube'],
    facebook: ['facebook', 'fb'],
    x: ['twitter', ' x ', 'x [', 'x -', 'tweet'],
    telegram: ['telegram', 'tg'],
    whatsapp: ['whatsapp', 'wa '],
  };

  const typeKeywords: Record<string, string[]> = {
    followers: ['follower', 'subscriber', 'sub', 'member'],
    likes: ['like', 'heart', 'reaction'],
    views: ['view', 'impression', 'reach', 'watch'],
    comments: ['comment', 'review'],
    shares: ['share', 'retweet', 'repost'],
    subscribers: ['subscriber', 'follower'],
    members: ['member', 'subscriber', 'join'],
  };

  const platKeys = platformKeywords[platLower] || [platLower];
  const typeKeys = typeKeywords[typeLower] || [typeLower];

  const candidates: { service: SmmService; score: number }[] = [];

  for (const s of services) {
    const nameLower = (s.name || '').toLowerCase();
    const catLower = (s.category || '').toLowerCase();
    const combined = `${nameLower} ${catLower}`;

    const matchesPlatform = platKeys.some((k) => combined.includes(k));
    if (!matchesPlatform) continue;

    const matchesType = typeKeys.some((k) => combined.includes(k));
    if (!matchesType) continue;

    if (combined.includes('bot') || combined.includes('drop guaranteed') || combined.includes('slow')) {
      continue;
    }

    let score = 50;

    if (combined.includes('real') || combined.includes('active')) score += 30;
    if (combined.includes('high quality') || combined.includes('hq')) score += 25;
    if (combined.includes('instant') || combined.includes('fast')) score += 25;
    if (combined.includes('refill') || combined.includes('guaranteed') || combined.includes('non-drop')) score += 35;
    if (combined.includes('stable')) score += 15;
    if (s.refill) score += 20;

    const min = typeof s.min === 'string' ? parseInt(s.min, 10) : s.min || 0;
    const max = typeof s.max === 'string' ? parseInt(s.max, 10) : s.max || 1000000;
    if (min <= targetQuantity && max >= targetQuantity) {
      score += 20;
    }

    const rate = typeof s.rate === 'string' ? parseFloat(s.rate) : s.rate || 0;
    if (rate > 0 && rate < 10) {
      score += 10;
    }

    candidates.push({ service: s, score });
  }

  if (candidates.length === 0) {
    const platformOnly = services.filter((s) => {
      const combined = `${s.name || ''} ${s.category || ''}`.toLowerCase();
      return platKeys.some((k) => combined.includes(k));
    });
    return platformOnly[0] || services[0] || null;
  }

  candidates.sort((a, b) => b.score - a.score);
  return candidates[0].service;
}

/**
 * Place Order to https://my.smm-panel.com
 * Automatically selects best service ID, executes order, and returns reference.
 */
export async function placeSmmOrder(params: PlaceSmmOrderParams): Promise<SmmOrderResult> {
  const { apiKey, apiUrl, isConfigured } = getSmmCredentials();

  const catalog = await fetchSmmServicesCatalog();

  const bestService = selectBestServiceForPlatform(
    catalog,
    params.platform,
    params.serviceType,
    params.quantity
  );

  const serviceId = bestService ? bestService.service : '101';
  const serviceName = bestService ? bestService.name : `${params.platform} ${params.serviceType} HQ`;

  if (!isConfigured) {
    const simulatedOrderId = `SMM-${Date.now().toString().slice(-6)}`;
    return {
      success: true,
      orderId: simulatedOrderId,
      serviceIdUsed: serviceId,
      serviceNameUsed: serviceName,
      mode: 'simulated_pending_key',
      data: {
        note: 'SMM_PANEL_API_KEY pending in environment. Order queued locally with target service.',
        serviceId,
        serviceName,
      },
    };
  }

  try {
    const body = new URLSearchParams();
    body.append('key', apiKey);
    body.append('action', 'add');
    body.append('service', String(serviceId));
    body.append('link', params.link);
    body.append('quantity', String(params.quantity));

    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json',
      },
      body: body.toString(),
    });

    const data = await response.json().catch(() => ({}));

    if (response.ok && data.order) {
      return {
        success: true,
        orderId: data.order,
        serviceIdUsed: serviceId,
        serviceNameUsed: serviceName,
        mode: 'live',
        data,
      };
    } else {
      const errorMsg = data.error || `SMM Panel error: HTTP ${response.status}`;
      console.warn('SMM Panel returned order error:', data);
      return {
        success: false,
        error: errorMsg,
        serviceIdUsed: serviceId,
        serviceNameUsed: serviceName,
        mode: 'live',
        data,
      };
    }
  } catch (err: any) {
    console.error('Network error communicating with SMM Panel:', err);
    return {
      success: false,
      error: err.message || 'Failed to reach my.smm-panel.com',
      serviceIdUsed: serviceId,
      serviceNameUsed: serviceName,
      mode: 'live',
    };
  }
}

/**
 * Check order status on https://my.smm-panel.com
 */
export async function checkSmmOrderStatus(orderId: string | number): Promise<{
  success: boolean;
  status: string;
  remains?: number | string;
  startCount?: number | string;
  error?: string;
  data?: any;
}> {
  const { apiKey, apiUrl, isConfigured } = getSmmCredentials();

  if (!isConfigured || !orderId || String(orderId).startsWith('SMM-')) {
    return {
      success: true,
      status: 'In progress',
      remains: 0,
      startCount: 0,
    };
  }

  try {
    const body = new URLSearchParams();
    body.append('key', apiKey);
    body.append('action', 'status');
    body.append('order', String(orderId));

    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json',
      },
      body: body.toString(),
    });

    if (response.ok) {
      const data = await response.json();
      return {
        success: !data.error,
        status: data.status || 'Pending',
        remains: data.remains,
        startCount: data.start_count,
        error: data.error,
        data,
      };
    }
  } catch (err: any) {
    console.warn('Status check error for order:', orderId, err);
  }

  return {
    success: true,
    status: 'In progress',
  };
}

/**
 * Default robust service blueprint matching https://my.smm-panel.com service schema
 */
function getFallbackServicesList(): SmmService[] {
  return [
    { service: 101, name: 'TikTok Followers | Instant | Non-Drop [HQ]', category: 'TikTok Followers', rate: 1.1, min: 100, max: 250000, refill: true },
    { service: 102, name: 'TikTok Likes | High Quality Real Hearts [Fast]', category: 'TikTok Likes', rate: 0.5, min: 100, max: 500000, refill: true },
    { service: 103, name: 'TikTok Views | FYP High Retention Views', category: 'TikTok Views', rate: 0.25, min: 250, max: 1000000 },
    { service: 104, name: 'TikTok Custom Comments | Organic Positive', category: 'TikTok Comments', rate: 2.0, min: 20, max: 50000 },

    { service: 201, name: 'Instagram Followers | Real & Active [Refill 30D]', category: 'Instagram Followers', rate: 1.2, min: 100, max: 200000, refill: true },
    { service: 202, name: 'Instagram Likes | Real High Retention Hearts', category: 'Instagram Likes', rate: 0.6, min: 100, max: 300000, refill: true },
    { service: 203, name: 'Instagram Reels Views | Explore Algorithm Reach', category: 'Instagram Views', rate: 0.3, min: 250, max: 2000000 },

    { service: 301, name: 'YouTube Subscribers | Non-Drop Active Creators', category: 'YouTube Subscribers', rate: 2.8, min: 50, max: 100000, refill: true },
    { service: 302, name: 'YouTube Views | High Retention Recommended Views', category: 'YouTube Views', rate: 1.0, min: 500, max: 5000000 },
    { service: 303, name: 'YouTube Likes | Real Engagement', category: 'YouTube Likes', rate: 0.9, min: 100, max: 250000 },

    { service: 401, name: 'Facebook Page Likes & Followers | High Quality', category: 'Facebook Followers', rate: 1.5, min: 100, max: 200000, refill: true },
    { service: 402, name: 'Facebook Post Likes & Reactions', category: 'Facebook Likes', rate: 0.8, min: 100, max: 100000 },

    { service: 501, name: 'X / Twitter Followers | Organic Appearance [HQ]', category: 'Twitter Followers', rate: 1.6, min: 100, max: 150000, refill: true },
    { service: 502, name: 'X / Twitter Likes & Retweets', category: 'Twitter Likes', rate: 0.9, min: 100, max: 100000 },

    { service: 601, name: 'Telegram Channel Members | Non-Drop Stable', category: 'Telegram Members', rate: 1.0, min: 100, max: 100000, refill: true },
    { service: 602, name: 'Telegram Post Views | Instant', category: 'Telegram Views', rate: 0.2, min: 200, max: 500000 },

    { service: 701, name: 'WhatsApp Channel Members | Active Real Contacts', category: 'WhatsApp Members', rate: 2.2, min: 100, max: 50000, refill: true },
  ];
}
