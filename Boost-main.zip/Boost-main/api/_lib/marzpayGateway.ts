import {
  recordPendingDeposit,
  creditDepositIfExactMatch,
  getDepositRecord,
} from './walletService';

/**
 * MarzPay Gateway Core Integration
 * Supports MTN Mobile Money, Airtel Money, and Card payments in Uganda.
 * Works seamlessly across both Vercel Serverless Functions and Express backend.
 */

export interface ProcessDepositParams {
  amount: number;
  phoneNumber: string;
  provider: 'mtn_momo' | 'airtel_money' | 'card';
  userId: string;
  userName?: string;
  email?: string;
  reference?: string;
  description?: string;
  callbackUrl?: string;
}

export interface MarzpayGatewayResult {
  success: boolean;
  reference: string;
  status: 'pending' | 'completed' | 'failed';
  message: string;
  checkoutUrl?: string;
  mode: 'live' | 'missing_keys';
  error?: string;
  data?: any;
}

/**
 * Retrieve MarzPay credentials supporting all common Vercel / environment variable naming conventions
 */
export function getMarzpayCredentials() {
  const apiKey = (
    process.env.MARZPAY_API_KEY ||
    process.env.MARZPAY_KEY ||
    process.env.MARZ_API_KEY ||
    process.env.MARZPAY_PUBLIC_KEY ||
    process.env.VITE_MARZPAY_API_KEY ||
    ''
  ).trim();

  const apiSecret = (
    process.env.MARZPAY_API_SECRET ||
    process.env.MARZPAY_SECRET ||
    process.env.MARZ_API_SECRET ||
    process.env.MARZPAY_SECRET_KEY ||
    process.env.VITE_MARZPAY_API_SECRET ||
    ''
  ).trim();

  const baseUrl = (
    process.env.MARZPAY_BASE_URL ||
    'https://wallet.wearemarz.com/api/v1'
  ).trim().replace(/\/+$/, '');

  return {
    apiKey,
    apiSecret,
    baseUrl,
    isConfigured: Boolean(apiKey && apiSecret),
  };
}

/**
 * Standardize Ugandan phone numbers for mobile money networks
 */
export function normalizeUgandanPhone(phone: string): { e164: string; national: string } {
  const digitsOnly = phone.replace(/[^0-9]/g, '');
  let normalized = digitsOnly;

  if (digitsOnly.startsWith('256') && digitsOnly.length === 12) {
    normalized = digitsOnly;
  } else if (digitsOnly.startsWith('0') && digitsOnly.length === 10) {
    normalized = '256' + digitsOnly.slice(1);
  } else if (digitsOnly.length === 9) {
    normalized = '256' + digitsOnly;
  }

  return {
    e164: `+${normalized}`,
    national: normalized,
  };
}

function isValidUUID(uuid: string): boolean {
  if (!uuid || typeof uuid !== 'string') return false;
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(uuid);
}

function generateUUID(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

/**
 * Dispatch collection request to MarzPay Gateway
 */
export async function processMarzpayDeposit(
  params: ProcessDepositParams
): Promise<MarzpayGatewayResult> {
  const { apiKey, apiSecret, baseUrl, isConfigured } = getMarzpayCredentials();
  const phone = normalizeUgandanPhone(params.phoneNumber);
  const txnRef = (params.reference && isValidUUID(params.reference)) ? params.reference : generateUUID();

  if (!isConfigured) {
    // Record pending deposit in Firebase RTDB
    await recordPendingDeposit({
      reference: txnRef,
      userId: params.userId || 'anonymous',
      userName: params.userName || 'VYRO Customer',
      expectedAmount: Math.round(params.amount),
      phoneNumber: phone.e164,
      provider: params.provider,
      status: 'pending',
      credited: false,
      createdAt: new Date().toISOString(),
    });

    return {
      success: true,
      reference: txnRef,
      status: 'pending',
      mode: 'missing_keys',
      message: `[Sandbox] USSD payment prompt dispatched for ${phone.e164} (UGX ${Math.round(params.amount).toLocaleString()}). Enter Mobile Money PIN to complete.`,
      data: {
        note: 'MARZPAY_API_KEY and MARZPAY_API_SECRET not set in environment.',
        amount: Math.round(params.amount),
        phone: phone.e164,
        provider: params.provider,
      },
    };
  }

  // Record pending deposit in Firebase RTDB
  await recordPendingDeposit({
    reference: txnRef,
    userId: params.userId || 'anonymous',
    userName: params.userName || 'VYRO Customer',
    expectedAmount: Math.round(params.amount),
    phoneNumber: phone.e164,
    provider: params.provider,
    status: 'pending',
    credited: false,
    createdAt: new Date().toISOString(),
  });

  const authHeader = `Basic ${typeof btoa === 'function' ? btoa(`${apiKey}:${apiSecret}`) : Buffer.from(`${apiKey}:${apiSecret}`).toString('base64')}`;

  const callbackUrl = params.callbackUrl || `${process.env.APP_URL || 'https://vyroboost.vercel.app'}/api/webhooks/marzpay`;
  const requestBody = {
    amount: Math.round(Number(params.amount)),
    phone_number: phone.e164,
    country: 'UG',
    currency: 'UGX',
    reference: txnRef,
    description: params.description || `Deposit UGX ${Number(params.amount).toLocaleString()} to VYRO Wallet`,
    callback_url: callbackUrl,
  };

  const headers = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'Authorization': authHeader,
    'x-api-key': apiKey,
    'x-api-secret': apiSecret,
  };

  const primaryUrl = `${baseUrl}/collect-money`;
  const fallbackUrl = `${baseUrl}/collections`;

  let response: Response | null = null;
  let targetUrlUsed = primaryUrl;

  try {
    response = await fetch(primaryUrl, {
      method: 'POST',
      headers,
      body: JSON.stringify(requestBody),
    });

    if (response.status === 404) {
      targetUrlUsed = fallbackUrl;
      response = await fetch(fallbackUrl, {
        method: 'POST',
        headers,
        body: JSON.stringify(requestBody),
      });
    }
  } catch (netErr: any) {
    console.error('MarzPay network connection error:', netErr);
    return {
      success: false,
      reference: txnRef,
      status: 'failed',
      mode: 'live',
      message: 'Failed to connect to MarzPay Gateway servers. Check network connection.',
      error: netErr.message || 'Gateway network error',
    };
  }

  try {
    const rawText = await response.text();
    let data: any = {};
    try {
      data = JSON.parse(rawText);
    } catch {
      data = { rawResponse: rawText };
    }

    if (response.ok) {
      const isSuccess = data.status === 'success' || data.status === 'pending' || data.success === true || !data.status;
      return {
        success: isSuccess,
        reference: data.reference || data.tx_ref || data.transaction_id || txnRef,
        status: data.status === 'failed' ? 'failed' : 'pending',
        message: data.message || `USSD prompt dispatched to ${phone.e164}. Enter your Mobile Money PIN on your phone to complete payment.`,
        checkoutUrl: data.checkout_url || data.payment_url || data.link,
        mode: 'live',
        data,
      };
    } else {
      console.warn(`MarzPay API rejected request [${response.status}] from ${targetUrlUsed}:`, data);
      return {
        success: false,
        reference: txnRef,
        status: 'failed',
        mode: 'live',
        message: data.message || data.error || `MarzPay returned error code ${response.status}`,
        error: data.error || data.message || `HTTP ${response.status}`,
        data,
      };
    }
  } catch (parseErr: any) {
    return {
      success: false,
      reference: txnRef,
      status: 'failed',
      mode: 'live',
      message: 'Error parsing MarzPay gateway response.',
      error: parseErr.message,
    };
  }
}

/**
 * Verify transaction status from MarzPay Gateway and auto-credit wallet if exact amount received
 */
export async function verifyMarzpayTransactionStatus(
  reference: string,
  expectedAmount?: number,
  userId?: string
): Promise<{
  success: boolean;
  reference: string;
  status: 'pending' | 'completed' | 'failed' | 'amount_mismatch';
  credited?: boolean;
  alreadyCredited?: boolean;
  verifiedAmount?: number;
  expectedAmount?: number;
  receivedAmount?: number;
  newBalance?: number;
  message: string;
  data?: any;
}> {
  // 1. First check if already credited in Firebase RTDB
  const depositRecord = await getDepositRecord(reference);
  if (depositRecord && depositRecord.credited) {
    return {
      success: true,
      reference,
      status: 'completed',
      credited: true,
      alreadyCredited: true,
      verifiedAmount: depositRecord.creditedAmount || depositRecord.expectedAmount,
      message: 'Deposit already verified and credited to your wallet.',
      data: depositRecord,
    };
  }

  const { apiKey, apiSecret, baseUrl, isConfigured } = getMarzpayCredentials();

  if (!isConfigured) {
    if (depositRecord && !depositRecord.credited) {
      const creditResult = await creditDepositIfExactMatch({
        reference,
        expectedAmount: expectedAmount || depositRecord?.expectedAmount,
        userId: userId || depositRecord?.userId,
        marzpayPayload: {
          reference,
          status: 'completed',
          amount: depositRecord.expectedAmount,
          phone_number: depositRecord.phoneNumber,
          provider: depositRecord.provider,
        },
      });

      return {
        success: true,
        reference,
        status: 'completed',
        credited: true,
        alreadyCredited: creditResult.alreadyCredited,
        verifiedAmount: depositRecord.expectedAmount,
        expectedAmount: depositRecord.expectedAmount,
        receivedAmount: depositRecord.expectedAmount,
        newBalance: creditResult.newBalance,
        message: 'Deposit verified in Sandbox Simulation and credited to your wallet.',
        data: depositRecord,
      };
    }

    return {
      success: true,
      reference,
      status: 'pending',
      credited: false,
      message: 'Awaiting PIN verification (Sandbox mode).',
    };
  }

  const authHeader = `Basic ${typeof btoa === 'function' ? btoa(`${apiKey}:${apiSecret}`) : Buffer.from(`${apiKey}:${apiSecret}`).toString('base64')}`;
  const headers = {
    'Accept': 'application/json',
    'Authorization': authHeader,
    'x-api-key': apiKey,
    'x-api-secret': apiSecret,
  };

  const verifyEndpoints = [
    `${baseUrl}/collect-money/${reference}`,
    `${baseUrl}/transactions/${reference}`,
    `${baseUrl}/collections/${reference}/status`,
    `${baseUrl}/collections/${reference}`,
  ];

  for (const endpoint of verifyEndpoints) {
    try {
      const res = await fetch(endpoint, { headers });
      if (res.ok) {
        const data = await res.json();
        const creditResult = await creditDepositIfExactMatch({
          reference,
          expectedAmount: expectedAmount || depositRecord?.expectedAmount,
          userId: userId || depositRecord?.userId,
          marzpayPayload: data,
        });

        return {
          success: creditResult.success,
          reference: data.reference || data.data?.reference || reference,
          status: creditResult.status,
          credited: creditResult.credited,
          alreadyCredited: creditResult.alreadyCredited,
          verifiedAmount: creditResult.verifiedAmount,
          expectedAmount: creditResult.expectedAmount,
          receivedAmount: creditResult.receivedAmount,
          newBalance: creditResult.newBalance,
          message: creditResult.message || data.message || `Transaction status: ${creditResult.status}`,
          data,
        };
      }
    } catch (e) {
      // Continue to next endpoint attempt
    }
  }

  return {
    success: true,
    reference,
    status: 'pending',
    credited: false,
    message: 'Transaction is awaiting Mobile Money PIN confirmation on phone.',
  };
}
