export default async function handler(req: any, res: any) {
  try {
    const marzApiKey = (process.env.MARZPAY_API_KEY || process.env.MARZPAY_KEY || '').trim();
    const marzSecret = (process.env.MARZPAY_API_SECRET || process.env.MARZPAY_SECRET || '').trim();
    const smmApiKey = (process.env.SMM_PANEL_API_KEY || process.env.SMM_API_KEY || '').trim();

    const payload = {
      status: 'ok',
      service: 'VYRO Platform API',
      marzpayConfigured: Boolean(marzApiKey && marzSecret),
      smmConfigured: Boolean(smmApiKey),
      timestamp: new Date().toISOString(),
    };

    if (typeof res.status === 'function') {
      return res.status(200).json(payload);
    } else {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify(payload));
    }
  } catch (err: any) {
    const errPayload = { status: 'error', error: err?.message || 'Unknown error' };
    if (typeof res.status === 'function') {
      return res.status(500).json(errPayload);
    } else {
      res.writeHead(500, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify(errPayload));
    }
  }
}
