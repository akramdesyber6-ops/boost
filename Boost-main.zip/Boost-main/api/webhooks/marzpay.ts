import crypto from 'crypto';
import { creditDepositIfExactMatch, parseMarzpayData } from '../_lib/walletService';
import { getMarzpayCredentials } from '../_lib/marzpayGateway';

export default async function handler(req: any, res: any) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, x-api-key, x-signature, x-webhook-signature');

  if (req.method === 'OPTIONS') {
    return res.status ? res.status(200).end() : res.writeHead(200).end();
  }

  const send = (code: number, data: any) => {
    if (typeof res.status === 'function') {
      return res.status(code).json(data);
    } else {
      res.writeHead(code, { 'Content-Type': 'application/json' });
      return res.end(JSON.stringify(data));
    }
  };

  try {
    let payload = req.body;
    let rawBody = '';

    if (typeof payload === 'string') {
      rawBody = payload;
      try {
        payload = JSON.parse(payload);
      } catch {
        payload = { raw: payload };
      }
    } else {
      // In Vercel, req.body is already parsed if it's JSON.
      // We recreate raw body string to verify signature.
      rawBody = JSON.stringify(payload);
    }

    const creds = getMarzpayCredentials();
    const signature = req.headers['x-signature'] || req.headers['x-webhook-signature'] || '';
    const apiKeyHeader = req.headers['x-api-key'] || '';

    let isVerified = false;
    if (signature) {
      const expectedSignatureHex = crypto.createHmac('sha256', creds.apiSecret).update(rawBody).digest('hex');
      const expectedSignatureB64 = crypto.createHmac('sha256', creds.apiSecret).update(rawBody).digest('base64');
      isVerified = signature === expectedSignatureHex || signature === expectedSignatureB64;
    } else if (apiKeyHeader === creds.apiKey) {
      isVerified = true;
    }

    if (!isVerified) {
      console.warn('[SECURITY] Invalid MarzPay webhook signature rejected in Serverless Function.');
      return send(401, { success: false, error: 'Unauthorized: Invalid signature' });
    }

    console.log('[MarzPay Webhook Received]:', JSON.stringify(payload));

    const parsed = parseMarzpayData(payload);

    if (parsed.reference) {
      // Process credit if exact amount was received by MarzPay
      const creditResult = await creditDepositIfExactMatch({
        reference: parsed.reference,
        marzpayPayload: payload,
      });

      console.log(
        `[MarzPay Webhook Processed] Ref: ${parsed.reference}, Result:`,
        creditResult
      );

      return send(200, {
        received: true,
        status: 'acknowledged',
        credited: creditResult.credited,
        alreadyCredited: creditResult.alreadyCredited,
        timestamp: new Date().toISOString(),
      });
    }

    // Acknowledge receipt even if unrecognized to prevent webhook retries
    return send(200, {
      received: true,
      status: 'acknowledged',
      timestamp: new Date().toISOString(),
    });
  } catch (err: any) {
    console.error('[MarzPay Webhook Error]:', err);
    return send(200, { received: true, note: 'Error processed and acknowledged' });
  }
}
