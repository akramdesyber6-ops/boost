## Security Threat Model

### Component Overview
An Express endpoint (`/api/webhooks/marzpay`) that receives webhook callbacks from the MarzPay payment gateway to confirm deposit transaction success and credit users' wallets.

### Entry Points and Untrusted Inputs
| Entry Point | Type | Trusted? | Validation |
|---|---|---|---|
| `/api/webhooks/marzpay` | HTTP POST webhook | No | Needs signature verification to authenticate the request as genuinely from MarzPay. |

### Trust Boundaries and Auth Assumptions
- **Authentication**: We will use a cryptographic signature (HMAC-SHA256) of the request body with `MARZPAY_API_SECRET` to authenticate the request, or check a direct secret header if MarzPay uses one.
- **Authorization**: If the signature matches, the request is authorized to trigger wallet crediting for the transaction reference contained in the body.
- **Implicit trust**: We cannot trust the body without signature verification. We cannot credit without verifying the amount matches the expected amount.

### Sensitive Data Paths
| Data Type | Source | Destination | Protection |
|---|---|---|---|
| User Balance | Firebase RTDB | Firebase RTDB | Updated only after signature validation, status="completed", and amount verification. |

### Privileged Actions
| Action | Location | Guard |
|---|---|---|
| Wallet Crediting | `server.ts` | Guarded by webhook signature verification and amount matching logic. |

### Priority Review Areas
1. Webhook Signature Verification: Ensure requests without a valid signature are rejected with 401/403.
2. Amount Verification: Prevent partial or fraudulent deposits from crediting an incorrect balance.
3. Idempotency: Prevent replay attacks or duplicate webhooks from crediting the user multiple times.

## Verification Plan

### Security Verification
- **Security Scan**: Inspect the newly created `/api/webhooks/marzpay` route for signature bypasses, missing amount checks, and double-crediting.
- **Security Audit**: Audit the implementation against the threat model. Document findings and remediations in `walkthrough.md`.
