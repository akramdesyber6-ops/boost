import React from 'react';
import { SocialOrb } from '../common/BrandIcons';
import { Platform, User } from '../../types';
import { 
  ArrowRight, 
  LogIn, 
  Heart, 
  Users, 
  CheckCheck,
  Zap
} from 'lucide-react';

interface LandingPageProps {
  currentUser: User | null;
  onGetStarted: () => void;
  onLogin: () => void;
  onSelectPlatformBoost: (platform: Platform) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  currentUser,
  onGetStarted,
  onLogin,
  onSelectPlatformBoost,
}) => {
  return (
    <div className="relative flex flex-col items-center justify-center h-full min-h-[calc(100vh-140px)] overflow-hidden bg-[#F4F7FF] dark:bg-[#0B1020] transition-colors">
      {/* Background ambient lighting orbs */}
      <div className="absolute top-10 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-[#7357FF]/10 dark:bg-[#7357FF]/15 blur-[120px] rounded-full pointer-events-none -z-10" />
      <div className="absolute top-40 right-10 w-[350px] h-[350px] bg-[#22D3EE]/10 dark:bg-[#22D3EE]/10 blur-[100px] rounded-full pointer-events-none -z-10" />

      {/* Main Container */}
      <div className="w-full max-w-5xl mx-auto px-4 flex flex-col items-center">
        
        {/* Mobile & Tablet Focused Stage Layout */}
        <div className="w-full max-w-[440px] flex flex-col items-center">
          {/* HERO CREATOR AVATAR WITH GLOWING ORB & FLOATING STATS PILLS */}
          <div className="relative w-full max-w-[280px] h-[250px] sm:h-[270px] flex items-center justify-center mt-1 mb-2">
            {/* Glowing Orb Backdrop */}
            <div className="absolute inset-1 rounded-full bg-gradient-to-tr from-[#7357FF]/20 via-[#22D3EE]/20 to-[#EC4899]/20 blur-xl animate-pulse" />
            <div className="absolute inset-3 rounded-full bg-gradient-to-tr from-[#E8EAFF] via-white to-[#FFEBF5] dark:from-[#111A32] dark:via-[#162244] dark:to-[#1A1838] border border-white/80 dark:border-[#7357FF]/30 shadow-vyro-card" />

            {/* Creator Image */}
            <div className="relative z-10 w-[180px] h-[220px] sm:h-[235px] overflow-hidden rounded-b-full flex items-end justify-center pointer-events-none">
              <img
                src="https://f005.backblazeb2.com/file/vendoproducts/1789460015088_mx50csg2.png"
                alt="josechakala"
                className="w-full h-full object-cover object-center filter contrast-[1.03]"
                referrerPolicy="no-referrer"
              />
              {/* Soft gradient fade at base to melt into background */}
              <div className="absolute bottom-0 inset-x-0 h-12 bg-gradient-to-t from-[#F4F7FF] dark:from-[#0B1020] via-[#F4F7FF]/70 dark:via-[#0B1020]/70 to-transparent" />
            </div>

            {/* FLOATING STAT PILL 1: TOP LEFT (TIKTOK VIEWS 1.2M ↑) */}
            <div className="absolute top-2 -left-2 z-20 bg-white/95 dark:bg-[#111A32]/95 backdrop-blur-md rounded-full px-2.5 py-1 shadow-vyro-card border border-[#E1E7F3] dark:border-[#7357FF]/30 flex items-center gap-1.5 transform hover:scale-105 transition-transform animate-float-slow">
              <div className="w-5 h-5 rounded-full bg-black text-white flex items-center justify-center p-1 shrink-0">
                <svg viewBox="0 0 24 24" fill="currentColor" className="w-3.5 h-3.5">
                  <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64c.29 0 .58.04.85.12V9.4a6.33 6.33 0 0 0-.85-.06A6.34 6.34 0 0 0 3.1 15.68a6.34 6.34 0 0 0 10.74 4.53 6.34 6.34 0 0 0 1.95-4.54V9.08c1.33.95 2.94 1.52 4.69 1.58V7.22a4.78 4.78 0 0 1-.89-.53z" />
                </svg>
              </div>
              <div>
                <p className="text-[8px] font-bold text-[#68738B] dark:text-slate-400 uppercase tracking-wider leading-none">
                  TikTok Reach
                </p>
                <p className="text-xs font-black text-[#10172A] dark:text-white flex items-center gap-0.5 leading-tight">
                  <span>1.2M</span>
                  <span className="text-emerald-500 font-bold text-[9px]">↑</span>
                </p>
              </div>
            </div>

            {/* FLOATING STAT PILL 2: MIDDLE RIGHT (LIKES +84.6K) */}
            <div className="absolute top-20 -right-2 z-20 bg-white/95 dark:bg-[#111A32]/95 backdrop-blur-md rounded-full px-2.5 py-1 shadow-vyro-card border border-[#E1E7F3] dark:border-[#7357FF]/30 flex items-center gap-1.5 transform hover:scale-105 transition-transform animate-float-reverse">
              <div className="w-5 h-5 rounded-full bg-[#EC4899]/10 text-[#EC4899] flex items-center justify-center shrink-0">
                <Heart className="w-3.5 h-3.5 fill-[#EC4899]" />
              </div>
              <div>
                <p className="text-[8px] font-bold text-[#68738B] dark:text-slate-400 uppercase tracking-wider leading-none">
                  Engagement
                </p>
                <p className="text-xs font-black text-[#10172A] dark:text-white leading-tight">
                  +84.6K
                </p>
              </div>
            </div>

            {/* FLOATING STAT PILL 3: BOTTOM LEFT (COMMUNITY +25.4K) */}
            <div className="absolute bottom-2 -left-2 z-20 bg-white/95 dark:bg-[#111A32]/95 backdrop-blur-md rounded-full px-2.5 py-1 shadow-vyro-card border border-[#E1E7F3] dark:border-[#7357FF]/30 flex items-center gap-1.5 transform hover:scale-105 transition-transform">
              <div className="w-5 h-5 rounded-full bg-[#7357FF]/10 text-[#7357FF] dark:text-[#22D3EE] flex items-center justify-center shrink-0">
                <Users className="w-3.5 h-3.5" />
              </div>
              <div>
                <p className="text-[8px] font-bold text-[#68738B] dark:text-slate-400 uppercase tracking-wider leading-none">
                  New Followers
                </p>
                <p className="text-xs font-black text-[#10172A] dark:text-white leading-tight">
                  +25.4K
                </p>
              </div>
            </div>
          </div>

          {/* CHAT / WELCOMING MESSAGE BUBBLE */}
          <div className="w-full bg-white dark:bg-[#111A32] rounded-3xl p-4 shadow-vyro-card border border-[#E1E7F3] dark:border-[#7357FF]/30 relative mb-3 transition-all">
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-black text-[#10172A] dark:text-white tracking-wide">
                  josechakala
                </span>
                {/* Verified badge */}
                <span className="w-3 h-3 rounded-full bg-[#22D3EE] text-slate-900 flex items-center justify-center text-[8px] font-black">
                  ✓
                </span>
                {/* Online indicator */}
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block animate-ping" />
              </div>
              <span className="text-[9px] text-[#68738B] dark:text-slate-400 font-medium">
                Active now
              </span>
            </div>

            {/* Message Content with VYRO branding */}
            <p className="text-xs text-[#10172A] dark:text-slate-200 font-semibold leading-relaxed pr-6">
              Hey! 👋 Welcome to <span className="font-extrabold text-[#7357FF] dark:text-[#22D3EE]">VYRO</span>. Turn attention into momentum.
            </p>

            {/* Cyan double check mark */}
            <div className="flex justify-end mt-0.5">
              <CheckCheck className="w-3 h-3 text-[#22D3EE]" />
            </div>
          </div>

          {/* SUBTITLE: "Where do you want to grow?" */}
          <div className="w-full flex items-center justify-center gap-2 my-1">
            <div className="h-[1px] w-10 bg-gradient-to-r from-transparent to-[#7357FF]/30" />
            <span className="text-[11px] font-bold text-[#68738B] dark:text-slate-400">
              Where do you want to grow?
            </span>
            <div className="h-[1px] w-10 bg-gradient-to-l from-transparent to-[#7357FF]/30" />
          </div>

          {/* 3D GLOWING SOCIAL ICONS ORBS */}
          <div className="flex items-center justify-center gap-3 my-2">
            <SocialOrb
              type="tiktok"
              onClick={() => onSelectPlatformBoost('tiktok')}
              size="md"
            />
            <SocialOrb
              type="x"
              onClick={() => onSelectPlatformBoost('x')}
              size="md"
            />
            <SocialOrb
              type="instagram"
              onClick={() => onSelectPlatformBoost('instagram')}
              size="md"
            />
            <SocialOrb
              type="youtube"
              onClick={() => onSelectPlatformBoost('youtube')}
              size="md"
            />
            <SocialOrb
              type="telegram"
              onClick={() => onSelectPlatformBoost('tiktok')}
              size="md"
            />
          </div>

          {/* BOTTOM ACTION BUTTONS */}
          <div className="w-full mt-2 mb-1">
            {!currentUser ? (
              <div className="grid grid-cols-2 gap-2">
                {/* Gradient Get Started Button */}
                <button
                  id="landing-get-started-btn"
                  onClick={onGetStarted}
                  className="py-3 px-3 rounded-full text-white text-xs sm:text-sm font-bold shadow-vyro-glow hover:opacity-95 transition-all transform hover:-translate-y-0.5 active:translate-y-0 flex items-center justify-center gap-1.5 cursor-pointer"
                  style={{
                    background: 'linear-gradient(110deg, #5B4BFF 0%, #8B5CF6 42%, #EC4899 75%, #FF8A65 100%)',
                  }}
                >
                  <span>Get Started</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>

                {/* Log In Button */}
                <button
                  id="landing-login-btn"
                  onClick={onLogin}
                  className="py-3 px-3 rounded-full bg-white dark:bg-[#111A32] text-[#10172A] dark:text-white text-xs sm:text-sm font-bold border border-[#E1E7F3] dark:border-[#7357FF]/30 shadow-sm hover:border-[#7357FF] transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <span>Log In</span>
                  <LogIn className="w-3.5 h-3.5 text-[#7357FF] dark:text-[#22D3EE]" />
                </button>
              </div>
            ) : (
              <button
                id="landing-boost-now-btn"
                onClick={onGetStarted}
                className="w-full py-3.5 px-4 rounded-full text-white text-sm sm:text-base font-black shadow-vyro-glow hover:opacity-95 transition-all transform hover:-translate-y-0.5 active:translate-y-0 flex items-center justify-center gap-2 cursor-pointer"
                style={{
                  background: 'linear-gradient(110deg, #5B4BFF 0%, #8B5CF6 42%, #EC4899 75%, #FF8A65 100%)',
                }}
              >
                <Zap className="w-5 h-5" />
                <span>Boost Now</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
