import React, { useState } from 'react';
import { User } from '../../types';
import { updateUser, addNotification } from '../../lib/storage';
import { 
  User as UserIcon, 
  Mail, 
  Phone, 
  AtSign, 
  KeyRound, 
  CheckCircle2, 
  Save, 
  Check,
  Shield
} from 'lucide-react';

interface ProfilePageProps {
  currentUser: User;
  onUserUpdated: (updatedUser: User) => void;
  onNavigateToWallet?: () => void;
}

const AVATAR_OPTIONS = [
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80',
  'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
];

export const ProfilePage: React.FC<ProfilePageProps> = ({
  currentUser,
  onUserUpdated,
}) => {
  const [fullName, setFullName] = useState(currentUser.fullName);
  const [username, setUsername] = useState(currentUser.username);
  const [phone, setPhone] = useState(currentUser.phone || '');
  const [avatarUrl, setAvatarUrl] = useState(currentUser.avatarUrl || AVATAR_OPTIONS[0]);

  // Password change state
  const [showPasswordChange, setShowPasswordChange] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState('');
  const [passwordError, setPasswordError] = useState('');

  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    
    // If password change is opened and filled
    if (showPasswordChange && newPassword) {
      if (newPassword.length < 6) {
        setPasswordError('Password must be at least 6 characters');
        return;
      }
      if (newPassword !== confirmPassword) {
        setPasswordError('Passwords do not match');
        return;
      }
      setPasswordSuccess('Password updated successfully!');
      setPasswordError('');
      setNewPassword('');
      setConfirmPassword('');
      setShowPasswordChange(false);
    }

    const updated: User = {
      ...currentUser,
      fullName: fullName.trim(),
      username: username.trim().toLowerCase().replace(/\s+/g, '_'),
      phone: phone.trim(),
      avatarUrl: avatarUrl.trim(),
      // Preserve existing role strictly without privilege escalation
      role: currentUser.role || 'user',
      connectedAccounts: currentUser.connectedAccounts,
      notificationPreferences: currentUser.notificationPreferences || {
        email: true,
        campaignUpdates: true,
        security: true,
        marketing: false,
      },
    };

    updateUser(updated);
    onUserUpdated(updated);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);

    addNotification({
      id: 'notif_' + Date.now(),
      userId: currentUser.id,
      title: 'Profile Updated',
      message: 'Your profile settings have been saved.',
      read: false,
      type: 'info',
      createdAt: new Date().toISOString(),
    });
  };

  return (
    <div className="w-full max-w-2xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6">
      {/* Page Title */}
      <div>
        <h1 className="text-2xl font-black text-[#10172A] dark:text-white">
          My Profile
        </h1>
        <p className="text-xs sm:text-sm text-[#68738B] dark:text-slate-400 mt-0.5">
          Manage your account information, mobile money number, and security.
        </p>
      </div>

      {savedSuccess && (
        <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs sm:text-sm flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span className="font-semibold">Profile saved successfully!</span>
        </div>
      )}

      {passwordSuccess && (
        <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs sm:text-sm flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span className="font-semibold">{passwordSuccess}</span>
        </div>
      )}

      {/* Main Form */}
      <form onSubmit={handleSaveProfile} className="space-y-5">
        {/* Profile Card */}
        <div className="bg-white dark:bg-[#111A32] rounded-3xl p-6 border border-[#E1E7F3] dark:border-[#7357FF]/20 shadow-vyro-card space-y-5">
          
          {/* Avatar and basic info header */}
          <div className="flex items-center gap-4 pb-4 border-b border-[#E1E7F3] dark:border-slate-800">
            <img
              src={avatarUrl}
              alt={fullName}
              className="w-16 h-16 rounded-full object-cover ring-2 ring-[#7357FF]/30 shadow-sm shrink-0"
            />
            <div className="flex-1 min-w-0">
              <h2 className="text-base font-bold text-[#10172A] dark:text-white truncate">
                {fullName || 'Your Name'}
              </h2>
              <p className="text-xs text-[#68738B] dark:text-slate-400 truncate">
                @{username || 'username'} · {currentUser.email}
              </p>
              <div className="flex items-center gap-2 mt-1.5">
                <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-[#FF4500]/10 text-[#FF4500] dark:text-[#FFAA00]">
                  UGX {currentUser.balanceUGX.toLocaleString()}
                </span>
                <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-[#68738B] dark:text-slate-300">
                  <Shield className="w-2.5 h-2.5 text-[#FF4500]" />
                  {currentUser.role === 'admin' ? 'Administrator' : 'Creator Account'}
                </span>
              </div>
            </div>
          </div>

          {/* Avatar Presets Selection */}
          <div>
            <label className="block text-xs font-semibold text-[#10172A] dark:text-slate-200 mb-2">
              Choose Avatar
            </label>
            <div className="flex items-center gap-2.5">
              {AVATAR_OPTIONS.map((img, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setAvatarUrl(img)}
                  className={`relative rounded-full transition-all cursor-pointer ${
                    avatarUrl === img ? 'ring-2 ring-[#FF4500] scale-105' : 'opacity-70 hover:opacity-100'
                  }`}
                >
                  <img
                    src={img}
                    alt={`Avatar option ${idx + 1}`}
                    className="w-10 h-10 rounded-full object-cover"
                  />
                  {avatarUrl === img && (
                    <span className="absolute -bottom-1 -right-1 bg-[#FF4500] text-white p-0.5 rounded-full ring-1 ring-white">
                      <Check className="w-2.5 h-2.5" />
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Basic Fields */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div>
              <label className="block text-xs font-semibold text-[#10172A] dark:text-slate-200 mb-1">
                Full Name
              </label>
              <div className="relative">
                <UserIcon className="w-4 h-4 text-[#68738B] absolute left-3 top-3" />
                <input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  required
                  placeholder="Your full name"
                  className="w-full pl-9 pr-3 py-2 bg-[#F4F7FF] dark:bg-[#0B1020] border border-[#E1E7F3] dark:border-slate-800 rounded-xl text-xs sm:text-sm text-[#10172A] dark:text-white focus:outline-none focus:border-[#FF4500]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#10172A] dark:text-slate-200 mb-1">
                Username
              </label>
              <div className="relative">
                <AtSign className="w-4 h-4 text-[#68738B] absolute left-3 top-3" />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                  placeholder="username"
                  className="w-full pl-9 pr-3 py-2 bg-[#F4F7FF] dark:bg-[#0B1020] border border-[#E1E7F3] dark:border-slate-800 rounded-xl text-xs sm:text-sm text-[#10172A] dark:text-white focus:outline-none focus:border-[#FF4500]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#10172A] dark:text-slate-200 mb-1">
                Email (Read-only)
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-[#68738B] absolute left-3 top-3" />
                <input
                  type="email"
                  value={currentUser.email}
                  disabled
                  className="w-full pl-9 pr-3 py-2 bg-slate-100 dark:bg-slate-900 border border-[#E1E7F3] dark:border-slate-800 rounded-xl text-xs sm:text-sm text-slate-500 cursor-not-allowed"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-[#10172A] dark:text-slate-200 mb-1">
                Mobile Number (MTN / Airtel)
              </label>
              <div className="relative">
                <Phone className="w-4 h-4 text-[#68738B] absolute left-3 top-3" />
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="0772 000 000"
                  className="w-full pl-9 pr-3 py-2 bg-[#F4F7FF] dark:bg-[#0B1020] border border-[#E1E7F3] dark:border-slate-800 rounded-xl text-xs sm:text-sm text-[#10172A] dark:text-white focus:outline-none focus:border-[#FF4500]"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Security & Password Card */}
        <div className="bg-white dark:bg-[#111A32] rounded-3xl p-6 border border-[#E1E7F3] dark:border-[#FF4500]/20 shadow-vyro-card space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-[#10172A] dark:text-white flex items-center gap-1.5">
                <KeyRound className="w-4 h-4 text-[#FF4500]" />
                <span>Password & Security</span>
              </h3>
              <p className="text-[11px] text-[#68738B] dark:text-slate-400 mt-0.5">
                Update your login password securely.
              </p>
            </div>

            <button
              type="button"
              onClick={() => {
                setShowPasswordChange(!showPasswordChange);
                setPasswordError('');
              }}
              className="text-xs font-bold text-[#FF4500] hover:underline cursor-pointer flex items-center gap-1"
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>{showPasswordChange ? 'Cancel' : 'Change Password'}</span>
            </button>
          </div>

          {passwordError && (
            <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs font-semibold">
              {passwordError}
            </div>
          )}

          {showPasswordChange && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 animate-in fade-in">
              <div>
                <label className="block text-[11px] font-semibold text-[#10172A] dark:text-slate-200 mb-1">
                  New Password
                </label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Min 6 characters"
                  className="w-full px-3 py-2 bg-[#F4F7FF] dark:bg-[#0B1020] border border-[#E1E7F3] dark:border-slate-800 rounded-xl text-xs text-[#10172A] dark:text-white focus:outline-none focus:border-[#FF4500]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-[#10172A] dark:text-slate-200 mb-1">
                  Confirm New Password
                </label>
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Repeat new password"
                  className="w-full px-3 py-2 bg-[#F4F7FF] dark:bg-[#0B1020] border border-[#E1E7F3] dark:border-slate-800 rounded-xl text-xs text-[#10172A] dark:text-white focus:outline-none focus:border-[#FF4500]"
                />
              </div>
            </div>
          )}
        </div>

        {/* Save button */}
        <div className="flex justify-end pt-1">
          <button
            type="submit"
            className="w-full sm:w-auto px-8 py-3 rounded-full text-xs sm:text-sm font-bold text-white shadow-vyro-glow hover:opacity-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
            style={{
              background: 'linear-gradient(110deg, #FF1E40 0%, #FF4500 38%, #FF7A00 75%, #FFAA00 100%)',
            }}
          >
            <Save className="w-4 h-4" />
            <span>Save Profile</span>
          </button>
        </div>
      </form>
    </div>
  );
};
