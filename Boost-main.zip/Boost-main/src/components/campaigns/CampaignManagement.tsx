import React, { useState } from 'react';
import { User, Campaign, CampaignStatus } from '../../types';
import { PlatformIcon } from '../common/BrandIcons';
import { saveCampaign, addNotification } from '../../lib/storage';
import { 
  Sparkles, 
  PlusCircle, 
  Play, 
  Pause, 
  XCircle, 
  ExternalLink, 
  TrendingUp, 
  Eye, 
  Calendar, 
  CheckCircle2, 
  Clock, 
  AlertCircle,
  BarChart3,
  HelpCircle,
  ShieldCheck,
  Share2
} from 'lucide-react';

interface CampaignManagementProps {
  currentUser: User;
  campaigns: Campaign[];
  onStartNewCampaign: () => void;
  onCampaignsUpdated: () => void;
}

export const CampaignManagement: React.FC<CampaignManagementProps> = ({
  currentUser,
  campaigns,
  onStartNewCampaign,
  onCampaignsUpdated,
}) => {
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [selectedCampaign, setSelectedCampaign] = useState<Campaign | null>(null);

  const userCampaigns = campaigns.filter((c) => c.userId === currentUser.id);

  const filtered = userCampaigns.filter((c) => {
    if (filterStatus === 'all') return true;
    return c.status === filterStatus;
  });

  const handleTogglePause = (campaign: Campaign) => {
    const newStatus: CampaignStatus = campaign.status === 'active' ? 'paused' : 'active';
    const updated: Campaign = {
      ...campaign,
      status: newStatus,
      updatedAt: new Date().toISOString(),
    };
    saveCampaign(updated);
    addNotification({
      id: 'notif_' + Date.now(),
      userId: currentUser.id,
      title: `Order ${newStatus === 'active' ? 'Resumed' : 'Paused'}`,
      message: `Your order "${campaign.description.substring(0, 30)}..." is now ${newStatus}.`,
      read: false,
      type: 'info',
      createdAt: new Date().toISOString(),
    });
    onCampaignsUpdated();
  };

  const handleCancel = (campaign: Campaign) => {
    if (!confirm('Are you sure you want to cancel this order? Any unspent UGX funds will be refunded to your VYRO wallet.')) {
      return;
    }
    const updated: Campaign = {
      ...campaign,
      status: 'cancelled',
      updatedAt: new Date().toISOString(),
    };
    saveCampaign(updated);
    addNotification({
      id: 'notif_' + Date.now(),
      userId: currentUser.id,
      title: 'Order Cancelled',
      message: `Your order has been cancelled. Unspent budget refunded.`,
      read: false,
      type: 'warning',
      createdAt: new Date().toISOString(),
    });
    onCampaignsUpdated();
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 py-4 sm:py-6 space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-[#10172A] dark:text-white">
            Orders Operations & Tracking
          </h1>
          <p className="text-xs sm:text-sm text-[#68738B] dark:text-slate-400">
            Monitor delivery progress, verified engagement, and track your orders in real time.
          </p>
        </div>

        <button
          id="campaigns-launch-new-btn"
          onClick={onStartNewCampaign}
          className="px-5 py-2.5 rounded-full text-white text-xs sm:text-sm font-bold shadow-vyro-glow hover:opacity-95 transition-all flex items-center gap-2 self-start sm:self-auto shrink-0"
          style={{
            background: 'linear-gradient(110deg, #5B4BFF 0%, #8B5CF6 42%, #EC4899 75%, #FF8A65 100%)',
          }}
        >
          <PlusCircle className="w-4 h-4" />
          <span>New Order</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
        {[
          { id: 'all', label: 'All Orders', count: userCampaigns.length },
          { id: 'active', label: 'Active', count: userCampaigns.filter((c) => c.status === 'active').length },
          { id: 'pending_review', label: 'Pending Review', count: userCampaigns.filter((c) => c.status === 'pending_review').length },
          { id: 'paused', label: 'Paused', count: userCampaigns.filter((c) => c.status === 'paused').length },
          { id: 'completed', label: 'Completed', count: userCampaigns.filter((c) => c.status === 'completed').length },
          { id: 'cancelled', label: 'Cancelled', count: userCampaigns.filter((c) => c.status === 'cancelled').length },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setFilterStatus(tab.id)}
            className={`px-3.5 py-1.5 rounded-full text-xs font-bold shrink-0 transition-all flex items-center gap-1.5 ${
              filterStatus === tab.id
                ? 'bg-[#7357FF] text-white shadow-sm'
                : 'bg-white dark:bg-[#111A32] text-[#68738B] dark:text-slate-400 hover:text-[#10172A] dark:hover:text-white border border-[#E1E7F3] dark:border-[#7357FF]/20'
            }`}
          >
            <span>{tab.label}</span>
            <span
              className={`px-1.5 py-0.2 rounded-full text-[10px] ${
                filterStatus === tab.id ? 'bg-white/25 text-white' : 'bg-slate-100 dark:bg-slate-800 text-[#68738B] dark:text-slate-400'
              }`}
            >
              {tab.count}
            </span>
          </button>
        ))}
      </div>

      {/* Campaign List Cards */}
      {filtered.length === 0 ? (
        <div className="bg-white dark:bg-[#111A32] rounded-3xl p-12 text-center border border-[#E1E7F3] dark:border-[#7357FF]/25 shadow-vyro-card">
          <Sparkles className="w-12 h-12 text-[#7357FF] mx-auto mb-3" />
          <h3 className="text-base font-bold text-[#10172A] dark:text-white">No orders match this filter</h3>
          <p className="text-xs text-[#68738B] dark:text-slate-400 mt-1">Ready to promote your latest social content?</p>
          <button
            onClick={onStartNewCampaign}
            className="mt-4 px-5 py-2.5 rounded-full text-white text-xs font-bold shadow-vyro-glow hover:opacity-95 transition-all"
            style={{
              background: 'linear-gradient(110deg, #5B4BFF 0%, #8B5CF6 42%, #EC4899 75%, #FF8A65 100%)',
            }}
          >
            Place Your First Order
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {filtered.map((cmp) => {
            const isCompleted = cmp.status === 'completed';
            const isActive = cmp.status === 'active';
            const isPaused = cmp.status === 'paused';

            return (
              <div
                key={cmp.id}
                className="bg-white dark:bg-[#111A32] rounded-3xl p-5 sm:p-6 border border-[#E1E7F3] dark:border-[#7357FF]/25 shadow-vyro-card hover:border-[#7357FF]/50 transition-all"
              >
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                  {/* Left: Platform & Info */}
                  <div className="flex items-start gap-3.5">
                    <PlatformIcon platform={cmp.platform} size="lg" />
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs font-extrabold text-[#7357FF] dark:text-[#22D3EE] uppercase tracking-wider">
                          {cmp.platform} · {cmp.goal.replace('_', ' ')}
                        </span>
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider ${
                            cmp.status === 'active'
                              ? 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                              : cmp.status === 'completed'
                              ? 'bg-blue-500/15 text-blue-600 dark:text-blue-400'
                              : cmp.status === 'pending_review'
                              ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400'
                              : cmp.status === 'paused'
                              ? 'bg-[#7357FF]/15 text-[#7357FF] dark:text-[#22D3EE]'
                              : 'bg-rose-500/15 text-rose-600 dark:text-rose-400'
                          }`}
                        >
                          {cmp.status.replace('_', ' ')}
                        </span>
                      </div>

                      <h3 className="text-sm sm:text-base font-bold text-[#10172A] dark:text-white mt-1">
                        {cmp.description}
                      </h3>

                      <a
                        href={cmp.destinationUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="text-[11px] text-[#68738B] dark:text-slate-400 hover:text-[#7357FF] dark:hover:text-[#22D3EE] inline-flex items-center gap-1 mt-0.5"
                      >
                        <span className="truncate max-w-[260px]">{cmp.destinationUrl}</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>

                  {/* Right: Quick Numbers */}
                  <div className="flex items-center gap-4 sm:gap-6 self-start md:self-center border-t md:border-t-0 pt-3 md:pt-0 border-slate-100 dark:border-slate-800">
                    <div>
                      <p className="text-[10px] uppercase font-bold text-[#68738B] dark:text-slate-400">Budget</p>
                      <p className="text-sm sm:text-base font-extrabold text-[#10172A] dark:text-white">
                        UGX {cmp.budgetUGX.toLocaleString()}
                      </p>
                    </div>

                    <div>
                      <p className="text-[10px] uppercase font-bold text-[#68738B] dark:text-slate-400">Delivered</p>
                      <p className="text-sm sm:text-base font-extrabold text-[#7357FF] dark:text-[#22D3EE]">
                        {cmp.impressionsDelivered.toLocaleString()}
                      </p>
                    </div>

                    <div>
                      <p className="text-[10px] uppercase font-bold text-[#68738B] dark:text-slate-400">Engagements</p>
                      <p className="text-sm sm:text-base font-extrabold text-[#EC4899]">
                        {cmp.engagementsCount.toLocaleString()}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Progress Bar & Status Controls */}
                <div className="mt-5 pt-4 border-t border-[#E1E7F3] dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex-1 pr-4">
                    <div className="flex items-center justify-between text-xs mb-1.5">
                      <span className="text-[#68738B] dark:text-slate-400 font-medium">Delivery Progress</span>
                      <span className="font-bold text-[#10172A] dark:text-white">
                        {cmp.progressPercentage}% ({cmp.impressionsDelivered.toLocaleString()} / {cmp.targetImpressions.toLocaleString()} views)
                      </span>
                    </div>
                    <div className="w-full h-2.5 rounded-full bg-[#E8EDF8] dark:bg-slate-800 overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-500"
                        style={{
                          width: `${cmp.progressPercentage}%`,
                          background: 'linear-gradient(90deg, #5B4BFF 0%, #8B5CF6 50%, #EC4899 100%)',
                        }}
                      />
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                    {(isActive || isPaused) && (
                      <button
                        onClick={() => handleTogglePause(cmp)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors flex items-center gap-1.5 ${
                          isActive
                            ? 'border-[#7357FF]/30 hover:bg-[#7357FF]/10 text-[#7357FF] dark:text-[#22D3EE]'
                            : 'border-emerald-500/30 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                        }`}
                      >
                        {isActive ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                        <span>{isActive ? 'Pause' : 'Resume'}</span>
                      </button>
                    )}

                    {isActive && (
                      <button
                        onClick={() => handleCancel(cmp)}
                        className="px-3 py-1.5 rounded-xl text-xs font-bold border border-rose-200 dark:border-rose-900/50 hover:bg-rose-50 dark:hover:bg-rose-950/30 text-rose-600 dark:text-rose-400 transition-colors"
                      >
                        Cancel
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
