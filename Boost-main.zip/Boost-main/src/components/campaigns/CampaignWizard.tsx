import React, { useState, useEffect, useMemo } from 'react';
import confetti from 'canvas-confetti';
import { User, Campaign, Platform } from '../../types';
import { SocialOrbsSlider, PlatformIcon } from '../common/BrandIcons';
import { saveCampaign, addTransaction, updateUser, addNotification } from '../../lib/storage';
import { initiateMarzpayDeposit, detectProviderFromPhone } from '../../services/marzpay';
import { dispatchSmmOrder } from '../../services/smm';
import { 
  Check, 
  ArrowRight, 
  Link as LinkIcon, 
  Wallet, 
  Smartphone, 
  AlertCircle, 
  CheckCircle2,
  Users,
  Heart,
  Eye,
  MessageCircle,
  Repeat2,
  Clock
} from 'lucide-react';

interface CampaignWizardProps {
  currentUser: User;
  onCampaignCreated: (campaign: Campaign) => void;
  onCancel: () => void;
  initialGoal?: string;
  initialPlatform?: Platform;
}

interface ServiceOption {
  id: string;
  label: string;
  unitName: string;
  icon: React.ReactNode;
  ratePer100: number; // in UGX
  minOrder: number;
  maxOrder: number;
}

const ALL_SERVICES: Record<Platform, ServiceOption[]> = {
  tiktok: [
    { id: 'followers', label: 'Followers', unitName: 'follower', icon: <Users className="w-4 h-4" />, ratePer100: 3800, minOrder: 100, maxOrder: 250000 },
    { id: 'likes', label: 'Likes', unitName: 'like', icon: <Heart className="w-4 h-4 fill-current" />, ratePer100: 1900, minOrder: 100, maxOrder: 500000 },
    { id: 'views', label: 'FYP Views', unitName: 'view', icon: <Eye className="w-4 h-4" />, ratePer100: 950, minOrder: 250, maxOrder: 1000000 },
    { id: 'comments', label: 'Comments', unitName: 'comment', icon: <MessageCircle className="w-4 h-4" />, ratePer100: 4500, minOrder: 50, maxOrder: 50000 },
    { id: 'shares', label: 'Shares', unitName: 'share', icon: <Repeat2 className="w-4 h-4" />, ratePer100: 2200, minOrder: 100, maxOrder: 100000 },
  ],
  instagram: [
    { id: 'followers', label: 'Followers', unitName: 'follower', icon: <Users className="w-4 h-4" />, ratePer100: 3800, minOrder: 100, maxOrder: 250000 },
    { id: 'likes', label: 'Likes', unitName: 'like', icon: <Heart className="w-4 h-4 fill-current" />, ratePer100: 1900, minOrder: 100, maxOrder: 500000 },
    { id: 'views', label: 'Reels Views', unitName: 'view', icon: <Eye className="w-4 h-4" />, ratePer100: 950, minOrder: 250, maxOrder: 1000000 },
    { id: 'comments', label: 'Comments', unitName: 'comment', icon: <MessageCircle className="w-4 h-4" />, ratePer100: 4500, minOrder: 50, maxOrder: 50000 },
  ],
  youtube: [
    { id: 'followers', label: 'Subscribers', unitName: 'subscriber', icon: <Users className="w-4 h-4" />, ratePer100: 5500, minOrder: 50, maxOrder: 100000 },
    { id: 'views', label: 'High-Retention Views', unitName: 'view', icon: <Eye className="w-4 h-4" />, ratePer100: 2200, minOrder: 250, maxOrder: 500000 },
    { id: 'likes', label: 'Likes', unitName: 'like', icon: <Heart className="w-4 h-4 fill-current" />, ratePer100: 2500, minOrder: 100, maxOrder: 250000 },
    { id: 'watchtime', label: 'Watch Hours', unitName: 'hour', icon: <Clock className="w-4 h-4" />, ratePer100: 8500, minOrder: 25, maxOrder: 10000 },
  ],
  facebook: [
    { id: 'followers', label: 'Page Followers', unitName: 'follower', icon: <Users className="w-4 h-4" />, ratePer100: 3800, minOrder: 100, maxOrder: 250000 },
    { id: 'likes', label: 'Post Likes', unitName: 'like', icon: <Heart className="w-4 h-4 fill-current" />, ratePer100: 1900, minOrder: 100, maxOrder: 500000 },
    { id: 'views', label: 'Video Views', unitName: 'view', icon: <Eye className="w-4 h-4" />, ratePer100: 1200, minOrder: 250, maxOrder: 1000000 },
    { id: 'shares', label: 'Post Shares', unitName: 'share', icon: <Repeat2 className="w-4 h-4" />, ratePer100: 2500, minOrder: 100, maxOrder: 100000 },
  ],
  x: [
    { id: 'followers', label: 'Followers', unitName: 'follower', icon: <Users className="w-4 h-4" />, ratePer100: 4200, minOrder: 100, maxOrder: 100000 },
    { id: 'likes', label: 'Tweet Likes', unitName: 'like', icon: <Heart className="w-4 h-4 fill-current" />, ratePer100: 2200, minOrder: 100, maxOrder: 250000 },
    { id: 'views', label: 'Impressions', unitName: 'impression', icon: <Eye className="w-4 h-4" />, ratePer100: 950, minOrder: 500, maxOrder: 2000000 },
    { id: 'shares', label: 'Reposts (Retweets)', unitName: 'repost', icon: <Repeat2 className="w-4 h-4" />, ratePer100: 3200, minOrder: 50, maxOrder: 100000 },
  ],
  telegram: [
    { id: 'followers', label: 'Channel Members', unitName: 'member', icon: <Users className="w-4 h-4" />, ratePer100: 4500, minOrder: 100, maxOrder: 200000 },
    { id: 'views', label: 'Post Views', unitName: 'view', icon: <Eye className="w-4 h-4" />, ratePer100: 800, minOrder: 500, maxOrder: 1000000 },
    { id: 'likes', label: 'Post Reactions', unitName: 'reaction', icon: <Heart className="w-4 h-4 fill-current" />, ratePer100: 1500, minOrder: 100, maxOrder: 100000 },
    { id: 'shares', label: 'Group Members', unitName: 'member', icon: <Users className="w-4 h-4" />, ratePer100: 4800, minOrder: 100, maxOrder: 100000 },
  ],
  whatsapp: [
    { id: 'followers', label: 'Channel Followers', unitName: 'follower', icon: <Users className="w-4 h-4" />, ratePer100: 4800, minOrder: 100, maxOrder: 150000 },
    { id: 'views', label: 'Status & Channel Views', unitName: 'view', icon: <Eye className="w-4 h-4" />, ratePer100: 1800, minOrder: 250, maxOrder: 200000 },
    { id: 'likes', label: 'Message Reactions', unitName: 'reaction', icon: <Heart className="w-4 h-4 fill-current" />, ratePer100: 2200, minOrder: 100, maxOrder: 100000 },
    { id: 'shares', label: 'Group Members', unitName: 'member', icon: <Users className="w-4 h-4" />, ratePer100: 5200, minOrder: 50, maxOrder: 50000 },
  ],
};

const GENERIC_SERVICES: { id: string; label: string; icon: React.ReactNode }[] = [
  { id: 'followers', label: 'Followers & Subs', icon: <Users className="w-4 h-4" /> },
  { id: 'likes', label: 'Likes & Reactions', icon: <Heart className="w-4 h-4 fill-current" /> },
  { id: 'views', label: 'Views & Reach', icon: <Eye className="w-4 h-4" /> },
  { id: 'comments', label: 'Comments & Buzz', icon: <MessageCircle className="w-4 h-4" /> },
  { id: 'shares', label: 'Shares & Reposts', icon: <Repeat2 className="w-4 h-4" /> },
];

const PLATFORMS: { id: Platform; label: string }[] = [
  { id: 'tiktok', label: 'TikTok' },
  { id: 'instagram', label: 'Instagram' },
  { id: 'youtube', label: 'YouTube' },
  { id: 'telegram', label: 'Telegram' },
  { id: 'whatsapp', label: 'WhatsApp' },
  { id: 'x', label: 'X' },
  { id: 'facebook', label: 'Facebook' },
];

export const CampaignWizard: React.FC<CampaignWizardProps> = ({
  currentUser,
  onCampaignCreated,
  initialGoal,
  initialPlatform,
}) => {
  // Step 1: Service Type
  const [selectedServiceId, setSelectedServiceId] = useState<string | null>(() => {
    if (initialGoal === 'content_reach') return 'views';
    if (initialGoal === 'community_engagement') return 'comments';
    if (initialGoal === 'audience_growth') return 'followers';
    return null;
  });

  // Step 2: Platform
  const [selectedPlatform, setSelectedPlatform] = useState<Platform | null>(initialPlatform || null);
  
  // Available services for current platform
  const currentPlatformServices = useMemo(() => {
    if (!selectedPlatform) return ALL_SERVICES.tiktok;
    return ALL_SERVICES[selectedPlatform] || ALL_SERVICES.tiktok;
  }, [selectedPlatform]);

  // Current service object for rates
  const currentServiceObj = useMemo(() => {
    const sId = selectedServiceId || 'followers';
    return currentPlatformServices.find((s) => s.id === sId) || currentPlatformServices[0];
  }, [currentPlatformServices, selectedServiceId]);

  // Step 3: Quantity input state
  const [quantityInput, setQuantityInput] = useState<string>('500');
  const [hasChosenQuantity, setHasChosenQuantity] = useState<boolean>(false);

  // Step 4: Destination URL
  const [destinationUrl, setDestinationUrl] = useState<string>('');

  // Step 5: Payment method
  const [paymentMethod, setPaymentMethod] = useState<'balance' | 'marzpay_momo'>('balance');
  const [phoneNumber, setPhoneNumber] = useState(currentUser.phone || '+256 772 123 456');

  // Execution feedback
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successOrder, setSuccessOrder] = useState<Campaign | null>(null);

  // Parse quantity cleanly from input
  const parsedQuantity = useMemo(() => {
    const cleaned = quantityInput.replace(/[^\d]/g, '');
    const num = parseInt(cleaned, 10);
    return isNaN(num) ? 0 : num;
  }, [quantityInput]);

  // Dynamic automatic price calculation: (quantity / 100) * ratePer100
  const totalCostUGX = useMemo(() => {
    if (parsedQuantity <= 0) return 0;
    return Math.round((parsedQuantity / 100) * currentServiceObj.ratePer100);
  }, [parsedQuantity, currentServiceObj.ratePer100]);

  const hasEnoughBalance = currentUser.balanceUGX >= totalCostUGX;

  // Progressive visibility gates:
  // Step 1: Always visible
  // Step 2: Visible once a service is selected
  const showStep2 = Boolean(selectedServiceId);
  // Step 3: Visible once a platform is selected
  const showStep3 = Boolean(selectedServiceId && selectedPlatform);
  // Step 4: Visible once quantity is configured/selected
  const showStep4 = Boolean(showStep3 && (hasChosenQuantity || parsedQuantity > 0));
  // Step 5: Visible once link is entered (at least 3 chars)
  const showStep5 = Boolean(showStep4 && destinationUrl.trim().length >= 3);

  const handleSelectService = (serviceId: string) => {
    setSelectedServiceId(serviceId);
    setErrorMsg(null);
  };

  const handleSelectPlatform = (plat: Platform) => {
    setSelectedPlatform(plat);
    setErrorMsg(null);
    if (!destinationUrl) {
      if (plat === 'tiktok') setDestinationUrl('https://www.tiktok.com/@');
      else if (plat === 'instagram') setDestinationUrl('https://www.instagram.com/');
      else if (plat === 'youtube') setDestinationUrl('https://www.youtube.com/watch?v=');
      else if (plat === 'facebook') setDestinationUrl('https://www.facebook.com/');
      else if (plat === 'x') setDestinationUrl('https://x.com/');
    }
  };

  const handleSelectPreset = (amt: number) => {
    setQuantityInput(amt.toString());
    setHasChosenQuantity(true);
    setErrorMsg(null);
  };

  const handleCustomQuantityChange = (val: string) => {
    const digitsOnly = val.replace(/[^\d]/g, '');
    setQuantityInput(digitsOnly);
    setHasChosenQuantity(true);
    setErrorMsg(null);
  };

  const handleLaunchCampaign = async () => {
    setErrorMsg(null);

    // Validate Platform
    const platformToUse = selectedPlatform || 'tiktok';

    // Validate URL
    if (!destinationUrl || destinationUrl.trim().length < 5) {
      setErrorMsg('Please enter a valid social link or account username.');
      return;
    }

    if (parsedQuantity < 100 || parsedQuantity > 250000) {
      setErrorMsg('Quantity must be between 100 and 250,000.');
      return;
    }

    if (paymentMethod === 'balance' && !hasEnoughBalance) {
      setErrorMsg(`Insufficient VYRO balance (UGX ${currentUser.balanceUGX.toLocaleString()}). Select Mobile Money or top up your wallet.`);
      return;
    }

    if (paymentMethod === 'marzpay_momo' && (!phoneNumber || phoneNumber.trim().length < 9)) {
      setErrorMsg('Please enter a valid MTN or Airtel phone number for the Mobile Money prompt.');
      return;
    }

    setIsSubmitting(true);

    let paymentRef = 'VYRO-WALLET';

    if (paymentMethod === 'marzpay_momo') {
      try {
        const marzResp = await initiateMarzpayDeposit({
          amountUGX: totalCostUGX,
          phoneNumber: phoneNumber.trim(),
          provider: detectProviderFromPhone(phoneNumber),
          userId: currentUser.id,
          userName: currentUser.fullName,
          email: currentUser.email,
          description: `VYRO Boost: ${platformToUse.toUpperCase()} ${currentServiceObj.label} (${parsedQuantity.toLocaleString()})`,
        });

        if (!marzResp.success) {
          setIsSubmitting(false);
          setErrorMsg(marzResp.message || 'Mobile Money request failed. Check your phone number or gateway setup.');
          return;
        }

        paymentRef = marzResp.reference;
      } catch (err: any) {
        setIsSubmitting(false);
        setErrorMsg(err.message || 'Payment gateway connection error.');
        return;
      }
    }

    setIsSubmitting(false);

    const newCampaign: Campaign = {
      id: 'cmp_' + Date.now(),
      userId: currentUser.id,
      userName: currentUser.fullName,
      goal: 'audience_growth',
      platform: platformToUse,
      budgetUGX: totalCostUGX,
      durationDays: 3,
      estimatedReach: {
        min: parsedQuantity,
        max: parsedQuantity * 2,
        metricLabel: `${currentServiceObj.label} Delivered`,
      },
      status: 'active',
      progressPercentage: 0,
      impressionsDelivered: 0,
      targetImpressions: parsedQuantity * 2,
      engagementsCount: 0,
      destinationUrl: destinationUrl.trim(),
      description: `Delivering ${parsedQuantity.toLocaleString()} high-retention verified ${currentServiceObj.label.toLowerCase()} across ${platformToUse}.`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      paymentReference: paymentRef,
      serviceCategory: selectedServiceId,
    };

    saveCampaign(newCampaign);

    // Dispatch automated order to https://my.smm-panel.com in the background
    // (Picks best service ID via backend smart selector, no services listed in user UI)
    dispatchSmmOrder({
      platform: platformToUse,
      serviceType: selectedServiceId,
      link: destinationUrl.trim(),
      quantity: parsedQuantity,
      campaignId: newCampaign.id,
      userId: currentUser.id,
    }).then((smmRes) => {
      if (smmRes.success && smmRes.orderId) {
        newCampaign.smmOrderId = smmRes.orderId;
        saveCampaign(newCampaign);
      }
    }).catch((e) => {
      console.warn('Background SMM dispatch:', e);
    });

    // Deduct balance or record mobile money
    if (paymentMethod === 'balance') {
      const updatedUserObj: User = {
        ...currentUser,
        balanceUGX: currentUser.balanceUGX - totalCostUGX,
      };
      updateUser(updatedUserObj);

      addTransaction({
        id: 'tx_' + Date.now(),
        userId: currentUser.id,
        userName: currentUser.fullName,
        campaignId: newCampaign.id,
        campaignTitle: `${platformToUse.toUpperCase()} ${currentServiceObj.label}`,
        amountUGX: totalCostUGX,
        currency: 'UGX',
        type: 'campaign_spend',
        paymentProvider: 'wallet',
        providerReference: 'BAL-' + Date.now(),
        status: 'completed',
        createdAt: new Date().toISOString(),
      });
    } else {
      addTransaction({
        id: 'tx_' + Date.now(),
        userId: currentUser.id,
        userName: currentUser.fullName,
        campaignId: newCampaign.id,
        campaignTitle: `${platformToUse.toUpperCase()} ${currentServiceObj.label}`,
        amountUGX: totalCostUGX,
        currency: 'UGX',
        type: 'campaign_spend',
        paymentProvider: 'marzpay',
        providerReference: paymentRef,
        status: 'completed',
        phoneNumber: phoneNumber,
        createdAt: new Date().toISOString(),
      });
    }

    addNotification({
      id: 'notif_' + Date.now(),
      userId: currentUser.id,
      title: paymentMethod === 'marzpay_momo' ? 'Order Initiated via MoMo' : 'Order Placed! 🚀',
      message: paymentMethod === 'marzpay_momo'
        ? `USSD payment prompt sent to ${phoneNumber}. Delivery starts automatically.`
        : `Your ${platformToUse.toUpperCase()} ${currentServiceObj.label} boost of ${parsedQuantity.toLocaleString()} units is now actively dispatching.`,
      type: 'success',
      read: false,
      createdAt: new Date().toISOString(),
      link: 'orders',
    });

    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
    });

    setSuccessOrder(newCampaign);
  };

  return (
    <div className="relative min-h-[85vh] flex flex-col justify-start overflow-hidden bg-[#F4F7FF] dark:bg-[#0B1020] transition-colors">
      {/* Centered Phone Canvas Layout */}
      <div className="w-full max-w-[430px] mx-auto px-4 sm:px-5 pt-1 pb-10 flex flex-col items-center">
        
        {/* TOP GLOWING SOCIAL MEDIA ICONS SLIDER / MARQUEE */}
        <div className="w-full mb-3">
          <SocialOrbsSlider 
            onSelectPlatform={(plat) => {
              if (!selectedServiceId) {
                setSelectedServiceId('followers');
              }
              handleSelectPlatform(plat);
            }} 
          />
        </div>

        {/* ORDER SUCCESS MODAL OVERLAY */}
        {successOrder ? (
          <div className="w-full bg-white dark:bg-[#111A32] rounded-3xl p-6 shadow-vyro-card border border-[#E1E7F3] dark:border-[#7357FF]/30 text-center animate-in zoom-in-95 duration-200">
            <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto mb-3">
              <CheckCircle2 className="w-9 h-9" />
            </div>

            <h3 className="text-xl font-black text-[#10172A] dark:text-white">
              Order Activated!
            </h3>
            <p className="text-xs text-[#68738B] dark:text-slate-400 mt-1">
              Your boost order for <span className="font-bold text-[#10172A] dark:text-white">{parsedQuantity.toLocaleString()} {currentServiceObj.label}</span> on <span className="font-bold text-[#7357FF] dark:text-[#22D3EE] uppercase">{selectedPlatform || 'Social'}</span> has begun distribution.
            </p>

            <div className="my-4 p-4 rounded-2xl bg-[#F4F7FF] dark:bg-[#0B1020] text-left text-xs space-y-1.5 border border-[#E1E7F3] dark:border-slate-800">
              <div className="flex justify-between">
                <span className="text-[#68738B] dark:text-slate-400">Order Reference:</span>
                <span className="font-mono font-bold text-[#10172A] dark:text-white">{successOrder.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#68738B] dark:text-slate-400">Total Billed:</span>
                <span className="font-bold text-[#10172A] dark:text-white">UGX {successOrder.budgetUGX.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#68738B] dark:text-slate-400">Estimated Delivery:</span>
                <span className="font-bold text-emerald-600 dark:text-emerald-400">2 - 6 Hours</span>
              </div>
            </div>

            <button
              onClick={() => onCampaignCreated(successOrder)}
              className="w-full py-3.5 rounded-full text-white font-bold text-xs sm:text-sm shadow-vyro-glow hover:opacity-95 transition-all cursor-pointer"
              style={{
                background: 'linear-gradient(110deg, #FF1E40 0%, #FF4500 38%, #FF7A00 75%, #FFAA00 100%)',
              }}
            >
              Track in My Orders
            </button>
          </div>
        ) : (
          /* STEP-BY-STEP PROGRESSIVE ORDER FORM */
          <div className="w-full space-y-4">
            
            {/* STEP 1: WHAT DO YOU WANT TO BOOST? */}
            <div className="w-full">
              <div className="flex items-center gap-2 mb-2">
                <span className="w-5 h-5 rounded-full bg-[#FF4500] text-white text-[10px] font-black flex items-center justify-center shrink-0 shadow-sm">
                  1
                </span>
                <h3 className="text-xs sm:text-sm font-extrabold text-[#10172A] dark:text-white">
                  What do you want to boost?
                </h3>
              </div>

              {/* Service Type Selection Pills */}
              <div className="grid grid-cols-2 gap-2">
                {(selectedPlatform ? currentPlatformServices : GENERIC_SERVICES).map((service) => {
                  const isSelected = selectedServiceId === service.id;
                  return (
                    <button
                      key={service.id}
                      type="button"
                      onClick={() => handleSelectService(service.id)}
                      className={`py-2.5 px-3 rounded-full text-xs font-bold border transition-all flex items-center justify-between cursor-pointer ${
                        isSelected
                          ? 'bg-[#FF4500]/10 border-[#FF4500] text-[#FF4500] dark:text-[#FFAA00] shadow-sm'
                          : 'bg-white dark:bg-[#111A32] border-[#E1E7F3] dark:border-[#FF4500]/20 text-[#10172A] dark:text-white hover:bg-slate-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      <span className="flex items-center gap-1.5 truncate">
                        {service.icon}
                        <span className="truncate">{service.label}</span>
                      </span>
                      {isSelected && <Check className="w-3.5 h-3.5 text-[#FF4500] dark:text-[#FFAA00] shrink-0" />}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* STEP 2: WHICH PLATFORM DO YOU WANT TO BOOST? (Appears after Step 1) */}
            {showStep2 && (
              <div className="w-full animate-in fade-in slide-in-from-top-3 duration-300">
                <div className="flex items-center gap-2 mb-2">
                  <span className="w-5 h-5 rounded-full bg-[#FF4500] text-white text-[10px] font-black flex items-center justify-center shrink-0 shadow-sm">
                    2
                  </span>
                  <h3 className="text-xs sm:text-sm font-extrabold text-[#10172A] dark:text-white">
                    Which platform do you want to boost?
                  </h3>
                </div>

                {/* Horizontal Platform Pills */}
                <div className="flex flex-wrap gap-2">
                  {PLATFORMS.map((plat) => {
                    const isSelected = selectedPlatform === plat.id;
                    return (
                      <button
                        key={plat.id}
                        type="button"
                        onClick={() => handleSelectPlatform(plat.id)}
                        className={`py-2 px-3.5 rounded-full text-xs font-bold border transition-all flex items-center gap-1.5 cursor-pointer ${
                          isSelected
                            ? 'bg-[#FF4500]/10 border-[#FF4500] text-[#FF4500] dark:text-[#FFAA00] shadow-sm'
                            : 'bg-white dark:bg-[#111A32] border-[#E1E7F3] dark:border-[#FF4500]/20 text-[#10172A] dark:text-white hover:bg-slate-50 dark:hover:bg-slate-800'
                        }`}
                      >
                        <PlatformIcon platform={plat.id} size="sm" />
                        <span>{plat.label}</span>
                        {isSelected && <Check className="w-3.5 h-3.5 text-[#FF4500] dark:text-[#FFAA00] ml-0.5" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* STEP 3: HOW MANY WOULD YOU LIKE? (Appears after Step 2) */}
            {showStep3 && (
              <div className="w-full animate-in fade-in slide-in-from-top-3 duration-300">
                <div className="flex items-center gap-2 mb-2">
                  <span className="w-5 h-5 rounded-full bg-[#FF4500] text-white text-[10px] font-black flex items-center justify-center shrink-0 shadow-sm">
                    3
                  </span>
                  <h3 className="text-xs sm:text-sm font-extrabold text-[#10172A] dark:text-white">
                    How many would you like?
                  </h3>
                </div>

                {/* Quantity Preset Pills */}
                <div className="flex flex-wrap gap-2 mb-2.5">
                  {[500, 1000, 2500, 5000, 10000].map((amt) => {
                    const isSelected = parsedQuantity === amt;
                    return (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => handleSelectPreset(amt)}
                        className={`py-2 px-3.5 rounded-full text-xs font-bold border transition-all flex items-center gap-1 cursor-pointer ${
                          isSelected
                            ? 'bg-[#111A32] dark:bg-white text-white dark:text-[#111A32] border-[#111A32] dark:border-white shadow-md'
                            : 'bg-white dark:bg-[#111A32] border-[#E1E7F3] dark:border-[#FF4500]/20 text-[#10172A] dark:text-white hover:bg-slate-50 dark:hover:bg-slate-800'
                        }`}
                      >
                        <span>{amt.toLocaleString()}</span>
                        {isSelected && <Check className="w-3 h-3 text-white dark:text-[#111A32]" />}
                      </button>
                    );
                  })}
                </div>

                {/* Simple Custom Amount Input Box with Auto-Calculation */}
                <div className="bg-white dark:bg-[#111A32] rounded-2xl p-3 border border-[#E1E7F3] dark:border-[#FF4500]/30 shadow-sm flex items-center justify-between">
                  <div>
                    <label htmlFor="custom-quantity-input" className="text-[10px] font-bold text-[#68738B] dark:text-slate-400 uppercase tracking-wider block">
                      Custom Units (Min 100 — Max 250,000)
                    </label>
                    <input
                      id="custom-quantity-input"
                      type="text"
                      inputMode="numeric"
                      pattern="[0-9]*"
                      value={quantityInput}
                      onChange={(e) => handleCustomQuantityChange(e.target.value)}
                      placeholder="e.g. 500"
                      className="w-28 text-sm font-black text-[#10172A] dark:text-white bg-transparent focus:outline-none mt-0.5"
                    />
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] text-[#68738B] dark:text-slate-400 block">Rate Calculated:</span>
                    <span className="text-sm font-extrabold text-[#FF4500] dark:text-[#FFAA00]">
                      UGX {totalCostUGX.toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>
            )}

            {/* STEP 4: WHERE SHOULD WE SEND THEM? (Appears after Step 3) */}
            {showStep4 && (
              <div className="w-full animate-in fade-in slide-in-from-top-3 duration-300">
                <div className="flex items-center gap-2 mb-2">
                  <span className="w-5 h-5 rounded-full bg-[#FF4500] text-white text-[10px] font-black flex items-center justify-center shrink-0 shadow-sm">
                    4
                  </span>
                  <h3 className="text-xs sm:text-sm font-extrabold text-[#10172A] dark:text-white">
                    Where should we send them?
                  </h3>
                </div>

                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#68738B] dark:text-slate-400">
                    <LinkIcon className="w-4 h-4" />
                  </span>
                  <input
                    id="destination-url-input"
                    type="text"
                    required
                    value={destinationUrl}
                    onChange={(e) => setDestinationUrl(e.target.value)}
                    placeholder={
                      selectedPlatform === 'telegram'
                        ? 'https://t.me/your_channel_or_group'
                        : selectedPlatform === 'whatsapp'
                        ? 'https://chat.whatsapp.com/... or channel link'
                        : `https://www.${selectedPlatform || 'tiktok'}.com/@username`
                    }
                    className="w-full pl-10 pr-4 py-3 rounded-full bg-white dark:bg-[#111A32] border border-[#E1E7F3] dark:border-[#FF4500]/30 text-xs sm:text-sm font-medium text-[#10172A] dark:text-white shadow-sm focus:border-[#FF4500] focus:outline-none"
                  />
                </div>
              </div>
            )}

            {/* STEP 5: CONFIRM ORDER & TOTAL (Appears after Step 4) */}
            {showStep5 && (
              <div className="w-full bg-white dark:bg-[#111A32] rounded-3xl p-4 border border-[#E1E7F3] dark:border-[#FF4500]/30 shadow-vyro-card space-y-3 animate-in fade-in slide-in-from-top-3 duration-300">
                <div className="flex items-center justify-between pb-2 border-b border-[#E1E7F3] dark:border-slate-800">
                  <div>
                    <span className="text-xs font-extrabold text-[#10172A] dark:text-white block">
                      Total Investment:
                    </span>
                    <span className="text-[10px] text-[#68738B] dark:text-slate-400">
                      {parsedQuantity.toLocaleString()} {currentServiceObj.label} on {(selectedPlatform || 'Social').toUpperCase()}
                    </span>
                  </div>
                  <span className="text-base font-black text-[#FF4500] dark:text-[#FFAA00]">
                    UGX {totalCostUGX.toLocaleString()}
                  </span>
                </div>

                {/* Payment Selector */}
                <div className="space-y-2">
                  {/* VYRO Balance Option */}
                  <label
                    onClick={() => setPaymentMethod('balance')}
                    className={`p-3 rounded-2xl border flex items-center justify-between cursor-pointer transition-all ${
                      paymentMethod === 'balance'
                        ? 'border-[#FF4500] bg-[#FF4500]/5 dark:bg-[#FF4500]/10'
                        : 'border-[#E1E7F3] dark:border-slate-800 bg-white dark:bg-[#111A32] hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-full bg-[#FF4500]/10 text-[#FF4500] dark:text-[#FFAA00] flex items-center justify-center">
                        <Wallet className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <p className="text-xs font-bold text-[#10172A] dark:text-white">
                          VYRO Balance
                        </p>
                        <p className="text-[10px] text-[#68738B] dark:text-slate-400">
                          Available: UGX {currentUser.balanceUGX.toLocaleString()}
                        </p>
                      </div>
                    </div>
                    <input
                      type="radio"
                      name="payment"
                      checked={paymentMethod === 'balance'}
                      onChange={() => setPaymentMethod('balance')}
                      className="w-4 h-4 text-[#FF4500]"
                    />
                  </label>

                  {/* Mobile Money Option */}
                  <label
                    onClick={() => setPaymentMethod('marzpay_momo')}
                    className={`p-3 rounded-2xl border flex items-center justify-between cursor-pointer transition-all ${
                      paymentMethod === 'marzpay_momo'
                        ? 'border-[#FF4500] bg-[#FF4500]/5 dark:bg-[#FF4500]/10'
                        : 'border-[#E1E7F3] dark:border-slate-800 bg-white dark:bg-[#111A32] hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-full bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                        <Smartphone className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <p className="text-xs font-bold text-[#10172A] dark:text-white">
                          Mobile Money
                        </p>
                        <p className="text-[10px] text-[#68738B] dark:text-slate-400">
                          MTN MoMo & Airtel Money Instant PIN Prompt
                        </p>
                      </div>
                    </div>
                    <input
                      type="radio"
                      name="payment"
                      checked={paymentMethod === 'marzpay_momo'}
                      onChange={() => setPaymentMethod('marzpay_momo')}
                      className="w-4 h-4 text-[#FF4500]"
                    />
                  </label>
                </div>

                {paymentMethod === 'marzpay_momo' && (
                  <div className="pt-1">
                    <label htmlFor="momo-phone-input" className="text-[10px] font-bold text-[#68738B] dark:text-slate-400 uppercase tracking-wider block mb-1">
                      Phone Number for PIN Prompt:
                    </label>
                    <input
                      id="momo-phone-input"
                      type="tel"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      placeholder="+256 772 123 456"
                      className="w-full px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-900 border border-[#E1E7F3] dark:border-slate-700 text-xs text-[#10172A] dark:text-white"
                    />
                  </div>
                )}

                {errorMsg && (
                  <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 flex items-center gap-2 text-xs text-rose-700 dark:text-rose-300">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{errorMsg}</span>
                  </div>
                )}

                {/* ACTION BUTTON: [ Place Order Now -> ] */}
                <button
                  id="wizard-launch-campaign-btn"
                  onClick={handleLaunchCampaign}
                  disabled={isSubmitting}
                  className="w-full py-4 px-4 rounded-full text-white text-xs sm:text-sm font-black shadow-vyro-glow hover:opacity-95 transition-all transform hover:-translate-y-0.5 active:translate-y-0 flex items-center justify-center gap-2 cursor-pointer mt-2"
                  style={{
                    background: 'linear-gradient(110deg, #FF1E40 0%, #FF4500 38%, #FF7A00 75%, #FFAA00 100%)',
                  }}
                >
                  {isSubmitting ? (
                    <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <span>Place Order Now</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

