import React, { useState } from 'react';
import { User, Campaign, Transaction, ServiceDefinition } from '../../types';
import { SERVICES, saveCampaign, updateUser, addNotification } from '../../lib/storage';
import { PlatformIcon } from '../common/BrandIcons';
import { 
  ShieldCheck, 
  Users, 
  Sparkles, 
  Receipt, 
  Check, 
  X, 
  AlertTriangle, 
  Sliders, 
  DollarSign, 
  Eye, 
  BarChart3, 
  CheckCircle2, 
  ExternalLink,
  Coins
} from 'lucide-react';

interface AdminPanelProps {
  currentUser: User;
  allUsers: User[];
  allCampaigns: Campaign[];
  allTransactions: Transaction[];
  onDataUpdated: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  currentUser,
  allUsers,
  allCampaigns,
  allTransactions,
  onDataUpdated,
}) => {
  const [activeTab, setActiveTab] = useState<'moderation' | 'users' | 'services' | 'ledger'>('moderation');
  const [servicesList, setServicesList] = useState<ServiceDefinition[]>(SERVICES);

  // Revenue calculation
  const totalRevenueUGX = allTransactions
    .filter((t) => t.type === 'campaign_spend')
    .reduce((acc, t) => acc + t.amountUGX, 0);

  const pendingCampaigns = allCampaigns.filter((c) => c.status === 'pending_review');
  const activeCampaigns = allCampaigns.filter((c) => c.status === 'active');

  const handleApproveCampaign = (campaign: Campaign) => {
    const updated: Campaign = {
      ...campaign,
      status: 'active',
      updatedAt: new Date().toISOString(),
    };
    saveCampaign(updated);

    addNotification({
      id: 'notif_' + Date.now(),
      userId: campaign.userId,
      title: 'Order Approved! 🚀',
      message: `Your order "${campaign.description.substring(0, 35)}..." has been verified and is now live.`,
      read: false,
      type: 'success',
      createdAt: new Date().toISOString(),
    });

    onDataUpdated();
  };

  const handleRejectCampaign = (campaign: Campaign) => {
    const reason = prompt('Reason for rejection (e.g. content policy violation, private account):');
    if (reason === null) return;

    const updated: Campaign = {
      ...campaign,
      status: 'failed',
      updatedAt: new Date().toISOString(),
    };
    saveCampaign(updated);

    addNotification({
      id: 'notif_' + Date.now(),
      userId: campaign.userId,
      title: 'Order Flagged',
      message: `Order rejected: ${reason || 'Does not adhere to advertising guidelines.'}`,
      read: false,
      type: 'warning',
      createdAt: new Date().toISOString(),
    });

    onDataUpdated();
  };

  const handleAdjustUserBalance = (user: User) => {
    const amountStr = prompt(`Adjust UGX balance for ${user.fullName} (current: UGX ${user.balanceUGX.toLocaleString()}):`, '50000');
    if (!amountStr) return;
    const delta = Number(amountStr);
    if (isNaN(delta)) return;

    const updated: User = {
      ...user,
      balanceUGX: Math.max(0, user.balanceUGX + delta),
    };
    updateUser(updated);
    onDataUpdated();
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 py-4 sm:py-6 space-y-6 animate-in fade-in duration-300">
      {/* Admin Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-indigo-500/10 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800/40 rounded-3xl p-5 sm:p-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-[#7357FF] text-white flex items-center justify-center shadow-vyro-glow">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-extrabold text-[#10172A] dark:text-white">
                VYRO Ops & Moderation
              </h1>
              <span className="px-2.5 py-0.5 rounded-full bg-[#7357FF]/20 text-[#7357FF] dark:text-[#22D3EE] text-[10px] font-extrabold uppercase">
                Staff Control
              </span>
            </div>
            <p className="text-xs text-[#68738B] dark:text-slate-400">
              Authenticated as {currentUser.fullName} ({currentUser.email})
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-[#7357FF] dark:text-[#22D3EE] bg-white dark:bg-[#111A32] px-3.5 py-1.5 rounded-full border border-[#E1E7F3] dark:border-[#7357FF]/30">
            {pendingCampaigns.length} orders pending review
          </span>
        </div>
      </div>

      {/* TOP METRIC CARDS */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Total Users */}
        <div className="bg-white dark:bg-[#111A32] rounded-3xl p-5 border border-[#E1E7F3] dark:border-[#7357FF]/25 shadow-vyro-card">
          <span className="text-xs font-semibold text-[#68738B] dark:text-slate-400">Total Creators & Brands</span>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl sm:text-3xl font-extrabold text-[#10172A] dark:text-white">{allUsers.length}</span>
            <Users className="w-5 h-5 text-[#7357FF] dark:text-[#22D3EE]" />
          </div>
          <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold mt-1 block">Active on VYRO</span>
        </div>

        {/* Card 2: Active Orders */}
        <div className="bg-white dark:bg-[#111A32] rounded-3xl p-5 border border-[#E1E7F3] dark:border-[#7357FF]/25 shadow-vyro-card">
          <span className="text-xs font-semibold text-[#68738B] dark:text-slate-400">Active Orders</span>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl sm:text-3xl font-extrabold text-[#7357FF] dark:text-[#22D3EE]">{activeCampaigns.length}</span>
            <Sparkles className="w-5 h-5 text-[#7357FF] dark:text-[#22D3EE]" />
          </div>
          <span className="text-[11px] text-[#7357FF] dark:text-[#22D3EE] font-semibold mt-1 block">Delivering live reach</span>
        </div>

        {/* Card 3: Revenue (UGX) */}
        <div className="bg-white dark:bg-[#111A32] rounded-3xl p-5 border border-[#E1E7F3] dark:border-[#7357FF]/25 shadow-vyro-card">
          <span className="text-xs font-semibold text-[#68738B] dark:text-slate-400">Gross Order Spend</span>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-xl sm:text-2xl font-extrabold text-[#EC4899]">
              UGX {totalRevenueUGX.toLocaleString()}
            </span>
            <Coins className="w-5 h-5 text-[#EC4899]" />
          </div>
          <span className="text-[11px] text-[#68738B] dark:text-slate-400 mt-1 block">Processed via Pesapal & Balances</span>
        </div>

        {/* Card 4: Pending Approvals */}
        <div className="bg-white dark:bg-[#111A32] rounded-3xl p-5 border border-[#E1E7F3] dark:border-[#7357FF]/25 shadow-vyro-card">
          <span className="text-xs font-semibold text-[#68738B] dark:text-slate-400">Pending Review</span>
          <div className="mt-2 flex items-baseline justify-between">
            <span className="text-2xl sm:text-3xl font-extrabold text-amber-500">{pendingCampaigns.length}</span>
            <AlertTriangle className="w-5 h-5 text-amber-500" />
          </div>
          <span className="text-[11px] text-amber-600 dark:text-amber-400 font-semibold mt-1 block">Requires manual audit</span>
        </div>
      </div>

      {/* ADMIN NAVIGATION TABS */}
      <div className="flex items-center gap-2 border-b border-[#E1E7F3] dark:border-slate-800 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('moderation')}
          className={`px-4 py-2 rounded-2xl text-xs font-bold transition-all shrink-0 ${
            activeTab === 'moderation'
              ? 'bg-[#7357FF] text-white shadow-sm'
              : 'text-[#68738B] dark:text-slate-400 hover:bg-[#7357FF]/10'
          }`}
        >
          Order Moderation Queue ({pendingCampaigns.length})
        </button>
        <button
          onClick={() => setActiveTab('users')}
          className={`px-4 py-2 rounded-2xl text-xs font-bold transition-all shrink-0 ${
            activeTab === 'users'
              ? 'bg-[#7357FF] text-white shadow-sm'
              : 'text-[#68738B] dark:text-slate-400 hover:bg-[#7357FF]/10'
          }`}
        >
          User Accounts ({allUsers.length})
        </button>
        <button
          onClick={() => setActiveTab('services')}
          className={`px-4 py-2 rounded-2xl text-xs font-bold transition-all shrink-0 ${
            activeTab === 'services'
              ? 'bg-[#7357FF] text-white shadow-sm'
              : 'text-[#68738B] dark:text-slate-400 hover:bg-[#7357FF]/10'
          }`}
        >
          Platform Service Rates
        </button>
        <button
          onClick={() => setActiveTab('ledger')}
          className={`px-4 py-2 rounded-2xl text-xs font-bold transition-all shrink-0 ${
            activeTab === 'ledger'
              ? 'bg-[#7357FF] text-white shadow-sm'
              : 'text-[#68738B] dark:text-slate-400 hover:bg-[#7357FF]/10'
          }`}
        >
          Global Transactions ({allTransactions.length})
        </button>
      </div>

      {/* TAB 1: MODERATION QUEUE */}
      {activeTab === 'moderation' && (
        <div className="bg-white dark:bg-[#111A32] rounded-3xl p-6 border border-[#E1E7F3] dark:border-[#7357FF]/25 shadow-vyro-card">
          <h3 className="text-base font-extrabold text-[#10172A] dark:text-white mb-4">
            Order Moderation & Verification Queue
          </h3>

          {pendingCampaigns.length === 0 ? (
            <div className="py-8 text-center text-xs text-[#68738B] dark:text-slate-400">
              <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
              All submitted orders have been reviewed!
            </div>
          ) : (
            <div className="space-y-3">
              {pendingCampaigns.map((cmp) => (
                <div
                  key={cmp.id}
                  className="p-4 rounded-2xl bg-amber-500/10 border border-amber-300 dark:border-amber-800/40 flex flex-col md:flex-row md:items-center justify-between gap-3"
                >
                  <div className="flex items-start gap-3">
                    <PlatformIcon platform={cmp.platform} size="md" />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-[#10172A] dark:text-white">{cmp.userName || 'Creator'}</span>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-800 dark:text-amber-300 font-bold uppercase">
                          {cmp.platform} · {cmp.goal.replace('_', ' ')}
                        </span>
                      </div>
                      <p className="text-xs text-[#10172A] dark:text-white mt-1 font-medium">{cmp.description}</p>
                      <a
                        href={cmp.destinationUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="text-[11px] text-[#7357FF] dark:text-[#22D3EE] hover:underline inline-flex items-center gap-1 mt-0.5 font-mono"
                      >
                        <span>{cmp.destinationUrl}</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end md:self-center">
                    <span className="text-xs font-extrabold text-[#10172A] dark:text-white mr-2">
                      UGX {cmp.budgetUGX.toLocaleString()}
                    </span>
                    <button
                      onClick={() => handleApproveCampaign(cmp)}
                      className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1 shadow-sm"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Approve</span>
                    </button>
                    <button
                      onClick={() => handleRejectCampaign(cmp)}
                      className="px-3.5 py-1.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 dark:hover:bg-rose-900/50 text-rose-700 dark:text-rose-300 text-xs font-bold flex items-center gap-1 border border-rose-200 dark:border-rose-800"
                    >
                      <X className="w-3.5 h-3.5" />
                      <span>Reject</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: USER DIRECTORY */}
      {activeTab === 'users' && (
        <div className="bg-white dark:bg-[#111A32] rounded-3xl p-6 border border-[#E1E7F3] dark:border-[#7357FF]/25 shadow-vyro-card overflow-x-auto">
          <h3 className="text-base font-extrabold text-[#10172A] dark:text-white mb-4">
            Registered Creators & Organizations
          </h3>

          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-[#E1E7F3] dark:border-slate-800 text-[#68738B] dark:text-slate-400">
                <th className="pb-3 font-semibold">User</th>
                <th className="pb-3 font-semibold">Username</th>
                <th className="pb-3 font-semibold">Role</th>
                <th className="pb-3 font-semibold">VYRO Balance</th>
                <th className="pb-3 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E1E7F3] dark:divide-slate-800">
              {allUsers.map((u) => (
                <tr key={u.id} className="hover:bg-[#F4F7FF] dark:hover:bg-[#15203D]">
                  <td className="py-3 flex items-center gap-2.5">
                    <img
                      src={u.avatarUrl}
                      alt={u.fullName}
                      className="w-8 h-8 rounded-full object-cover"
                    />
                    <div>
                      <p className="font-bold text-[#10172A] dark:text-white">{u.fullName}</p>
                      <p className="text-[10px] text-[#68738B] dark:text-slate-400">{u.email}</p>
                    </div>
                  </td>
                  <td className="py-3 font-mono text-[#68738B] dark:text-slate-400">@{u.username}</td>
                  <td className="py-3">
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                        u.role === 'admin' ? 'bg-[#7357FF]/20 text-[#7357FF] dark:text-[#22D3EE]' : 'bg-slate-200 dark:bg-slate-800 text-[#10172A] dark:text-slate-300'
                      }`}
                    >
                      {u.role}
                    </span>
                  </td>
                  <td className="py-3 font-extrabold text-[#10172A] dark:text-white">
                    UGX {u.balanceUGX.toLocaleString()}
                  </td>
                  <td className="py-3 text-right">
                    <button
                      onClick={() => handleAdjustUserBalance(u)}
                      className="px-2.5 py-1 rounded-xl bg-[#7357FF]/10 hover:bg-[#7357FF]/20 text-[#7357FF] dark:text-[#22D3EE] text-xs font-semibold"
                    >
                      Adjust Credit
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* TAB 3: PLATFORM SERVICE RATES */}
      {activeTab === 'services' && (
        <div className="bg-white dark:bg-[#111A32] rounded-3xl p-6 border border-[#E1E7F3] dark:border-[#7357FF]/25 shadow-vyro-card">
          <h3 className="text-base font-extrabold text-[#10172A] dark:text-white mb-4">
            Platform Service Rates & Minimum Order Thresholds
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {servicesList.map((srv) => (
              <div key={srv.id} className="p-4 rounded-2xl bg-[#F4F7FF] dark:bg-[#0B1020] border border-[#E1E7F3] dark:border-slate-800">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <PlatformIcon platform={srv.platform} size="sm" />
                    <h4 className="font-bold text-sm text-[#10172A] dark:text-white">{srv.name}</h4>
                  </div>
                  <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-500/15 px-2 py-0.5 rounded-full">
                    Active
                  </span>
                </div>
                <p className="text-xs text-[#68738B] dark:text-slate-400 mb-3">{srv.description}</p>
                <div className="grid grid-cols-2 gap-2 text-xs border-t border-[#E1E7F3] dark:border-slate-800 pt-2">
                  <div>
                    <span className="text-[#68738B] dark:text-slate-400">Min Order:</span>
                    <span className="font-bold text-[#10172A] dark:text-white ml-1">UGX {srv.minBudgetUGX.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="text-[#68738B] dark:text-slate-400">Est Rate / 1k:</span>
                    <span className="font-bold text-[#7357FF] dark:text-[#22D3EE] ml-1">UGX {srv.ratePer1kImpressionsUGX}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: GLOBAL TRANSACTIONS */}
      {activeTab === 'ledger' && (
        <div className="bg-white dark:bg-[#111A32] rounded-3xl p-6 border border-[#E1E7F3] dark:border-[#7357FF]/25 shadow-vyro-card overflow-x-auto">
          <h3 className="text-base font-extrabold text-[#10172A] dark:text-white mb-4">
            System Transactions & Ledger
          </h3>

          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-[#E1E7F3] dark:border-slate-800 text-[#68738B] dark:text-slate-400">
                <th className="pb-3 font-semibold">Reference</th>
                <th className="pb-3 font-semibold">User</th>
                <th className="pb-3 font-semibold">Type</th>
                <th className="pb-3 font-semibold">Payment Method</th>
                <th className="pb-3 font-semibold">Amount (UGX)</th>
                <th className="pb-3 font-semibold">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E1E7F3] dark:divide-slate-800">
              {allTransactions.map((t) => (
                <tr key={t.id} className="hover:bg-[#F4F7FF] dark:hover:bg-[#15203D]">
                  <td className="py-2.5 font-mono text-[11px] font-bold text-[#7357FF] dark:text-[#22D3EE]">{t.providerReference}</td>
                  <td className="py-2.5 text-[#10172A] dark:text-white">{t.userName || t.userId}</td>
                  <td className="py-2.5 capitalize text-[#10172A] dark:text-white">{t.type.replace('_', ' ')}</td>
                  <td className="py-2.5 font-semibold text-[#68738B] dark:text-slate-400 uppercase">
                    {t.paymentProvider === 'marzpay' || t.paymentProvider === 'pesapal' ? 'Mobile Money' : t.paymentProvider}
                  </td>
                  <td className="py-2.5 font-extrabold text-[#10172A] dark:text-white">UGX {t.amountUGX.toLocaleString()}</td>
                  <td className="py-2.5">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 uppercase">
                      {t.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
