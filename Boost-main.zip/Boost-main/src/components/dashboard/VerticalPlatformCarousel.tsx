import React from 'react';
import { Platform } from '../../types';
import { CoverFlowSlider } from './CoverFlowSlider';

export interface VerticalPlatformCarouselProps {
  onStartCampaign: (preselectedGoal?: string, preselectedPlatform?: Platform) => void;
  initialPlatform?: Platform;
}

export const VerticalPlatformCarousel: React.FC<VerticalPlatformCarouselProps> = (props) => {
  return <CoverFlowSlider {...props} />;
};

export default VerticalPlatformCarousel;
