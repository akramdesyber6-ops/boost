import { Platform } from '../../types';

export interface PlatformSlide {
  id: Platform;
  name: string;
  category: string;
  headline: string;
  subheadline: string;
  ctaText: string;
  accentColor: string;
  accentGradient: string;
  glowColor: string;
  badgeBg: string;
  badgeText: string;
  startingRate: string;
  tagline: string;
  description?: string;
  tag?: string;
  creatorImage?: string;
  creatorAlt?: string;
  metricLabel?: string;
  metricValue?: string;
  minOrder?: string;
  features?: string[];
}

export const PLATFORM_SLIDES: PlatformSlide[] = [
  {
    id: 'instagram',
    name: 'Instagram',
    category: 'Followers, Likes & Views',
    headline: 'Followers, Likes & Reels',
    subheadline: 'Instant explore boost & active growth',
    ctaText: 'Boost on Instagram',
    accentColor: '#EC4899',
    accentGradient: 'linear-gradient(135deg, #fdf497 0%, #fd5949 45%, #d6249f 70%, #285AEB 100%)',
    glowColor: 'rgba(236, 72, 153, 0.35)',
    badgeBg: 'bg-pink-500/10 dark:bg-pink-500/20',
    badgeText: 'text-pink-600 dark:text-pink-400',
    startingRate: 'UGX 1,900',
    tagline: 'Instant Start · Non-Drop',
  },
  {
    id: 'tiktok',
    name: 'TikTok',
    category: 'Followers, Views & Likes',
    headline: 'FYP Views & Followers',
    subheadline: 'Push sounds & videos into trending FYP',
    ctaText: 'Boost on TikTok',
    accentColor: '#22D3EE',
    accentGradient: 'linear-gradient(135deg, #00F2FE 0%, #4FACFE 50%, #7357FF 100%)',
    glowColor: 'rgba(34, 211, 238, 0.35)',
    badgeBg: 'bg-cyan-500/10 dark:bg-cyan-500/20',
    badgeText: 'text-cyan-600 dark:text-cyan-400',
    startingRate: 'UGX 950',
    tagline: 'Instant Start · High Retention',
  },
  {
    id: 'youtube',
    name: 'YouTube',
    category: 'Subscribers, Views & Watchtime',
    headline: 'Watch Hours & Subscribers',
    subheadline: 'Monetization-safe views & active subs',
    ctaText: 'Boost on YouTube',
    accentColor: '#FF0000',
    accentGradient: 'linear-gradient(135deg, #FF0000 0%, #DC2626 100%)',
    glowColor: 'rgba(255, 0, 0, 0.35)',
    badgeBg: 'bg-red-500/10 dark:bg-red-500/20',
    badgeText: 'text-red-600 dark:text-red-400',
    startingRate: 'UGX 3,800',
    tagline: 'Monetization Safe · Guaranteed',
  },
  {
    id: 'facebook',
    name: 'Facebook',
    category: 'Page Likes, Followers & Views',
    headline: 'Page Likes & Followers',
    subheadline: 'Authentic page growth & post engagement',
    ctaText: 'Boost on Facebook',
    accentColor: '#1877F2',
    accentGradient: 'linear-gradient(135deg, #1877F2 0%, #0D65D9 100%)',
    glowColor: 'rgba(24, 119, 242, 0.35)',
    badgeBg: 'bg-blue-500/10 dark:bg-blue-500/20',
    badgeText: 'text-blue-600 dark:text-blue-400',
    startingRate: 'UGX 1,900',
    tagline: 'Real Profiles · Stable Growth',
  },
  {
    id: 'x',
    name: 'X (Twitter)',
    category: 'Followers, Reposts & Views',
    headline: 'Impressions & Followers',
    subheadline: 'Viral reposts & trending amplification',
    ctaText: 'Boost on X',
    accentColor: '#7357FF',
    accentGradient: 'linear-gradient(135deg, #0B1020 0%, #7357FF 100%)',
    glowColor: 'rgba(115, 87, 255, 0.35)',
    badgeBg: 'bg-purple-500/10 dark:bg-purple-500/20',
    badgeText: 'text-purple-600 dark:text-purple-400',
    startingRate: 'UGX 2,500',
    tagline: 'Fast Delivery · Non-Drop',
  },
];
