import React from 'react';
import { ChevronUp, ChevronDown, Pause, Play } from 'lucide-react';
import { PlatformSlide } from './carouselData';

interface CarouselIndicatorsProps {
  slides: PlatformSlide[];
  currentIndex: number;
  onSelectIndex: (index: number) => void;
  onNext: () => void;
  onPrev: () => void;
  isPaused: boolean;
  onTogglePause: () => void;
}

export const CarouselIndicators: React.FC<CarouselIndicatorsProps> = ({
  slides,
  currentIndex,
  onSelectIndex,
  onNext,
  onPrev,
  isPaused,
  onTogglePause,
}) => {
  const currentSlide = slides[currentIndex];

  return (
    <div className="flex flex-row md:flex-col items-center justify-between gap-2 p-1.5 rounded-2xl bg-white/60 dark:bg-[#111A32]/60 backdrop-blur-md border border-[#E1E7F3] dark:border-slate-800 shadow-sm">
      {/* Up Button */}
      <button
        onClick={onPrev}
        aria-label="Previous platform slide"
        className="w-7 h-7 rounded-xl flex items-center justify-center text-[#68738B] hover:text-[#10172A] dark:hover:text-white hover:bg-white dark:hover:bg-slate-800 transition-colors"
      >
        <ChevronUp className="w-4 h-4 hidden md:block" />
        <span className="md:hidden text-xs font-bold">‹</span>
      </button>

      {/* Vertical Progress Pills */}
      <div className="flex flex-row md:flex-col items-center gap-1.5 my-1">
        {slides.map((slide, idx) => {
          const isActive = idx === currentIndex;
          return (
            <button
              key={slide.id}
              onClick={() => onSelectIndex(idx)}
              aria-label={`Go to slide ${idx + 1}: ${slide.name}`}
              className={`transition-all duration-300 rounded-full ${
                isActive
                  ? 'w-5 h-2 md:w-2 md:h-5 shadow-sm'
                  : 'w-2 h-2 rounded-full bg-[#68738B]/30 hover:bg-[#68738B]/60'
              }`}
              style={{
                backgroundColor: isActive ? currentSlide.accentColor : undefined,
              }}
            />
          );
        })}
      </div>

      {/* Down Button */}
      <button
        onClick={onNext}
        aria-label="Next platform slide"
        className="w-7 h-7 rounded-xl flex items-center justify-center text-[#68738B] hover:text-[#10172A] dark:hover:text-white hover:bg-white dark:hover:bg-slate-800 transition-colors"
      >
        <ChevronDown className="w-4 h-4 hidden md:block" />
        <span className="md:hidden text-xs font-bold">›</span>
      </button>

      {/* Pause/Play Toggle */}
      <button
        onClick={onTogglePause}
        aria-label={isPaused ? 'Resume auto slide' : 'Pause auto slide'}
        title={isPaused ? 'Resume auto-slideshow' : 'Pause auto-slideshow'}
        className="w-7 h-7 rounded-xl flex items-center justify-center text-[#68738B] hover:text-[#7357FF] dark:hover:text-[#22D3EE] hover:bg-white dark:hover:bg-slate-800 transition-colors"
      >
        {isPaused ? <Play className="w-3 h-3 fill-current" /> : <Pause className="w-3 h-3 fill-current" />}
      </button>
    </div>
  );
};
