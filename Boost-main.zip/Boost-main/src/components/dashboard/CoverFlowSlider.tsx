import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Platform } from '../../types';
import { PLATFORM_SLIDES, PlatformSlide } from './carouselData';
import { PlatformIcon } from '../common/BrandIcons';
import { ArrowRight, Zap, ShieldCheck } from 'lucide-react';

interface CoverFlowSliderProps {
  onStartCampaign: (preselectedGoal?: string, preselectedPlatform?: Platform) => void;
  initialPlatform?: Platform;
}

/**
 * Clean, modern centerpiece displaying the glowing platform brand icon
 * with authentic brand gradients and ambient lighting.
 */
const PlatformCenterpiece: React.FC<{ slide: PlatformSlide }> = ({ slide }) => {
  return (
    <div className="relative w-full h-[105px] xs:h-[115px] sm:h-[135px] rounded-2xl overflow-hidden my-2 border border-black/5 dark:border-white/10 flex items-center justify-center group shadow-inner select-none">
      {/* Background with authentic brand colors */}
      <div 
        className="absolute inset-0 transition-transform duration-700 group-hover:scale-105"
        style={{
          background:
            slide.id === 'instagram'
              ? 'radial-gradient(circle at 30% 107%, #fdf497 0%, #fdf497 5%, #fd5949 45%, #d6249f 65%, #285AEB 100%)'
              : slide.id === 'youtube'
              ? 'linear-gradient(135deg, #FF1E1E 0%, #D80000 60%, #990000 100%)'
              : slide.id === 'facebook'
              ? 'linear-gradient(135deg, #2B87FF 0%, #1877F2 60%, #0D5AC4 100%)'
              : slide.id === 'tiktok'
              ? 'linear-gradient(145deg, #0A0D14 0%, #151B28 60%, #0B0E17 100%)'
              : 'linear-gradient(135deg, #1D2230 0%, #0F141E 60%, #080A10 100%)',
        }}
      />

      {/* Decorative ambient radial highlights */}
      <div className="absolute inset-0 bg-radial from-white/20 via-transparent to-black/25 pointer-events-none" />

      {/* Specific brand glow orbs */}
      {slide.id === 'tiktok' && (
        <>
          <div className="absolute top-2 right-4 w-14 h-14 rounded-full bg-[#00F2FE]/25 blur-xl pointer-events-none" />
          <div className="absolute bottom-4 left-4 w-14 h-14 rounded-full bg-[#FE2C55]/25 blur-xl pointer-events-none" />
        </>
      )}

      {/* Large Centerpiece Platform Icon */}
      <div className="relative z-10 flex items-center justify-center transition-transform duration-500 group-hover:scale-110">
        {slide.id === 'instagram' && (
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="white"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="w-12 h-12 xs:w-13 xs:h-13 sm:w-15 sm:h-15 text-white drop-shadow-[0_8px_16px_rgba(0,0,0,0.35)]"
          >
            <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
            <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
            <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
          </svg>
        )}
        {slide.id === 'tiktok' && (
          <svg
            viewBox="0 0 24 24"
            fill="white"
            className="w-12 h-12 xs:w-13 xs:h-13 sm:w-15 sm:h-15 text-white drop-shadow-[0_8px_20px_rgba(0,242,254,0.45)]"
          >
            <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64c.29 0 .58.04.85.12V9.4a6.33 6.33 0 0 0-.85-.06A6.34 6.34 0 0 0 3.1 15.68a6.34 6.34 0 0 0 10.74 4.53 6.34 6.34 0 0 0 1.95-4.54V9.08c1.33.95 2.94 1.52 4.69 1.58V7.22a4.78 4.78 0 0 1-.89-.53z" />
          </svg>
        )}
        {slide.id === 'youtube' && (
          <svg
            viewBox="0 0 24 24"
            fill="white"
            className="w-14 h-14 xs:w-15 xs:h-15 sm:w-17 sm:h-17 text-white drop-shadow-[0_8px_18px_rgba(0,0,0,0.35)]"
          >
            <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
          </svg>
        )}
        {slide.id === 'facebook' && (
          <svg
            viewBox="0 0 24 24"
            fill="white"
            className="w-12 h-12 xs:w-13 xs:h-13 sm:w-15 sm:h-15 text-white drop-shadow-[0_8px_18px_rgba(0,0,0,0.35)]"
          >
            <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
          </svg>
        )}
        {slide.id === 'x' && (
          <svg
            viewBox="0 0 24 24"
            fill="white"
            className="w-11 h-11 xs:w-12 xs:h-12 sm:w-14 sm:h-14 text-white drop-shadow-[0_8px_18px_rgba(0,0,0,0.45)]"
          >
            <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
          </svg>
        )}
      </div>
    </div>
  );
};

export const CoverFlowSlider: React.FC<CoverFlowSliderProps> = ({
  onStartCampaign,
  initialPlatform = 'instagram',
}) => {
  const initialIdx = PLATFORM_SLIDES.findIndex((s) => s.id === initialPlatform);
  const [activeIndex, setActiveIndex] = useState<number>(initialIdx !== -1 ? initialIdx : 0);
  const [isHovered, setIsHovered] = useState<boolean>(false);
  const [isMobile, setIsMobile] = useState<boolean>(false);

  const containerRef = useRef<HTMLDivElement | null>(null);
  const touchStartX = useRef<number | null>(null);
  const touchStartY = useRef<number | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const count = PLATFORM_SLIDES.length;
  const activeSlide: PlatformSlide = PLATFORM_SLIDES[activeIndex];

  // Screen resize listener for responsive 3D spacing
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 640);
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const goToNext = useCallback(() => {
    setActiveIndex((prev) => (prev + 1) % count);
  }, [count]);

  const goToPrev = useCallback(() => {
    setActiveIndex((prev) => (prev - 1 + count) % count);
  }, [count]);

  const goToIndex = useCallback((idx: number) => {
    setActiveIndex(idx);
  }, []);

  // Decreased auto-advance speed: rotates gently every 7.5 seconds
  useEffect(() => {
    if (isHovered) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    timerRef.current = setInterval(() => {
      goToNext();
    }, 7500);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [goToNext, isHovered]);

  // Keyboard navigation
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowRight') {
      e.preventDefault();
      goToNext();
    } else if (e.key === 'ArrowLeft') {
      e.preventDefault();
      goToPrev();
    }
  };

  // Touch swipe support
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
    touchStartY.current = e.touches[0].clientY;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartX.current === null) return;
    const touchEndX = e.changedTouches[0].clientX;
    const touchEndY = e.changedTouches[0].clientY;
    const deltaX = touchStartX.current - touchEndX;
    const deltaY = (touchStartY.current || 0) - touchEndY;

    // Only swipe if horizontal drag is dominant
    if (Math.abs(deltaX) > Math.abs(deltaY) && Math.abs(deltaX) > 40) {
      if (deltaX > 0) {
        goToNext();
      } else {
        goToPrev();
      }
    }
    touchStartX.current = null;
    touchStartY.current = null;
  };

  // Helper to calculate circular shortest distance from activeIndex
  const getOffset = (index: number): number => {
    let diff = (index - activeIndex) % count;
    if (diff > count / 2) diff -= count;
    if (diff < -count / 2) diff += count;
    return diff;
  };

  return (
    <div
      id="3d-coverflow-slider"
      ref={containerRef}
      tabIndex={0}
      onKeyDown={handleKeyDown}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      aria-label="3D Floating Cover Flow Platform Promotions"
      className="relative w-full py-1 sm:py-2 select-none outline-none overflow-hidden"
      style={{ touchAction: 'pan-y' }}
    >
      {/* Background ambient lighting aura for active platform */}
      <div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 rounded-full blur-[120px] pointer-events-none transition-colors duration-1000 opacity-25 -z-10"
        style={{ backgroundColor: activeSlide.accentColor }}
      />

      {/* Floating 3D Cover Flow Stage */}
      <div 
        className="relative w-full h-[290px] xs:h-[305px] sm:h-[340px] flex items-center justify-center overflow-visible py-1 sm:py-2"
        style={{ perspective: '1100px' }}
      >
        <div 
          className="relative w-full h-full flex items-center justify-center"
          style={{ transformStyle: 'preserve-3d' }}
        >
          {PLATFORM_SLIDES.map((slide, index) => {
            const offset = getOffset(index);
            const isActive = offset === 0;
            const isVisible = Math.abs(offset) <= 2;

            if (!isVisible) return null;

            // Compute exact 3D positioning for Cover Flow
            const spacing = isMobile ? 80 : 185;
            const distantSpacing = isMobile ? 140 : 310;
            
            let translateX = 0;
            let translateZ = 0;
            let rotateY = 0;
            let scale = 1;
            let opacity = 1;
            let zIndex = 30;

            if (isActive) {
              translateX = 0;
              translateZ = 60;
              rotateY = 0;
              scale = 1;
              opacity = 1;
              zIndex = 30;
            } else if (offset === 1) {
              translateX = spacing;
              translateZ = -60;
              rotateY = -34;
              scale = 0.86;
              opacity = 0.72;
              zIndex = 20;
            } else if (offset === -1) {
              translateX = -spacing;
              translateZ = -60;
              rotateY = 34;
              scale = 0.86;
              opacity = 0.72;
              zIndex = 20;
            } else if (offset > 1) {
              translateX = distantSpacing;
              translateZ = -140;
              rotateY = -46;
              scale = 0.74;
              opacity = 0.28;
              zIndex = 10;
            } else if (offset < -1) {
              translateX = -distantSpacing;
              translateZ = -140;
              rotateY = 46;
              scale = 0.74;
              opacity = 0.28;
              zIndex = 10;
            }

            return (
              <div
                key={slide.id}
                id={`coverflow-card-${slide.id}`}
                onClick={() => {
                  if (isActive) {
                    onStartCampaign('content_reach', slide.id);
                  } else {
                    goToIndex(index);
                  }
                }}
                className={`absolute w-[80vw] max-w-[250px] xs:max-w-[270px] sm:w-[310px] sm:max-w-[330px] h-[275px] xs:h-[290px] sm:h-[325px] rounded-3xl p-3 xs:p-3.5 sm:p-4 cursor-pointer transition-all duration-700 ease-out flex flex-col justify-between ${
                  isActive
                    ? 'bg-white dark:bg-[#162244] border-2 shadow-2xl'
                    : 'bg-white/90 dark:bg-[#111A32]/90 border border-[#E1E7F3] dark:border-slate-800 shadow-lg hover:opacity-90'
                }`}
                style={{
                  transform: `translateX(${translateX}px) translateZ(${translateZ}px) rotateY(${rotateY}deg) scale(${scale})`,
                  transformStyle: 'preserve-3d',
                  zIndex,
                  opacity,
                  borderColor: isActive ? slide.accentColor : undefined,
                  boxShadow: isActive
                    ? `0 20px 40px -10px rgba(0,0,0,0.16), 0 0 30px -6px ${slide.glowColor}`
                    : undefined,
                }}
              >
                {/* Floating Ground Shadow for Active Card */}
                {isActive && (
                  <div 
                    className="absolute -bottom-4 left-1/2 -translate-x-1/2 w-40 h-3 rounded-full blur-md pointer-events-none opacity-50"
                    style={{ backgroundColor: slide.accentColor }}
                  />
                )}

                {/* Top of Card: Brand Icon, Name & Starting Price */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 sm:gap-2 min-w-0">
                    <div
                      className="w-7 h-7 sm:w-8 sm:h-8 rounded-xl flex items-center justify-center text-white shadow-xs shrink-0"
                      style={{
                        background:
                          slide.id === 'instagram'
                            ? slide.accentGradient
                            : slide.id === 'youtube'
                            ? '#FF0000'
                            : slide.id === 'facebook'
                            ? '#1877F2'
                            : slide.id === 'tiktok'
                            ? '#000000'
                            : '#0B1020',
                      }}
                    >
                      <PlatformIcon platform={slide.id} size="sm" />
                    </div>
                    <div className="min-w-0">
                      <h3 className="text-xs font-black text-[#10172A] dark:text-white leading-tight truncate">
                        {slide.name}
                      </h3>
                      <p className="text-[9px] sm:text-[10px] text-[#68738B] dark:text-slate-400 font-medium truncate">
                        {slide.category}
                      </p>
                    </div>
                  </div>

                  <span
                    className="text-[8px] sm:text-[9px] font-extrabold px-2 py-0.5 rounded-full shrink-0 ml-1"
                    style={{
                      backgroundColor: `${slide.accentColor}18`,
                      color: slide.accentColor,
                    }}
                  >
                    From {slide.startingRate}
                  </span>
                </div>

                {/* Centerpiece: Platform Brand Glow */}
                <PlatformCenterpiece slide={slide} />

                {/* Card Bottom: Concise Headline & Direct CTA */}
                <div>
                  <div className="flex items-center justify-between gap-1 mb-2">
                    <span className="inline-flex items-center gap-1 text-[9px] sm:text-[10px] font-bold text-[#10172A] dark:text-slate-200 truncate">
                      <Zap className="w-3 h-3 text-amber-500 shrink-0" />
                      {slide.tagline}
                    </span>
                    <span className="inline-flex items-center gap-0.5 text-[8px] sm:text-[9px] font-bold text-emerald-600 dark:text-emerald-400 shrink-0">
                      <ShieldCheck className="w-3 h-3" />
                      Verified
                    </span>
                  </div>

                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      onStartCampaign('content_reach', slide.id);
                    }}
                    className={`w-full py-2 sm:py-2.5 px-3 rounded-full text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer min-h-[36px] sm:min-h-[38px] ${
                      isActive
                        ? 'text-white shadow-vyro-glow hover:opacity-95 active:scale-98'
                        : 'bg-[#F4F7FF] dark:bg-slate-800 text-[#10172A] dark:text-slate-200 hover:bg-slate-200'
                    }`}
                    style={{
                      background: isActive
                        ? 'linear-gradient(110deg, #5B4BFF 0%, #8B5CF6 42%, #EC4899 75%, #FF8A65 100%)'
                        : undefined,
                    }}
                  >
                    <span>{isActive ? `Boost on ${slide.name}` : `Select ${slide.name}`}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Mobile Dot Navigation Indicators */}
      <div className="flex items-center justify-center gap-2 pt-1 pb-2">
        {PLATFORM_SLIDES.map((slide, idx) => (
          <button
            key={slide.id}
            type="button"
            onClick={() => goToIndex(idx)}
            aria-label={`Go to ${slide.name}`}
            className={`transition-all duration-300 rounded-full cursor-pointer ${
              activeIndex === idx
                ? 'w-6 h-2 bg-[#7357FF]'
                : 'w-2 h-2 bg-slate-300 hover:bg-slate-400'
            }`}
          />
        ))}
      </div>
    </div>
  );
};

export default CoverFlowSlider;
