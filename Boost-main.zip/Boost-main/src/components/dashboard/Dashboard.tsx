import React from 'react';
import { User, Campaign, Platform } from '../../types';
import { PlatformIcon } from '../common/BrandIcons';
import { CoverFlowSlider } from './CoverFlowSlider';
import { 
  Wallet, 
  Plus, 
  ArrowRight, 
  Users, 
  Heart, 
  Eye, 
  MessageCircle, 
  CheckCircle2, 
  Sparkles,
  Flame
} from 'lucide-react';

interface DashboardProps {
  currentUser: User;
  campaigns: Campaign[];
  onStartCampaign: (preselectedGoal?: string, preselectedPlatform?: Platform) => void;
  onOpenWallet: () => void;
  onViewAllCampaigns: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({
  currentUser,
  campaigns,
  onStartCampaign,
  onOpenWallet,
  onViewAllCampaigns,
}) => {
  const userCampaigns = campaigns.filter((c) => c.userId === currentUser.id);

  return (
    <div className="relative min-h-[85vh] flex flex-col justify-start overflow-hidden bg-[#F4F7FF]">
      {/* Centered Mobile/Responsive Content Container */}
      <div className="w-full max-w-4xl mx-auto px-4 sm:px-6 pt-2 pb-8 space-y-4 sm:space-y-5">
        
        {/* 3D COVER FLOW SLIDER */}
        <CoverFlowSlider
          onStartCampaign={onStartCampaign}
          initialPlatform="instagram"
        />

        {/* BALANCE CARD */}
        <div 
          id="dashboard-balance-card"
          className="w-full bg-white rounded-3xl p-5 sm:p-6 shadow-vyro-card border border-[#E1E7F3] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
        >
          <div>
            <p className="text-xs font-medium text-[#68738B]">
              Your VYRO balance
            </p>
            <h2 className="text-2xl sm:text-3xl font-black text-[#10172A] tracking-tight mt-0.5">
              UGX {currentUser.balanceUGX.toLocaleString()}
            </h2>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-[11px] text-emerald-600 font-semibold flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" />
                <span>Available to boost</span>
              </span>
              <span className="text-slate-300">·</span>
              <span className="text-[11px] text-[#68738B]">
                Pesapal MoMo Ready
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              id="balance-add-funds-btn"
              onClick={onOpenWallet}
              className="flex-1 sm:flex-none py-2.5 px-5 rounded-full bg-[#7357FF]/10 hover:bg-[#7357FF]/20 text-[#7357FF] text-xs font-extrabold transition-all flex items-center justify-center gap-1.5 border border-[#7357FF]/20 active:scale-95 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5 stroke-[3]" />
              <span>Add funds</span>
            </button>
            <button
              onClick={() => onStartCampaign()}
              className="flex-1 sm:flex-none py-2.5 px-5 rounded-full text-white text-xs font-bold shadow-vyro-glow hover:opacity-95 transition-all flex items-center justify-center gap-1.5 cursor-pointer active:scale-95"
              style={{
                background: 'linear-gradient(110deg, #5B4BFF 0%, #8B5CF6 42%, #EC4899 75%, #FF8A65 100%)',
              }}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>New Order</span>
            </button>
          </div>
        </div>

        {/* CATEGORIES SECTION: "What do you want to boost?" (2x2 Grid) */}
        <div className="w-full">
          <div className="flex items-center justify-between mb-3 px-1">
            <h3 className="text-sm sm:text-base font-extrabold text-[#10172A]">
              What do you want to boost?
            </h3>
            <span className="text-xs text-[#68738B]">
              Select category to start
            </span>
          </div>

          <div className="bg-white rounded-3xl border border-[#E1E7F3] shadow-vyro-card overflow-hidden grid grid-cols-2 divide-x divide-y divide-[#E1E7F3]">
            {/* Box 1: Followers */}
            <button
              onClick={() => onStartCampaign('audience_growth')}
              className="p-4 sm:p-5 flex items-center gap-3 text-left hover:bg-[#F4F7FF] transition-colors group cursor-pointer"
            >
              <div className="w-10 h-10 rounded-2xl bg-[#7357FF]/10 text-[#7357FF] flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
                <Users className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs sm:text-sm font-bold text-[#10172A] block">
                  Followers
                </span>
                <span className="text-[10px] text-[#68738B]">
                  Targeted profiles
                </span>
              </div>
            </button>

            {/* Box 2: Likes */}
            <button
              onClick={() => onStartCampaign('engagement')}
              className="p-4 sm:p-5 flex items-center gap-3 text-left hover:bg-[#F4F7FF] transition-colors group cursor-pointer"
            >
              <div className="w-10 h-10 rounded-2xl bg-[#EC4899]/10 text-[#EC4899] flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
                <Heart className="w-5 h-5 fill-[#EC4899]" />
              </div>
              <div>
                <span className="text-xs sm:text-sm font-bold text-[#10172A] block">
                  Likes
                </span>
                <span className="text-[10px] text-[#68738B]">
                  Post resonance
                </span>
              </div>
            </button>

            {/* Box 3: Views */}
            <button
              onClick={() => onStartCampaign('content_reach')}
              className="p-4 sm:p-5 flex items-center gap-3 text-left hover:bg-[#F4F7FF] transition-colors group cursor-pointer"
            >
              <div className="w-10 h-10 rounded-2xl bg-[#22D3EE]/15 text-cyan-600 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
                <Eye className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs sm:text-sm font-bold text-[#10172A] block">
                  Views
                </span>
                <span className="text-[10px] text-[#68738B]">
                  High-retention
                </span>
              </div>
            </button>

            {/* Box 4: Comments */}
            <button
              onClick={() => onStartCampaign('brand_awareness')}
              className="p-4 sm:p-5 flex items-center gap-3 text-left hover:bg-[#F4F7FF] transition-colors group cursor-pointer"
            >
              <div className="w-10 h-10 rounded-2xl bg-[#FF8A65]/15 text-[#FF8A65] flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform">
                <MessageCircle className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs sm:text-sm font-bold text-[#10172A] block">
                  Comments
                </span>
                <span className="text-[10px] text-[#68738B]">
                  Community replies
                </span>
              </div>
            </button>
          </div>
        </div>

        {/* ORDERS CARD: LIST OR CLEAN REALTIME EMPTY STATE */}
        {userCampaigns.length > 0 ? (
          <div className="w-full bg-white rounded-3xl p-5 border border-[#E1E7F3] shadow-vyro-card">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Flame className="w-4 h-4 text-[#EC4899]" />
                <span className="text-xs font-extrabold text-[#10172A]">
                  Active Orders ({userCampaigns.length})
                </span>
              </div>
              <button
                onClick={onViewAllCampaigns}
                className="text-[11px] font-bold text-[#7357FF] hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span>View All Orders</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            <div className="space-y-2.5">
              {userCampaigns.slice(0, 3).map((cmp) => (
                <div
                  key={cmp.id}
                  className="p-3.5 rounded-2xl bg-[#F4F7FF] flex items-center justify-between text-xs border border-[#E1E7F3]"
                >
                  <div className="flex items-center gap-3">
                    <PlatformIcon platform={cmp.platform} size="sm" />
                    <div>
                      <p className="font-bold text-[#10172A] capitalize">
                        {cmp.platform} · {cmp.goal.replace('_', ' ')}
                      </p>
                      <p className="text-[10px] text-[#68738B]">
                        {cmp.impressionsDelivered.toLocaleString()} / {cmp.targetImpressions.toLocaleString()} views delivered ({cmp.progressPercentage}%)
                      </p>
                    </div>
                  </div>

                  <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                    cmp.status === 'active'
                      ? 'bg-emerald-500/15 text-emerald-600'
                      : cmp.status === 'completed'
                      ? 'bg-blue-500/15 text-blue-600'
                      : 'bg-amber-500/15 text-amber-600'
                  }`}>
                    {cmp.status.replace('_', ' ')}
                  </span>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="w-full bg-white rounded-3xl p-6 border border-[#E1E7F3] shadow-vyro-card text-center">
            <div className="w-12 h-12 mx-auto rounded-2xl bg-[#7357FF]/10 text-[#7357FF] flex items-center justify-center mb-3">
              <Sparkles className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-extrabold text-[#10172A]">No orders placed yet</h3>
            <p className="text-xs text-[#68738B] max-w-sm mx-auto mt-1 mb-4">
              Select a growth goal above or start a custom order to boost your video, followers, or brand reach.
            </p>
            <button
              onClick={() => onStartCampaign()}
              className="px-5 py-2.5 rounded-full text-xs font-bold text-white shadow-vyro-glow inline-flex items-center gap-1.5 cursor-pointer"
              style={{
                background: 'linear-gradient(110deg, #5B4BFF 0%, #8B5CF6 42%, #EC4899 75%, #FF8A65 100%)',
              }}
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Create Your First Order</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
