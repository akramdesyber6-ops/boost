import React from 'react';
import { PlatformSlide } from './carouselData';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowRight, Sparkles, CheckCircle2 } from 'lucide-react';

interface PromotionOverlayProps {
  slide: PlatformSlide;
  direction: number;
  onPromote: () => void;
  prefersReducedMotion?: boolean;
}

export const PromotionOverlay: React.FC<PromotionOverlayProps> = ({
  slide,
  direction,
  onPromote,
  prefersReducedMotion = false,
}) => {
  return (
    <div className="relative z-20 w-full max-w-[290px] sm:max-w-[310px]">
      <AnimatePresence initial={false} custom={direction} mode="wait">
        <motion.div
          key={slide.id}
          custom={direction}
          initial={{
            opacity: 0,
            y: prefersReducedMotion ? 0 : direction > 0 ? 20 : -20,
            scale: prefersReducedMotion ? 1 : 0.98,
          }}
          animate={{
            opacity: 1,
            y: 0,
            scale: 1,
            transition: {
              duration: 0.65,
              ease: [0.16, 1, 0.3, 1],
            },
          }}
          exit={{
            opacity: 0,
            y: prefersReducedMotion ? 0 : direction > 0 ? -20 : 20,
            scale: prefersReducedMotion ? 1 : 0.98,
            transition: {
              duration: 0.45,
            },
          }}
          className="bg-white/95 dark:bg-[#111A32]/95 backdrop-blur-xl rounded-3xl p-4 sm:p-5 shadow-vyro-card border border-[#E1E7F3] dark:border-[#7357FF]/40 text-[#10172A] dark:text-white"
        >
          {/* Tag & Pulse Header */}
          <div className="flex items-center justify-between gap-2 mb-2">
            <div className="flex items-center gap-1.5">
              <span
                className="w-2 h-2 rounded-full animate-ping shrink-0"
                style={{ backgroundColor: slide.accentColor }}
              />
              <span className="text-[10px] font-black uppercase tracking-wider text-[#68738B] dark:text-slate-300">
                {slide.tag}
              </span>
            </div>

            <span
              className="text-[9px] font-extrabold uppercase px-2 py-0.5 rounded-full"
              style={{
                backgroundColor: `${slide.accentColor}18`,
                color: slide.accentColor,
              }}
            >
              Active Boost
            </span>
          </div>

          {/* Headline */}
          <h3 className="text-sm sm:text-base font-black text-[#10172A] dark:text-white leading-tight tracking-tight">
            {slide.headline}
          </h3>

          {/* Subheadline description */}
          <p className="text-[11px] text-[#68738B] dark:text-slate-300 leading-snug mt-1.5">
            "{slide.subheadline}"
          </p>

          {/* Key Feature checklist */}
          <div className="mt-3 space-y-1">
            {slide.features.slice(0, 2).map((feat, i) => (
              <div key={i} className="flex items-center gap-1.5 text-[10px] text-[#68738B] dark:text-slate-400">
                <CheckCircle2 className="w-3 h-3 text-emerald-500 shrink-0" />
                <span className="truncate">{feat}</span>
              </div>
            ))}
          </div>

          {/* Gradient Action Button */}
          <button
            id={`promo-cta-btn-${slide.id}`}
            onClick={onPromote}
            className="mt-3.5 w-full py-2.5 px-4 rounded-full text-white text-xs font-extrabold shadow-vyro-glow hover:opacity-95 active:scale-98 transition-all flex items-center justify-center gap-2 group cursor-pointer"
            style={{
              background: 'linear-gradient(110deg, #5B4BFF 0%, #8B5CF6 42%, #EC4899 75%, #FF8A65 100%)',
            }}
          >
            <span>{slide.ctaText}</span>
            <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
          </button>
        </motion.div>
      </AnimatePresence>
    </div>
  );
};
