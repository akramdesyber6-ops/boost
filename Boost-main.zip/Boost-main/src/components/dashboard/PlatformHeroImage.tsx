import React from 'react';
import { PlatformSlide } from './carouselData';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles } from 'lucide-react';

interface PlatformHeroImageProps {
  slide: PlatformSlide;
  direction: number; // 1 for down, -1 for up
  prefersReducedMotion?: boolean;
}

export const PlatformHeroImage: React.FC<PlatformHeroImageProps> = ({
  slide,
  direction,
  prefersReducedMotion = false,
}) => {
  // Variants for vertical slide-one-by-one animation (600-900ms)
  const variants: any = {
    enter: (dir: number) => ({
      y: prefersReducedMotion ? 0 : dir > 0 ? 50 : -50,
      opacity: 0,
      scale: prefersReducedMotion ? 1 : 0.95,
      filter: 'blur(4px)',
    }),
    center: {
      y: 0,
      opacity: 1,
      scale: 1,
      filter: 'blur(0px)',
      transition: {
        y: { type: 'spring', stiffness: 260, damping: 28, mass: 0.9 },
        opacity: { duration: 0.7, ease: [0.16, 1, 0.3, 1] },
        scale: { duration: 0.7, ease: [0.16, 1, 0.3, 1] },
        filter: { duration: 0.5 },
      },
    },
    exit: (dir: number) => ({
      y: prefersReducedMotion ? 0 : dir > 0 ? -50 : 50,
      opacity: 0,
      scale: prefersReducedMotion ? 1 : 0.95,
      filter: 'blur(4px)',
      transition: {
        y: { duration: 0.6, ease: [0.32, 0, 0.67, 0] },
        opacity: { duration: 0.5 },
        scale: { duration: 0.6 },
        filter: { duration: 0.4 },
      },
    }),
  };

  return (
    <div className="relative w-full h-[260px] sm:h-[300px] md:h-[330px] rounded-3xl sm:rounded-[36px] overflow-hidden flex items-end justify-center bg-gradient-to-b from-white/40 via-transparent to-black/30 dark:from-slate-900/40 dark:to-black/60 border border-white/60 dark:border-slate-700/40 shadow-inner">
      {/* Dynamic Background Ambient Aura */}
      <motion.div
        key={`glow-${slide.id}`}
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 0.55, scale: 1 }}
        exit={{ opacity: 0, scale: 0.8 }}
        transition={{ duration: 0.9 }}
        className="absolute -top-10 -right-10 w-48 sm:w-64 h-48 sm:h-64 rounded-full blur-3xl pointer-events-none"
        style={{
          background: `radial-gradient(circle, ${slide.accentColor} 0%, transparent 70%)`,
        }}
      />

      {/* Decorative Grid / Tech Ring */}
      <div className="absolute inset-0 bg-[radial-gradient(#7357FF_1px,transparent_1px)] [background-size:16px_16px] opacity-20 pointer-events-none" />

      {/* Slide Image with Smooth Vertical Transition */}
      <AnimatePresence initial={false} custom={direction} mode="wait">
        <motion.div
          key={slide.id}
          custom={direction}
          variants={variants}
          initial="enter"
          animate="center"
          exit="exit"
          className="absolute inset-0 w-full h-full flex items-end justify-center"
        >
          {/* Creator Image with soft edge gradients */}
          <div className="relative w-full h-full">
            <img
              src={slide.creatorImage}
              alt={slide.creatorAlt}
              className="w-full h-full object-cover object-top filter contrast-[1.04] brightness-95"
              loading="eager"
            />

            {/* Seamless gradient fades: bottom vignette, top light vignette, side feather */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#0B1020]/80 via-transparent to-transparent pointer-events-none" />
            <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-[#0B1020]/90 via-[#0B1020]/40 to-transparent pointer-events-none" />
            <div className="absolute inset-y-0 left-0 w-16 bg-gradient-to-r from-white/20 dark:from-[#0B1020]/40 to-transparent pointer-events-none" />
          </div>

          {/* Quick Platform Badge Pill in Corner */}
          <div className="absolute top-3 left-3 z-10">
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/90 dark:bg-[#0B1020]/90 backdrop-blur-md border border-white/60 dark:border-slate-700/60 shadow-sm">
              <span
                className="w-2 h-2 rounded-full animate-pulse"
                style={{ backgroundColor: slide.accentColor }}
              />
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-[#10172A] dark:text-white">
                {slide.name} Spotlight
              </span>
            </div>
          </div>

          {/* Performance Pill in Right Corner */}
          <div className="absolute top-3 right-3 z-10">
            <div className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-black/40 backdrop-blur-md text-white text-[10px] font-bold border border-white/20">
              <Sparkles className="w-3 h-3 text-[#22D3EE]" />
              <span>{slide.metricLabel}: {slide.metricValue}</span>
            </div>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
};
