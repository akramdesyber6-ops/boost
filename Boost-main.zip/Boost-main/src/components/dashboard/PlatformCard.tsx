import React from 'react';
import { PlatformSlide } from './carouselData';
import { PlatformIcon } from '../common/BrandIcons';
import { ChevronRight, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';

interface PlatformCardProps {
  slide: PlatformSlide;
  isActive: boolean;
  onClick: () => void;
  index: number;
}

export const PlatformCard: React.FC<PlatformCardProps> = ({
  slide,
  isActive,
  onClick,
  index,
}) => {
  return (
    <motion.div
      layout
      onClick={onClick}
      id={`platform-card-${slide.id}`}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          onClick();
        }
      }}
      aria-label={`Select ${slide.name} promotion`}
      className={`group relative p-3 sm:p-3.5 rounded-2xl backdrop-blur-md cursor-pointer transition-all duration-300 select-none ${
        isActive
          ? 'bg-white dark:bg-[#162244] shadow-vyro-card scale-[1.02] z-20 border'
          : 'bg-white/80 dark:bg-[#111A32]/70 hover:bg-white dark:hover:bg-[#162244]/90 border border-[#E1E7F3]/80 dark:border-slate-800/80 hover:scale-[1.01] hover:shadow-md'
      }`}
      style={{
        borderColor: isActive ? slide.accentColor : undefined,
        boxShadow: isActive
          ? `0 12px 28px -8px ${slide.glowColor}, 0 4px 12px -2px rgba(0, 0, 0, 0.05)`
          : undefined,
      }}
    >
      {/* Left indicator bar on active */}
      {isActive && (
        <motion.div
          layoutId="activeCardIndicator"
          className="absolute left-0 top-2 bottom-2 w-1 rounded-r-full"
          style={{ backgroundColor: slide.accentColor }}
          transition={{ type: 'spring', stiffness: 350, damping: 30 }}
        />
      )}

      <div className="flex items-center gap-3">
        {/* Platform Icon Box */}
        <div
          className="w-10 h-10 rounded-xl p-1.5 shrink-0 flex items-center justify-center transition-transform duration-300 group-hover:scale-105 shadow-sm"
          style={{
            background:
              slide.id === 'instagram'
                ? slide.accentGradient
                : slide.id === 'youtube'
                ? '#FF0000'
                : slide.id === 'facebook'
                ? '#1877F2'
                : slide.id === 'tiktok'
                ? '#000000'
                : '#0B1020',
          }}
        >
          <PlatformIcon platform={slide.id} size="sm" />
        </div>

        {/* Text Details */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-1">
            <div className="flex items-center gap-1.5">
              <span
                className="text-[10px] font-extrabold uppercase tracking-wider leading-none"
                style={{ color: slide.accentColor }}
              >
                {slide.name}
              </span>
              {isActive && (
                <span
                  className="w-1.5 h-1.5 rounded-full animate-ping"
                  style={{ backgroundColor: slide.accentColor }}
                />
              )}
            </div>

            <div className="flex items-center gap-1">
              <span className="text-[10px] text-[#68738B] dark:text-slate-400 font-medium hidden sm:inline">
                {slide.metricValue}
              </span>
              <ChevronRight
                className={`w-3.5 h-3.5 transition-transform duration-300 ${
                  isActive
                    ? 'text-[#7357FF] dark:text-[#22D3EE] translate-x-0.5'
                    : 'text-[#68738B] dark:text-slate-500 group-hover:translate-x-0.5'
                }`}
              />
            </div>
          </div>

          <p className="text-xs sm:text-[13px] font-bold text-[#10172A] dark:text-white leading-tight mt-0.5 truncate">
            {slide.category}
          </p>

          <div className="flex items-center justify-between mt-0.5">
            <p className="text-[10px] text-[#68738B] dark:text-slate-400 leading-tight truncate">
              {slide.description}
            </p>
          </div>
        </div>
      </div>
    </motion.div>
  );
};
