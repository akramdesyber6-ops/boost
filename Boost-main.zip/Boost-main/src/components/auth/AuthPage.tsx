import React, { useState } from 'react';
import { User } from '../../types';
import { getStoredUsers, setCurrentUser } from '../../lib/storage';
import { auth, googleProvider, dbSaveUser } from '../../lib/firebase';
import { signInWithPopup } from 'firebase/auth';
import { 
  Eye, 
  EyeOff, 
  ArrowRight, 
  Lock, 
  User as UserIcon, 
  AlertCircle,
  Phone,
  Mail,
  Sparkles,
  CheckCircle2
} from 'lucide-react';

interface AuthPageProps {
  initialMode?: 'login' | 'register';
  onSuccess: (user: User) => void;
  onCancel: () => void;
}

export const AuthPage: React.FC<AuthPageProps> = ({
  initialMode = 'login',
  onSuccess,
  onCancel,
}) => {
  const [mode, setMode] = useState<'login' | 'register'>(initialMode);

  // Form State - start clean with real inputs
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [staySignedIn, setStaySignedIn] = useState(true);

  // Registration Extra State
  const [fullName, setFullName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [referralCodeInput, setReferralCodeInput] = useState('');

  // Check for referral code in URL
  React.useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const ref = params.get('ref');
      if (ref) {
        setReferralCodeInput(ref);
        setMode('register');
      }
    }
  }, []);

  // Feedback
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [resetMsg, setResetMsg] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (mode === 'login') {
      if (!email.trim() || !password.trim()) {
        setErrorMsg('Please enter both your email address and password.');
        return;
      }

      setIsLoading(true);
      setTimeout(() => {
        setIsLoading(false);
        const users = getStoredUsers();
        const found = users.find(
          (u) => u.email.toLowerCase() === email.trim().toLowerCase()
        );

        if (found) {
          setCurrentUser(found.id);
          onSuccess(found);
        } else {
          setErrorMsg('Account not found with this email. Please sign up to create your account.');
        }
      }, 350);
    } else {
      // Register Mode
      if (!fullName.trim() || !email.trim() || !password.trim()) {
        setErrorMsg('Please fill in your full name, email, and password.');
        return;
      }

      setIsLoading(true);
      setTimeout(() => {
        setIsLoading(false);
        const users = getStoredUsers();
        const cleanUser = email.trim().toLowerCase().split('@')[0].replace(/[^a-z0-9_]/g, '') || ('creator_' + Date.now().toString().slice(-4));
        
        if (users.some((u) => u.email.toLowerCase() === email.trim().toLowerCase())) {
          setErrorMsg('This email is already registered. Please log in.');
          return;
        }

        const newUser: User = {
          id: 'user_' + Date.now(),
          fullName: fullName.trim(),
          username: cleanUser,
          email: email.trim().toLowerCase(),
          phone: phoneNumber.trim() || '',
          avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
          role: 'user',
          balanceUGX: 0,
          pendingBalanceUGX: 0,
          themePreference: 'light',
          referralCode: cleanUser.slice(0, 4).toUpperCase() + Math.random().toString(36).substring(2, 6).toUpperCase(),
          referredBy: referralCodeInput.trim() || undefined,
          referralsCount: 0,
          referralEarningsUGX: 0,
          hasMadeFirstTransaction: false,
          connectedAccounts: {},
          createdAt: new Date().toISOString(),
        };

        const updated = [...users, newUser];
        localStorage.setItem('vyro_users', JSON.stringify(updated));
        dbSaveUser(newUser);
        setCurrentUser(newUser.id);
        onSuccess(newUser);
      }, 350);
    }
  };

  const handleGoogleSignIn = async () => {
    setIsLoading(true);
    setErrorMsg(null);
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const fbUser = result.user;
      const users = getStoredUsers();
      let found = users.find(
        (u) => (fbUser.email && u.email.toLowerCase() === fbUser.email.toLowerCase()) || u.id === fbUser.uid
      );
      if (!found) {
        const cleanUser = (fbUser.displayName || 'creator').toLowerCase().replace(/[^a-z0-9]/g, '') || ('creator_' + Date.now().toString().slice(-4));
        found = {
          id: fbUser.uid,
          fullName: fbUser.displayName || 'Google Creator',
          username: cleanUser,
          email: fbUser.email || 'user@google.com',
          avatarUrl: fbUser.photoURL || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
          role: 'user',
          balanceUGX: 0,
          pendingBalanceUGX: 0,
          phone: fbUser.phoneNumber || '',
          themePreference: 'light',
          referralCode: cleanUser.slice(0, 4).toUpperCase() + Math.random().toString(36).substring(2, 6).toUpperCase(),
          referredBy: referralCodeInput.trim() || undefined,
          referralsCount: 0,
          referralEarningsUGX: 0,
          hasMadeFirstTransaction: false,
          connectedAccounts: {},
          createdAt: new Date().toISOString(),
        };
        const updated = [...users, found];
        localStorage.setItem('vyro_users', JSON.stringify(updated));
        await dbSaveUser(found);
      }
      setCurrentUser(found.id);
      setIsLoading(false);
      onSuccess(found);
    } catch (err: any) {
      setIsLoading(false);
      setErrorMsg('Google Sign-In was unable to complete in this window. Please sign up or log in using email and password.');
    }
  };

  const handleForgotPassword = () => {
    setResetMsg('Password recovery instructions sent to your verified email or mobile number.');
    setTimeout(() => setResetMsg(null), 4000);
  };

  return (
    <div className="relative min-h-[92vh] flex flex-col justify-between overflow-hidden bg-[#F4F7FF] dark:bg-[#0B1020] transition-colors">
      {/* Centered Phone Canvas Layout matching Screen 5 reference */}
      <div className="w-full max-w-[400px] mx-auto px-5 pt-3 pb-8 flex flex-col items-center">
        
        {/* TOP GLOWING CIRCULAR HALO WITH JANICE & TEAM CREATOR PHOTO */}
        <div className="relative flex flex-col items-center mt-1 mb-4">
          {/* Tooltip speech bubble: 🟣 Janice: Ready to grow? */}
          <div className="mb-2 bg-white dark:bg-[#111A32] px-3.5 py-1.5 rounded-full shadow-vyro-card border border-[#E1E7F3] dark:border-[#7357FF]/30 flex items-center gap-1.5 animate-bounce-slow">
            <span className="w-2 h-2 rounded-full bg-[#7357FF] dark:bg-[#22D3EE] inline-block" />
            <span className="text-[11px] font-bold text-[#10172A] dark:text-white">
              <span className="font-extrabold text-[#7357FF] dark:text-[#22D3EE]">Janice:</span> Ready to grow?
            </span>
          </div>

          {/* Halo and Creator Photo */}
          <div className="relative w-32 h-32 sm:w-36 sm:h-36 rounded-full p-1 bg-gradient-to-tr from-[#7357FF]/30 via-[#22D3EE]/30 to-[#EC4899]/30 shadow-vyro-card flex items-center justify-center">
            <div className="w-full h-full rounded-full overflow-hidden border-2 border-white dark:border-[#111A32]">
              <img
                src="https://images.unsplash.com/photo-1582750433449-648ed127bb54?auto=format&fit=crop&w=400&q=80"
                alt="Janice and Creator Team"
                className="w-full h-full object-cover object-top"
              />
            </div>
          </div>
        </div>

        {/* SEGMENTED TAB TOGGLE: [ Log In ] [ Sign Up ] */}
        <div className="w-full bg-[#E8EDF8] dark:bg-[#111A32] p-1 rounded-full flex items-center mb-4 border border-[#E1E7F3] dark:border-[#7357FF]/20">
          <button
            type="button"
            onClick={() => setMode('login')}
            className={`flex-1 py-2.5 rounded-full text-xs font-bold transition-all ${
              mode === 'login'
                ? 'bg-white dark:bg-[#1A2548] text-[#10172A] dark:text-white shadow-sm border border-slate-200/50 dark:border-[#7357FF]/30'
                : 'text-[#68738B] dark:text-slate-400 hover:text-[#10172A] dark:hover:text-white'
            }`}
          >
            Log In
          </button>
          <button
            type="button"
            onClick={() => setMode('register')}
            className={`flex-1 py-2.5 rounded-full text-xs font-bold transition-all ${
              mode === 'register'
                ? 'bg-white dark:bg-[#1A2548] text-[#10172A] dark:text-white shadow-sm border border-slate-200/50 dark:border-[#7357FF]/30'
                : 'text-[#68738B] dark:text-slate-400 hover:text-[#10172A] dark:hover:text-white'
            }`}
          >
            Sign Up
          </button>
        </div>

        {/* HEADINGS */}
        <div className="w-full text-left mb-3">
          <span className="text-[10px] font-extrabold uppercase tracking-[0.2em] text-[#7357FF] dark:text-[#22D3EE]">
            VYRO / ACCESS
          </span>
          <h2 className="text-xl sm:text-2xl font-black text-[#10172A] dark:text-white tracking-tight leading-snug mt-0.5">
            Turn attention <br />
            into{' '}
            <span
              style={{
                background: 'linear-gradient(110deg, #5B4BFF 0%, #8B5CF6 42%, #EC4899 75%, #FF8A65 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}
            >
              momentum.
            </span>
          </h2>
        </div>

        {errorMsg && (
          <div className="w-full mb-3 p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 flex items-center gap-2 text-xs text-rose-700 dark:text-rose-300">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {resetMsg && (
          <div className="w-full mb-3 p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 flex items-center gap-2 text-xs text-emerald-700 dark:text-emerald-300">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{resetMsg}</span>
          </div>
        )}

        {/* AUTH FORM */}
        <form onSubmit={handleSubmit} className="w-full space-y-3">
          {mode === 'register' && (
            <div>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-[#68738B] dark:text-slate-400">
                  <UserIcon className="w-4 h-4" />
                </span>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Full Name (e.g. Alex Mukasa)"
                  className="w-full pl-11 pr-4 py-3 rounded-full bg-white dark:bg-[#111A32] border border-[#E1E7F3] dark:border-[#7357FF]/30 text-xs sm:text-sm text-[#10172A] dark:text-white placeholder:text-[#68738B] dark:placeholder:text-slate-500 shadow-sm focus:border-[#7357FF] focus:outline-none"
                />
              </div>
            </div>
          )}

          {mode === 'register' && (
            <div>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-[#68738B] dark:text-slate-400">
                  <Phone className="w-4 h-4" />
                </span>
                <input
                  type="tel"
                  required
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  placeholder="Phone (e.g. +256 772 123 456)"
                  className="w-full pl-11 pr-4 py-3 rounded-full bg-white dark:bg-[#111A32] border border-[#E1E7F3] dark:border-[#7357FF]/30 text-xs sm:text-sm text-[#10172A] dark:text-white placeholder:text-[#68738B] dark:placeholder:text-slate-500 shadow-sm focus:border-[#7357FF] focus:outline-none"
                />
              </div>
            </div>
          )}

          {/* EMAIL INPUT */}
          <div>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-[#68738B] dark:text-slate-400">
                <Mail className="w-4 h-4" />
              </span>
              <input
                id="auth-email-input"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email Address"
                className="w-full pl-11 pr-4 py-3 rounded-full bg-white dark:bg-[#111A32] border border-[#E1E7F3] dark:border-[#7357FF]/30 text-xs sm:text-sm text-[#10172A] dark:text-white placeholder:text-[#68738B] dark:placeholder:text-slate-500 shadow-sm focus:border-[#7357FF] focus:outline-none"
              />
            </div>
          </div>

          {/* PASSWORD INPUT WITH EYE TOGGLE */}
          <div>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-[#68738B] dark:text-slate-400">
                <Lock className="w-4 h-4" />
              </span>
              <input
                id="auth-password-input"
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password"
                className="w-full pl-11 pr-11 py-3 rounded-full bg-white dark:bg-[#111A32] border border-[#E1E7F3] dark:border-[#7357FF]/30 text-xs sm:text-sm text-[#10172A] dark:text-white placeholder:text-[#68738B] dark:placeholder:text-slate-500 shadow-sm focus:border-[#7357FF] focus:outline-none"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-4 flex items-center text-[#68738B] dark:text-slate-400 hover:text-[#10172A] dark:hover:text-white"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {mode === 'register' && (
            <div>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-[#68738B] dark:text-slate-400">
                  <Sparkles className="w-4 h-4" />
                </span>
                <input
                  type="text"
                  value={referralCodeInput}
                  onChange={(e) => setReferralCodeInput(e.target.value)}
                  placeholder="Referral Code (Optional)"
                  className="w-full pl-11 pr-4 py-3 rounded-full bg-white dark:bg-[#111A32] border border-[#E1E7F3] dark:border-[#7357FF]/30 text-xs sm:text-sm text-[#10172A] dark:text-white placeholder:text-[#68738B] dark:placeholder:text-slate-500 shadow-sm focus:border-[#7357FF] focus:outline-none uppercase"
                />
              </div>
            </div>
          )}

          {/* CHECKBOX & FORGOT PASSWORD ROW */}
          <div className="flex items-center justify-between text-xs pt-0.5 px-1">
            <label className="flex items-center gap-2 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={staySignedIn}
                onChange={(e) => setStaySignedIn(e.target.checked)}
                className="w-4 h-4 rounded text-[#7357FF] focus:ring-[#7357FF] border-[#E1E7F3]"
              />
              <span className="text-[#10172A] dark:text-slate-300 font-medium text-[11px] sm:text-xs">
                Stay signed in
              </span>
            </label>

            <button
              type="button"
              onClick={handleForgotPassword}
              className="text-[#7357FF] dark:text-[#22D3EE] hover:underline font-semibold text-[11px] sm:text-xs"
            >
              Forgot password?
            </button>
          </div>

          {/* MAIN ACTION: [ Enter VYRO -> ] */}
          <button
            id="auth-submit-btn"
            type="submit"
            disabled={isLoading}
            className="w-full py-3.5 px-4 rounded-full text-white text-xs sm:text-sm font-bold shadow-vyro-glow hover:opacity-95 transition-all transform hover:-translate-y-0.5 active:translate-y-0 flex items-center justify-center gap-2 mt-2"
            style={{
              background: 'linear-gradient(110deg, #5B4BFF 0%, #8B5CF6 42%, #EC4899 75%, #FF8A65 100%)',
            }}
          >
            {isLoading ? (
              <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <span>Enter VYRO</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>

          {/* TERMS DISCLAIMER */}
          <p className="text-[11px] text-[#68738B] dark:text-slate-400 text-center pt-2">
            By continuing, you accept our{' '}
            <span className="text-[#7357FF] dark:text-[#22D3EE] font-semibold cursor-pointer hover:underline">
              Terms & Privacy
            </span>
            .
          </p>
        </form>
      </div>
    </div>
  );
};
