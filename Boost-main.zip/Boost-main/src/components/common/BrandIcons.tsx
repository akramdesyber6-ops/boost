import React from 'react';
import { Platform } from '../../types';

export const VyroWordmark: React.FC<{
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showDot?: boolean;
  onClick?: () => void;
}> = ({ className = '', size = 'md', showDot = true, onClick }) => {
  const sizeClasses = {
    sm: 'text-lg tracking-tight',
    md: 'text-2xl sm:text-[26px] tracking-tight',
    lg: 'text-3xl sm:text-4xl tracking-tight',
    xl: 'text-4xl sm:text-5xl tracking-tighter',
  };

  return (
    <div
      onClick={onClick}
      className={`inline-flex items-center select-none font-black ${
        onClick ? 'cursor-pointer' : ''
      } ${sizeClasses[size]} ${className}`}
    >
      <span
        className="font-extrabold uppercase"
        style={{
          background: 'linear-gradient(110deg, #FF1E40 0%, #FF4500 38%, #FF7A00 75%, #FFAA00 100%)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
          letterSpacing: '-0.03em',
        }}
      >
        VYRO
      </span>
      {showDot && (
        <span className="w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full bg-[#FF4500] ml-0.5 shadow-[0_0_8px_#FF4500]" />
      )}
    </div>
  );
};

export const VyroAppIcon: React.FC<{
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}> = ({ size = 'md', className = '' }) => {
  const sizeClasses = {
    sm: 'w-7 h-7',
    md: 'w-9 h-9',
    lg: 'w-12 h-12',
    xl: 'w-16 h-16',
  };

  return (
    <div
      className={`relative inline-flex items-center justify-center rounded-2xl bg-[#0B1020] border border-[#FF4500]/30 shadow-vyro-glow overflow-hidden ${sizeClasses[size]} ${className}`}
    >
      <div className="absolute inset-0 bg-radial from-[#FF6B00]/20 via-transparent to-transparent opacity-60" />
      <svg viewBox="0 0 40 40" fill="none" className="w-3/5 h-3/5 relative z-10">
        <path
          d="M8 12 L16 28 L20 18 L24 28 L32 12"
          stroke="url(#vyroIconGrad)"
          strokeWidth="3.5"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
        <circle cx="32" cy="10" r="2" fill="#FF7A00" />
        <defs>
          <linearGradient id="vyroIconGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FF1E40" />
            <stop offset="50%" stopColor="#FF4500" />
            <stop offset="100%" stopColor="#FFAA00" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
};

export const VyroLogo: React.FC<{
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  showIcon?: boolean;
  onClick?: () => void;
}> = ({ className = '', size = 'md', showIcon = true, onClick }) => {
  return (
    <div
      onClick={onClick}
      className={`inline-flex items-center gap-2 select-none ${
        onClick ? 'cursor-pointer group' : ''
      } ${className}`}
    >
      {showIcon && <VyroAppIcon size={size === 'lg' ? 'md' : 'sm'} />}
      <VyroWordmark size={size} />
    </div>
  );
};

// Aliases for backwards compatibility
export const BoostaWordmark = VyroWordmark;
export const BoostaLogo = VyroLogo;

export const PlatformIcon: React.FC<{
  platform: Platform | 'telegram' | 'whatsapp';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}> = ({ platform, size = 'md', className = '' }) => {
  const sizeClasses = {
    sm: 'w-5 h-5',
    md: 'w-6 h-6',
    lg: 'w-8 h-8',
    xl: 'w-10 h-10',
  };

  switch (platform) {
    case 'tiktok':
      return (
        <div
          className={`${sizeClasses[size]} rounded-full flex items-center justify-center bg-black text-white p-1 shadow-sm ${className}`}
        >
          <svg viewBox="0 0 24 24" fill="currentColor" className="w-full h-full">
            <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64c.29 0 .58.04.85.12V9.4a6.33 6.33 0 0 0-.85-.06A6.34 6.34 0 0 0 3.1 15.68a6.34 6.34 0 0 0 10.74 4.53 6.34 6.34 0 0 0 1.95-4.54V9.08c1.33.95 2.94 1.52 4.69 1.58V7.22a4.78 4.78 0 0 1-.89-.53z" />
          </svg>
        </div>
      );
    case 'instagram':
      return (
        <div
          className={`${sizeClasses[size]} rounded-full flex items-center justify-center p-1 text-white shadow-sm ${className}`}
          style={{
            background:
              'radial-gradient(circle at 30% 107%, #fdf497 0%, #fdf497 5%, #fd5949 45%, #d6249f 60%, #285AEB 90%)',
          }}
        >
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.2"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="w-full h-full"
          >
            <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
            <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
            <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
          </svg>
        </div>
      );
    case 'youtube':
      return (
        <div
          className={`${sizeClasses[size]} rounded-full flex items-center justify-center bg-[#FF0000] text-white p-1 shadow-sm ${className}`}
        >
          <svg viewBox="0 0 24 24" fill="currentColor" className="w-full h-full">
            <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
          </svg>
        </div>
      );
    case 'facebook':
      return (
        <div
          className={`${sizeClasses[size]} rounded-full flex items-center justify-center bg-[#1877F2] text-white p-1 shadow-sm ${className}`}
        >
          <svg viewBox="0 0 24 24" fill="currentColor" className="w-full h-full">
            <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
          </svg>
        </div>
      );
    case 'x':
      return (
        <div
          className={`${sizeClasses[size]} rounded-full flex items-center justify-center bg-[#0F1419] text-white p-1 shadow-sm ${className}`}
        >
          <svg viewBox="0 0 24 24" fill="currentColor" className="w-full h-full p-0.5">
            <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
          </svg>
        </div>
      );
    case 'telegram':
      return (
        <div
          className={`${sizeClasses[size]} rounded-full flex items-center justify-center bg-[#29A9EB] text-white p-1 shadow-sm ${className}`}
        >
          <svg viewBox="0 0 24 24" fill="currentColor" className="w-full h-full p-0.5">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 0 0-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.74-.55 2.92-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.36.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .38z" />
          </svg>
        </div>
      );
    case 'whatsapp':
      return (
        <div
          className={`${sizeClasses[size]} rounded-full flex items-center justify-center bg-[#25D366] text-white p-1 shadow-sm ${className}`}
        >
          <svg viewBox="0 0 24 24" fill="currentColor" className="w-full h-full p-0.5">
            <path d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.816 9.816 0 0 0 12.04 2zm0 18.15c-1.49 0-2.95-.4-4.23-1.16l-.3-.18-3.14.82.84-3.06-.2-.31a8.19 8.19 0 0 1-1.26-4.36c0-4.54 3.7-8.24 8.25-8.24 2.2 0 4.27.86 5.82 2.42a8.18 8.18 0 0 1 2.41 5.83c.02 4.54-3.68 8.24-8.22 8.24zm4.52-6.17c-.25-.12-1.47-.72-1.7-.81-.23-.08-.39-.12-.56.12-.17.25-.64.81-.79.97-.14.17-.29.19-.54.06-.25-.12-1.05-.39-1.99-1.23-.74-.66-1.23-1.47-1.38-1.72-.14-.25-.02-.38.11-.5.11-.11.25-.29.37-.43.12-.14.17-.25.25-.41.08-.17.04-.31-.02-.43s-.56-1.34-.76-1.84c-.2-.48-.41-.42-.56-.43h-.48c-.17 0-.43.06-.66.31-.22.25-.86.84-.86 2.05s.88 2.38 1 2.54c.12.17 1.74 2.65 4.2 3.72.59.25 1.05.41 1.41.52.59.19 1.13.16 1.56.1.48-.07 1.47-.6 1.68-1.18.21-.58.21-1.07.14-1.18-.06-.11-.23-.17-.48-.29z" />
          </svg>
        </div>
      );
    default:
      return null;
  }
};

/**
 * 3D Glowing Social Media Orbs with neon accent dots as seen in the screenshots
 */
export type OrbType = Platform | 'telegram' | 'whatsapp' | 'spotify' | 'snapchat' | 'linkedin';

export const SocialOrb: React.FC<{
  type: OrbType;
  onClick?: () => void;
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}> = ({ type, onClick, className = '', size = 'md' }) => {
  const containerSizes = {
    sm: 'w-11 h-11',
    md: 'w-14 h-14 sm:w-16 sm:h-16',
    lg: 'w-16 h-16 sm:w-20 sm:h-20',
  };

  const orbSizes = {
    sm: 'w-9 h-9',
    md: 'w-12 h-12 sm:w-13 sm:h-13',
    lg: 'w-14 h-14 sm:w-16 sm:h-16',
  };

  return (
    <div
      onClick={onClick}
      className={`relative inline-flex items-center justify-center select-none cursor-pointer transition-transform hover:scale-110 active:scale-95 ${containerSizes[size]} ${className}`}
    >
      {type === 'tiktok' && (
        <>
          {/* Neon accent dots */}
          <span className="absolute top-0 right-1 w-2.5 h-2.5 rounded-full bg-[#29D7E7] shadow-[0_0_8px_#29D7E7] animate-pulse" />
          <span className="absolute bottom-1 left-0.5 w-2 h-2 rounded-full bg-[#F04BAE] shadow-[0_0_6px_#F04BAE]" />
          {/* Main 3D Glossy Orb */}
          <div
            className={`${orbSizes[size]} rounded-full bg-gradient-to-b from-[#2B2D42] to-[#101223] flex items-center justify-center shadow-lg border border-white/20 relative overflow-hidden`}
          >
            <div className="absolute inset-0 bg-gradient-to-t from-transparent via-transparent to-white/25 rounded-full" />
            <svg viewBox="0 0 24 24" fill="white" className="w-1/2 h-1/2 drop-shadow">
              <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64c.29 0 .58.04.85.12V9.4a6.33 6.33 0 0 0-.85-.06A6.34 6.34 0 0 0 3.1 15.68a6.34 6.34 0 0 0 10.74 4.53 6.34 6.34 0 0 0 1.95-4.54V9.08c1.33.95 2.94 1.52 4.69 1.58V7.22a4.78 4.78 0 0 1-.89-.53z" />
            </svg>
          </div>
        </>
      )}

      {type === 'facebook' && (
        <>
          <span className="absolute top-0 right-1 w-2.5 h-2.5 rounded-full bg-[#22D3EE] shadow-[0_0_8px_#22D3EE]" />
          <span className="absolute bottom-1 left-0.5 w-2 h-2 rounded-full bg-[#1877F2] shadow-[0_0_6px_#1877F2]" />
          <div
            className={`${orbSizes[size]} rounded-full bg-gradient-to-b from-[#1877F2] to-[#0D57BD] flex items-center justify-center shadow-lg border border-white/30 relative overflow-hidden`}
          >
            <div className="absolute inset-0 bg-gradient-to-t from-transparent via-transparent to-white/30 rounded-full" />
            <svg viewBox="0 0 24 24" fill="white" className="w-1/2 h-1/2 drop-shadow">
              <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
            </svg>
          </div>
        </>
      )}

      {type === 'x' && (
        <>
          <span className="absolute top-1 right-0.5 w-2.5 h-2.5 rounded-full bg-[#7E7D94] shadow-[0_0_6px_#7E7D94]" />
          <span className="absolute bottom-1 left-1 w-2 h-2 rounded-full bg-[#202533]" />
          <div
            className={`${orbSizes[size]} rounded-full bg-gradient-to-b from-[#2B303C] to-[#12151D] flex items-center justify-center shadow-lg border border-white/20 relative overflow-hidden`}
          >
            <div className="absolute inset-0 bg-gradient-to-t from-transparent via-transparent to-white/25 rounded-full" />
            <svg viewBox="0 0 24 24" fill="white" className="w-1/2 h-1/2 drop-shadow">
              <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
            </svg>
          </div>
        </>
      )}

      {type === 'instagram' && (
        <>
          <span className="absolute top-0 right-1 w-2.5 h-2.5 rounded-full bg-[#FF9B4A] shadow-[0_0_8px_#FF9B4A] animate-pulse" />
          <span className="absolute bottom-1 left-0.5 w-2 h-2 rounded-full bg-[#F04BAE] shadow-[0_0_6px_#F04BAE]" />
          <div
            className={`${orbSizes[size]} rounded-full flex items-center justify-center shadow-lg border border-white/30 relative overflow-hidden`}
            style={{
              background: 'radial-gradient(circle at 30% 107%, #fdf497 0%, #fd5949 45%, #d6249f 70%, #285AEB 100%)',
            }}
          >
            <div className="absolute inset-0 bg-gradient-to-t from-transparent via-transparent to-white/30 rounded-full" />
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="white"
              strokeWidth="2.2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="w-1/2 h-1/2 drop-shadow"
            >
              <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
              <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
              <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
            </svg>
          </div>
        </>
      )}

      {type === 'telegram' && (
        <>
          <span className="absolute top-1 right-0 w-2.5 h-2.5 rounded-full bg-[#29D7E7] shadow-[0_0_8px_#29D7E7]" />
          <span className="absolute bottom-1.5 left-0.5 w-2 h-2 rounded-full bg-[#0088CC] shadow-[0_0_6px_#0088CC]" />
          <div
            className={`${orbSizes[size]} rounded-full bg-gradient-to-b from-[#37AEE2] to-[#1E96C8] flex items-center justify-center shadow-lg border border-white/30 relative overflow-hidden`}
          >
            <div className="absolute inset-0 bg-gradient-to-t from-transparent via-transparent to-white/30 rounded-full" />
            <svg viewBox="0 0 24 24" fill="white" className="w-1/2 h-1/2 drop-shadow">
              <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm4.64 6.8c-.15 1.58-.8 5.42-1.13 7.19-.14.75-.42 1-.68 1.03-.58.05-1.02-.38-1.58-.75-.88-.58-1.38-.94-2.23-1.5-.99-.65-.35-1.01.22-1.59.15-.15 2.71-2.48 2.76-2.69a.2.2 0 0 0-.05-.18c-.06-.05-.14-.03-.21-.02-.09.02-1.49.95-4.22 2.79-.4.27-.76.41-1.08.4-.36-.01-1.04-.2-1.55-.37-.63-.2-1.12-.31-1.08-.66.02-.18.27-.36.74-.55 2.92-1.27 4.86-2.11 5.83-2.51 2.78-1.16 3.35-1.36 3.73-1.36.08 0 .27.02.39.12.1.08.13.19.14.27-.01.06.01.24 0 .38z" />
            </svg>
          </div>
        </>
      )}

      {type === 'youtube' && (
        <>
          <span className="absolute top-0 right-1 w-2.5 h-2.5 rounded-full bg-[#FF6D78] shadow-[0_0_8px_#FF6D78]" />
          <span className="absolute bottom-1 left-0.5 w-2 h-2 rounded-full bg-[#FF0000]" />
          <div
            className={`${orbSizes[size]} rounded-full bg-gradient-to-b from-[#FF2B2B] to-[#CC0000] flex items-center justify-center shadow-lg border border-white/30 relative overflow-hidden`}
          >
            <div className="absolute inset-0 bg-gradient-to-t from-transparent via-transparent to-white/30 rounded-full" />
            <svg viewBox="0 0 24 24" fill="white" className="w-1/2 h-1/2 drop-shadow">
              <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
            </svg>
          </div>
        </>
      )}

      {type === 'whatsapp' && (
        <>
          <span className="absolute top-0 right-1 w-2.5 h-2.5 rounded-full bg-[#4ADE80] shadow-[0_0_8px_#4ADE80]" />
          <span className="absolute bottom-1 left-0.5 w-2 h-2 rounded-full bg-[#16A34A]" />
          <div
            className={`${orbSizes[size]} rounded-full bg-gradient-to-b from-[#25D366] to-[#128C7E] flex items-center justify-center shadow-lg border border-white/30 relative overflow-hidden`}
          >
            <div className="absolute inset-0 bg-gradient-to-t from-transparent via-transparent to-white/30 rounded-full" />
            <svg viewBox="0 0 24 24" fill="white" className="w-1/2 h-1/2 drop-shadow">
              <path d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.816 9.816 0 0 0 12.04 2zm0 18.15c-1.49 0-2.95-.4-4.23-1.16l-.3-.18-3.14.82.84-3.06-.2-.31a8.19 8.19 0 0 1-1.26-4.36c0-4.54 3.7-8.24 8.25-8.24 2.2 0 4.27.86 5.82 2.42a8.18 8.18 0 0 1 2.41 5.83c.02 4.54-3.68 8.24-8.22 8.24zm4.52-6.17c-.25-.12-1.47-.72-1.7-.81-.23-.08-.39-.12-.56.12-.17.25-.64.81-.79.97-.14.17-.29.19-.54.06-.25-.12-1.05-.39-1.99-1.23-.74-.66-1.23-1.47-1.38-1.72-.14-.25-.02-.38.11-.5.11-.11.25-.29.37-.43.12-.14.17-.25.25-.41.08-.17.04-.31-.02-.43s-.56-1.34-.76-1.84c-.2-.48-.41-.42-.56-.43h-.48c-.17 0-.43.06-.66.31-.22.25-.86.84-.86 2.05s.88 2.38 1 2.54c.12.17 1.74 2.65 4.2 3.72.59.25 1.05.41 1.41.52.59.19 1.13.16 1.56.1.48-.07 1.47-.6 1.68-1.18.21-.58.21-1.07.14-1.18-.06-.11-.23-.17-.48-.29z" />
            </svg>
          </div>
        </>
      )}

      {type === 'spotify' && (
        <>
          <span className="absolute top-0 right-1 w-2.5 h-2.5 rounded-full bg-[#1ED760] shadow-[0_0_8px_#1ED760]" />
          <span className="absolute bottom-1 left-0.5 w-2 h-2 rounded-full bg-[#111]" />
          <div
            className={`${orbSizes[size]} rounded-full bg-gradient-to-b from-[#1ED760] to-[#128C3E] flex items-center justify-center shadow-lg border border-white/30 relative overflow-hidden`}
          >
            <div className="absolute inset-0 bg-gradient-to-t from-transparent via-transparent to-white/30 rounded-full" />
            <svg viewBox="0 0 24 24" fill="white" className="w-1/2 h-1/2 drop-shadow">
              <path d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm4.586 14.424a.625.625 0 0 1-.86.208c-2.355-1.439-5.32-1.764-8.812-.966a.625.625 0 1 1-.28-1.218c3.823-.873 7.104-.506 9.744 1.115a.625.625 0 0 1 .208.861zm1.225-2.724a.782.782 0 0 1-1.076.257c-2.696-1.657-6.806-2.137-9.995-1.17a.781.781 0 1 1-.453-1.496c3.642-1.106 8.188-.574 11.267 1.332a.782.782 0 0 1 .257 1.077zm.106-2.836C14.685 8.91 9.362 8.733 6.273 9.67a.938.938 0 1 1-.544-1.794c3.553-1.078 9.428-.871 13.197 1.365a.937.937 0 1 1-.994 1.593z" />
            </svg>
          </div>
        </>
      )}

      {type === 'snapchat' && (
        <>
          <span className="absolute top-0 right-1 w-2.5 h-2.5 rounded-full bg-[#FFFC00] shadow-[0_0_8px_#FFFC00]" />
          <span className="absolute bottom-1 left-0.5 w-2 h-2 rounded-full bg-[#E5E000]" />
          <div
            className={`${orbSizes[size]} rounded-full bg-gradient-to-b from-[#FFFC00] to-[#F0EC00] flex items-center justify-center shadow-lg border border-white/30 relative overflow-hidden text-black`}
          >
            <div className="absolute inset-0 bg-gradient-to-t from-transparent via-transparent to-white/40 rounded-full" />
            <svg viewBox="0 0 24 24" fill="currentColor" className="w-1/2 h-1/2 drop-shadow">
              <path d="M12.003 2.5c-4.48 0-6.73 3.32-6.73 6.01 0 1.25.43 2.45.96 3.42.15.27.18.43.08.64-.13.29-.44.5-.83.69-.37.18-.72.36-.72.69 0 .34.34.61.85.74.52.13 1.13.11 1.76.08.31-.02.63-.03.95.03.4.08.7.27.97.63.48.66 1.23 1.07 2.06 1.07.21 0 .42-.03.62-.08.57-.15 1.14-.15 1.71 0 .2.05.41.08.62.08.83 0 1.58-.41 2.06-1.07.27-.36.57-.55.97-.63.32-.06.64-.05.95-.03.63.03 1.24.05 1.76-.08.51-.13.85-.4.85-.74 0-.33-.35-.51-.72-.69-.39-.19-.7-.4-.83-.69-.1-.21-.07-.37.08-.64.53-.97.96-2.17.96-3.42 0-2.69-2.25-6.01-6.73-6.01z" />
            </svg>
          </div>
        </>
      )}

      {type === 'linkedin' && (
        <>
          <span className="absolute top-0 right-1 w-2.5 h-2.5 rounded-full bg-[#0A66C2] shadow-[0_0_8px_#0A66C2]" />
          <span className="absolute bottom-1 left-0.5 w-2 h-2 rounded-full bg-[#004182]" />
          <div
            className={`${orbSizes[size]} rounded-full bg-gradient-to-b from-[#0A66C2] to-[#004182] flex items-center justify-center shadow-lg border border-white/30 relative overflow-hidden`}
          >
            <div className="absolute inset-0 bg-gradient-to-t from-transparent via-transparent to-white/30 rounded-full" />
            <svg viewBox="0 0 24 24" fill="white" className="w-1/2 h-1/2 drop-shadow">
              <path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.28 1.3v-1.11h-2.79v8.37h2.79v-4.93c0-.77.62-1.4 1.39-1.4a1.4 1.4 0 0 1 1.4 1.4v4.93h2.75M6.46 8.76c.96 0 1.74-.78 1.74-1.74a1.74 1.74 0 0 0-3.48 0c0 .96.78 1.74 1.74 1.74m1.39 9.74v-8.37H5.07v8.37h2.78z" />
            </svg>
          </div>
        </>
      )}
    </div>
  );
};

/**
 * Continuous Smooth Sliding Marquee of Glowing Social Orbs
 */
export const SocialOrbsSlider: React.FC<{
  onSelectPlatform?: (platform: Platform) => void;
  className?: string;
}> = ({ onSelectPlatform, className = '' }) => {
  const orbsList: OrbType[] = [
    'tiktok',
    'instagram',
    'youtube',
    'facebook',
    'x',
    'telegram',
    'whatsapp',
    'spotify',
    'snapchat',
    'linkedin',
  ];

  const handleOrbClick = (type: OrbType) => {
    if (onSelectPlatform) {
      if (type === 'tiktok' || type === 'instagram' || type === 'youtube' || type === 'facebook' || type === 'x') {
        onSelectPlatform(type);
      }
    }
  };

  return (
    <div className={`w-full overflow-hidden relative select-none py-2 ${className}`}>
      {/* Edge gradient masks */}
      <div className="absolute left-0 top-0 bottom-0 w-8 z-10 bg-gradient-to-r from-[#F4F7FF] dark:from-[#0B1020] to-transparent pointer-events-none" />
      <div className="absolute right-0 top-0 bottom-0 w-8 z-10 bg-gradient-to-l from-[#F4F7FF] dark:from-[#0B1020] to-transparent pointer-events-none" />

      {/* Marquee Track */}
      <div className="flex w-max animate-marquee-slide">
        {/* First set */}
        <div className="flex items-center gap-4 px-2">
          {orbsList.map((orb, idx) => (
            <div key={`orb1-${orb}-${idx}`} className="flex flex-col items-center">
              <SocialOrb type={orb} onClick={() => handleOrbClick(orb)} size="sm" />
            </div>
          ))}
        </div>

        {/* Duplicate set for seamless infinite loop */}
        <div className="flex items-center gap-4 px-2">
          {orbsList.map((orb, idx) => (
            <div key={`orb2-${orb}-${idx}`} className="flex flex-col items-center">
              <SocialOrb type={orb} onClick={() => handleOrbClick(orb)} size="sm" />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

