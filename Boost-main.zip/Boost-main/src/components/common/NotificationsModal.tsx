import React from 'react';
import { NotificationItem } from '../../types';
import { markAllNotificationsRead } from '../../lib/storage';
import { Bell, Check, X, Sparkles, AlertCircle, Info, ExternalLink } from 'lucide-react';

interface NotificationsModalProps {
  userId: string;
  notifications: NotificationItem[];
  isOpen: boolean;
  onClose: () => void;
  onRefresh: () => void;
  onNavigateToCampaigns?: () => void;
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({
  userId,
  notifications,
  isOpen,
  onClose,
  onRefresh,
  onNavigateToCampaigns,
}) => {
  if (!isOpen) return null;

  const userNotifs = notifications.filter((n) => n.userId === userId);

  const handleMarkAllRead = () => {
    markAllNotificationsRead(userId);
    onRefresh();
  };

  return (
    <div className="fixed inset-0 bg-[#171A35]/35 backdrop-blur-sm z-50 flex items-start justify-end p-3 sm:p-6">
      <div className="bg-white rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl border border-purple-100 mt-12 animate-in fade-in slide-in-from-top-4 duration-200">
        <div className="flex items-center justify-between pb-3 border-b border-purple-100">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-purple-100 text-[#7546F5] flex items-center justify-center">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-extrabold text-[#171A35]">Notifications</h3>
              <p className="text-[10px] text-[#7E7D94]">Live order & payment alerts</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleMarkAllRead}
              className="text-[11px] text-[#7546F5] hover:underline font-semibold"
            >
              Mark all read
            </button>
            <button
              onClick={onClose}
              className="p-1 rounded-full text-[#7E7D94] hover:text-[#171A35]"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="mt-4 max-h-96 overflow-y-auto space-y-2.5">
          {userNotifs.length === 0 ? (
            <div className="text-center py-8 text-[#7E7D94] text-xs">
              No notifications at this time.
            </div>
          ) : (
            userNotifs.map((item) => (
              <div
                key={item.id}
                className={`p-3.5 rounded-2xl border transition-all text-left ${
                  item.read
                    ? 'bg-[#F8F5FF]/60 border-purple-50'
                    : 'bg-white border-purple-200 shadow-sm ring-1 ring-purple-100'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <h4 className="text-xs font-bold text-[#171A35] flex items-center gap-1.5">
                    {!item.read && (
                      <span className="w-2 h-2 rounded-full bg-[#FF6D78] inline-block shrink-0" />
                    )}
                    <span>{item.title}</span>
                  </h4>
                  <span className="text-[10px] text-[#7E7D94] shrink-0">
                    {new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
                <p className="text-[11px] text-[#7E7D94] mt-1 leading-snug">
                  {item.message}
                </p>
              </div>
            ))
          )}
        </div>

        {onNavigateToCampaigns && (
          <div className="mt-4 pt-3 border-t border-purple-100">
            <button
              onClick={() => {
                onClose();
                onNavigateToCampaigns();
              }}
              className="w-full py-2 rounded-xl bg-purple-50 hover:bg-purple-100 text-[#7546F5] text-xs font-bold transition-colors"
            >
              View Active Orders
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
