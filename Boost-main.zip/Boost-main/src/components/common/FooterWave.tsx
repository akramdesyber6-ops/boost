import React from 'react';

export const FooterWave: React.FC<{ className?: string; variant?: 'subtle' | 'vibrant' }> = ({
  className = '',
  variant = 'vibrant',
}) => {
  return (
    <div className={`w-full overflow-hidden leading-none select-none pointer-events-none mt-8 ${className}`}>
      <svg
        viewBox="0 0 1440 220"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-auto block"
        preserveAspectRatio="none"
      >
        <defs>
          <linearGradient id="vyroWaveGradient1" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#5B4BFF" stopOpacity={variant === 'subtle' ? '0.15' : '0.88'} />
            <stop offset="42%" stopColor="#8B5CF6" stopOpacity={variant === 'subtle' ? '0.18' : '0.82'} />
            <stop offset="75%" stopColor="#EC4899" stopOpacity={variant === 'subtle' ? '0.2' : '0.78'} />
            <stop offset="100%" stopColor="#FF8A65" stopOpacity={variant === 'subtle' ? '0.22' : '0.88'} />
          </linearGradient>

          <linearGradient id="vyroWaveGradient2" x1="100%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#22D3EE" stopOpacity={variant === 'subtle' ? '0.15' : '0.4'} />
            <stop offset="50%" stopColor="#6366F1" stopOpacity={variant === 'subtle' ? '0.15' : '0.5'} />
            <stop offset="100%" stopColor="#4338CA" stopOpacity={variant === 'subtle' ? '0.18' : '0.65'} />
          </linearGradient>

          <linearGradient id="vyroWaveGradient3" x1="0%" y1="50%" x2="100%" y2="50%">
            <stop offset="0%" stopColor="#7357FF" stopOpacity="0.08" />
            <stop offset="100%" stopColor="#22D3EE" stopOpacity="0.12" />
          </linearGradient>
        </defs>

        {/* Deep background soft curve */}
        <path
          d="M0,80 C320,160 480,20 840,110 C1200,200 1340,90 1440,120 L1440,220 L0,220 Z"
          fill="url(#vyroWaveGradient3)"
        />

        {/* Middle wave curve */}
        <path
          d="M0,120 C360,40 600,180 960,80 C1240,10 1380,110 1440,70 L1440,220 L0,220 Z"
          fill="url(#vyroWaveGradient2)"
        />

        {/* Foreground dynamic signature wave */}
        <path
          d="M0,140 C280,70 540,190 820,100 C1100,20 1320,140 1440,95 L1440,220 L0,220 Z"
          fill="url(#vyroWaveGradient1)"
        />
      </svg>
    </div>
  );
};

