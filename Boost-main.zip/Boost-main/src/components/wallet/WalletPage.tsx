import React, { useState, useEffect, useRef } from 'react';
import confetti from 'canvas-confetti';
import { User, Transaction } from '../../types';
import { addTransaction, updateTransactionStatus, updateUser, addNotification } from '../../lib/storage';
import {
  initiateMarzpayDeposit,
  checkMarzpayGatewayConfig,
  checkMarzpayTransactionStatus,
  formatUgandanPhone,
  detectProviderFromPhone,
} from '../../services/marzpay';
import { 
  ArrowUpRight, 
  ArrowDownLeft, 
  CheckCircle2, 
  ShieldCheck, 
  X,
  AlertCircle,
  Smartphone,
  Lock,
  RefreshCw,
  Zap,
  Sparkles,
} from 'lucide-react';

interface WalletPageProps {
  currentUser: User;
  transactions: Transaction[];
  onBalanceUpdated: (updatedUser: User) => void;
  onNavigateToCampaigns: () => void;
}

const PRESET_AMOUNTS = [10000, 25000, 50000, 100000, 250000];

export const WalletPage: React.FC<WalletPageProps> = ({
  currentUser,
  transactions,
  onBalanceUpdated,
  onNavigateToCampaigns,
}) => {
  const [depositAmount, setDepositAmount] = useState<number>(50000);
  const [depositMethod, setDepositMethod] = useState<'mtn_momo' | 'airtel_money'>('mtn_momo');
  const [phoneNumber, setPhoneNumber] = useState(currentUser.phone || '+256 772 000 000');
  const [isProcessing, setIsProcessing] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [selectedReceipt, setSelectedReceipt] = useState<Transaction | null>(null);

  // Gateway live status state
  const [gatewayInfo, setGatewayInfo] = useState<{
    configured: boolean;
    gateway: string;
    keyHint?: string | null;
  }>({ configured: false, gateway: 'MarzPay Uganda' });

  // Pending mobile money authorization state
  const [pendingTxn, setPendingTxn] = useState<{
    reference: string;
    amount: number;
    phone: string;
    provider: string;
  } | null>(null);
  const [isCheckingStatus, setIsCheckingStatus] = useState(false);
  const pollTimerRef = useRef<any>(null);

  useEffect(() => {
    checkMarzpayGatewayConfig().then((info) => {
      setGatewayInfo(info);
    });

    // Auto-check any pending deposit that may have completed while user was away
    const recentPending = transactions.find(
      (t) => t.userId === currentUser.id && t.type === 'deposit' && t.status === 'pending' && t.providerReference
    );
    if (recentPending && recentPending.providerReference) {
      verifyPendingTransaction(recentPending.providerReference, recentPending.amountUGX);
    }

    return () => {
      if (pollTimerRef.current) clearInterval(pollTimerRef.current);
    };
  }, []);

  const userTransactions = transactions
    .filter((t) => t.userId === currentUser.id)
    .slice(0, 5); // Show latest 5 transactions only for simplicity

  const handleSelectPreset = (amt: number) => {
    setDepositAmount(amt);
    setErrorMessage(null);
    setSuccessMessage(null);
  };

  const handleCustomAmountChange = (val: string) => {
    const numeric = parseInt(val.replace(/[^0-9]/g, ''), 10) || 0;
    setDepositAmount(numeric);
    setErrorMessage(null);
    setSuccessMessage(null);
  };

  const handlePhoneChange = (val: string) => {
    setPhoneNumber(val);
    setErrorMessage(null);
    if (val.length >= 4) {
      const detected = detectProviderFromPhone(val);
      if (detected === 'mtn_momo' || detected === 'airtel_money') {
        setDepositMethod(detected);
      }
    }
  };

  const creditSuccessfulDeposit = (amount: number, reference: string, newBalance?: number) => {
    const targetBalance = typeof newBalance === 'number' && newBalance > 0
      ? newBalance
      : currentUser.balanceUGX + amount;

    const updatedUser: User = {
      ...currentUser,
      balanceUGX: targetBalance,
    };
    updateUser(updatedUser);
    onBalanceUpdated(updatedUser);

    // Sync transaction status to completed in storage and Firebase RTDB
    updateTransactionStatus(reference, 'completed', amount);

    addNotification({
      id: 'notif_' + Date.now(),
      userId: currentUser.id,
      title: 'Deposit Confirmed 🎉',
      message: `Exact deposit of UGX ${amount.toLocaleString()} received and credited to your wallet. Ref: ${reference}`,
      read: false,
      type: 'success',
      createdAt: new Date().toISOString(),
    });

    setSuccessMessage(`UGX ${amount.toLocaleString()} verified by MarzPay and credited to your wallet!`);
    setPendingTxn(null);
    if (pollTimerRef.current) clearInterval(pollTimerRef.current);

    try {
      confetti({
        particleCount: 70,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#FF1E40', '#FF4500', '#FF7A00', '#FFAA00'],
      });
    } catch {}
  };

  // Check pending transaction status on demand or via poll
  const verifyPendingTransaction = async (reference: string, expectedAmount: number) => {
    setIsCheckingStatus(true);
    try {
      const statusRes = await checkMarzpayTransactionStatus(reference, expectedAmount, currentUser.id);
      if (statusRes.status === 'completed') {
        const verifiedAmount = statusRes.verifiedAmount || expectedAmount;
        creditSuccessfulDeposit(verifiedAmount, reference, statusRes.newBalance);
      } else if (statusRes.status === 'amount_mismatch') {
        setErrorMessage(
          `Security Alert: MarzPay received UGX ${statusRes.receivedAmount?.toLocaleString()}, but expected UGX ${statusRes.expectedAmount?.toLocaleString()}. Your wallet was NOT credited to protect your account. Please contact support.`
        );
        setPendingTxn(null);
        if (pollTimerRef.current) clearInterval(pollTimerRef.current);
        updateTransactionStatus(reference, 'failed');
      } else if (statusRes.status === 'failed') {
        setErrorMessage(statusRes.message || 'Transaction was declined, cancelled, or expired on phone.');
        setPendingTxn(null);
        if (pollTimerRef.current) clearInterval(pollTimerRef.current);
        updateTransactionStatus(reference, 'failed');
      }
    } catch (err) {
      console.warn('Status verification error:', err);
    } finally {
      setIsCheckingStatus(false);
    }
  };

  const handleDepositSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessMessage(null);
    setPendingTxn(null);
    if (pollTimerRef.current) clearInterval(pollTimerRef.current);

    if (depositAmount < 1000) {
      setErrorMessage('Minimum deposit is UGX 1,000');
      return;
    }

    if (!phoneNumber || phoneNumber.trim().length < 9) {
      setErrorMessage('Enter a valid Ugandan phone number (e.g. +256 772...)');
      return;
    }

    setIsProcessing(true);

    try {
      const response = await initiateMarzpayDeposit({
        amountUGX: depositAmount,
        phoneNumber,
        provider: depositMethod,
        userId: currentUser.id,
        userName: currentUser.fullName,
        email: currentUser.email,
        description: `VYRO Balance Deposit - UGX ${depositAmount.toLocaleString()}`,
      });

      setIsProcessing(false);

      if (!response.success) {
        setErrorMessage(response.message || 'Payment request failed. Please verify your phone number and try again.');
        return;
      }

      // Record transaction
      const newTxn: Transaction = {
        id: 'txn_' + Date.now(),
        userId: currentUser.id,
        userName: currentUser.fullName,
        amountUGX: depositAmount,
        currency: 'UGX',
        type: 'deposit',
        paymentProvider: 'marzpay',
        providerReference: response.reference,
        status: response.status === 'completed' ? 'completed' : 'pending',
        createdAt: new Date().toISOString(),
        phoneNumber: formatUgandanPhone(phoneNumber),
      };
      addTransaction(newTxn);

      if (response.status === 'completed') {
        creditSuccessfulDeposit(depositAmount, response.reference);
      } else {
        // Pending USSD authorization on phone
        setPendingTxn({
          reference: response.reference,
          amount: depositAmount,
          phone: formatUgandanPhone(phoneNumber),
          provider: depositMethod === 'mtn_momo' ? 'MTN MoMo' : 'Airtel Money',
        });

        // Set up poll every 4 seconds for up to 120 seconds (30 attempts)
        let attempts = 0;
        pollTimerRef.current = setInterval(async () => {
          attempts++;
          if (attempts > 30) {
            clearInterval(pollTimerRef.current);
            return;
          }
          await verifyPendingTransaction(response.reference, depositAmount);
        }, 4000);
      }
    } catch (err: any) {
      setIsProcessing(false);
      setErrorMessage(err.message || 'Connection error. Please try again.');
    }
  };

  return (
    <div className="w-full max-w-lg mx-auto px-4 py-6 space-y-5 animate-in fade-in duration-300">
      
      {/* 1. COMPACT BALANCE CARD */}
      <div className="bg-white dark:bg-[#111A32] rounded-3xl p-5 border border-[#E1E7F3] dark:border-slate-800 shadow-sm flex items-center justify-between">
        <div>
          <span className="text-[11px] font-bold text-[#68738B] dark:text-slate-400 uppercase tracking-wider">
            Available Balance
          </span>
          <div className="flex items-baseline gap-1 mt-0.5">
            <span className="text-xs font-bold text-[#68738B]">UGX</span>
            <span className="text-2xl sm:text-3xl font-black text-[#10172A] dark:text-white tracking-tight">
              {currentUser.balanceUGX.toLocaleString()}
            </span>
          </div>
          <div className="flex items-center gap-1.5 mt-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
            <span className="text-[11px] text-[#68738B] dark:text-slate-400 font-medium">
              Secured by MarzPay Mobile Money
            </span>
          </div>
        </div>

        <button
          onClick={onNavigateToCampaigns}
          className="px-4 py-2.5 rounded-full text-white text-xs font-black shadow-vyro-glow hover:opacity-95 transition-all flex items-center gap-1.5 cursor-pointer"
          style={{
            background: 'linear-gradient(110deg, #FF1E40 0%, #FF4500 38%, #FF7A00 75%, #FFAA00 100%)',
          }}
        >
          <Zap className="w-3.5 h-3.5 fill-white" />
          <span>New Order</span>
        </button>
      </div>

      {/* 2. DEPOSIT PANEL */}
      <div className="bg-white dark:bg-[#111A32] rounded-3xl p-5 border border-[#E1E7F3] dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-sm font-black text-[#10172A] dark:text-white">
              Add Funds to Wallet
            </h2>
            <p className="text-[11px] text-[#68738B] dark:text-slate-400">
              Instant MTN MoMo & Airtel Money deposit
            </p>
          </div>

          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/60 text-[10px] font-bold text-emerald-700 dark:text-emerald-400">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            <span>{gatewayInfo.configured ? 'MarzPay Live' : 'MarzPay Gateway'}</span>
          </div>
        </div>

        {/* Status Alerts */}
        {errorMessage && (
          <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 flex items-start gap-2 text-xs text-rose-700 dark:text-rose-300">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <div className="flex-1">
              <span className="font-bold">Deposit Issue: </span>
              <span>{errorMessage}</span>
            </div>
            <button onClick={() => setErrorMessage(null)} className="text-rose-500 hover:text-rose-700 cursor-pointer">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {successMessage && (
          <div className="p-3 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 flex items-center gap-2 text-xs text-emerald-700 dark:text-emerald-300">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* Active Pending USSD Card */}
        {pendingTxn && (
          <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/60 space-y-3">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-full bg-amber-500/20 text-amber-600 flex items-center justify-center shrink-0">
                <Smartphone className="w-4 h-4 animate-bounce" />
              </div>
              <div className="flex-1">
                <h4 className="text-xs font-black text-amber-900 dark:text-amber-200">
                  PIN Prompt Sent to Your Phone
                </h4>
                <p className="text-[11px] text-amber-700 dark:text-amber-300 mt-0.5 leading-relaxed">
                  Please check <span className="font-bold">{pendingTxn.phone}</span> ({pendingTxn.provider}) to enter your Mobile Money PIN and authorize <span className="font-bold">UGX {pendingTxn.amount.toLocaleString()}</span>.
                </p>
                <p className="text-[10px] text-amber-600 dark:text-amber-400 font-mono mt-1">
                  Ref: {pendingTxn.reference}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                type="button"
                onClick={() => verifyPendingTransaction(pendingTxn.reference, pendingTxn.amount)}
                disabled={isCheckingStatus}
                className="flex-1 py-2 px-3 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isCheckingStatus ? 'animate-spin' : ''}`} />
                <span>{isCheckingStatus ? 'Checking Status...' : "I've Entered My PIN"}</span>
              </button>

              <button
                type="button"
                onClick={() => setPendingTxn(null)}
                className="py-2 px-3 rounded-xl bg-amber-100 dark:bg-amber-900/40 text-amber-800 dark:text-amber-300 text-xs font-bold hover:bg-amber-200 transition-colors cursor-pointer"
              >
                Dismiss
              </button>
            </div>
          </div>
        )}

        <form onSubmit={handleDepositSubmit} className="space-y-4">
          {/* Quick Amounts */}
          <div>
            <label className="block text-[11px] font-bold text-[#68738B] dark:text-slate-400 uppercase tracking-wider mb-1.5">
              Amount (UGX)
            </label>
            <div className="grid grid-cols-5 gap-1.5 mb-2">
              {PRESET_AMOUNTS.map((amt) => {
                const isSelected = depositAmount === amt;
                return (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => handleSelectPreset(amt)}
                    className={`py-1.5 rounded-xl text-xs font-bold transition-all border cursor-pointer ${
                      isSelected
                        ? 'border-[#FF4500] bg-[#FF4500] text-white shadow-xs'
                        : 'border-[#E1E7F3] dark:border-slate-800 bg-[#F4F7FF] dark:bg-[#0B1020] text-[#10172A] dark:text-white hover:border-[#FF4500]/50'
                    }`}
                  >
                    {amt >= 1000 ? `${amt / 1000}k` : amt}
                  </button>
                );
              })}
            </div>

            <div className="relative">
              <span className="absolute left-3 top-2.5 text-xs font-bold text-[#68738B]">
                UGX
              </span>
              <input
                type="text"
                value={depositAmount > 0 ? depositAmount.toLocaleString() : ''}
                onChange={(e) => handleCustomAmountChange(e.target.value)}
                placeholder="50,000"
                className="w-full pl-11 pr-3 py-2 rounded-xl border border-[#E1E7F3] dark:border-slate-800 bg-[#F4F7FF] dark:bg-[#0B1020] text-sm font-bold text-[#10172A] dark:text-white focus:outline-none focus:border-[#FF4500]"
              />
            </div>
          </div>

          {/* Payment Method Selector - MTN MoMo & Airtel Money */}
          <div>
            <label className="block text-[11px] font-bold text-[#68738B] dark:text-slate-400 uppercase tracking-wider mb-1.5">
              Mobile Money Network
            </label>
            <div className="grid grid-cols-2 gap-2.5">
              {/* MTN */}
              <button
                type="button"
                onClick={() => setDepositMethod('mtn_momo')}
                className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                  depositMethod === 'mtn_momo'
                    ? 'border-[#FFCC00] bg-[#FFCC00]/15 shadow-xs'
                    : 'border-[#E1E7F3] dark:border-slate-800 bg-[#F4F7FF] dark:bg-[#0B1020] hover:border-slate-400'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-xl bg-[#FFCC00] text-black font-black text-[11px] flex items-center justify-center shrink-0">
                    MTN
                  </div>
                  <div>
                    <p className="text-xs font-bold text-[#10172A] dark:text-white leading-tight">
                      MTN MoMo
                    </p>
                    <p className="text-[10px] text-[#68738B]">Instant PIN Prompt</p>
                  </div>
                </div>
                <div className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${
                  depositMethod === 'mtn_momo' ? 'border-[#FFCC00] bg-[#FFCC00]' : 'border-slate-300'
                }`}>
                  {depositMethod === 'mtn_momo' && <div className="w-1.5 h-1.5 rounded-full bg-black" />}
                </div>
              </button>

              {/* Airtel */}
              <button
                type="button"
                onClick={() => setDepositMethod('airtel_money')}
                className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                  depositMethod === 'airtel_money'
                    ? 'border-[#E60000] bg-[#E60000]/15 shadow-xs'
                    : 'border-[#E1E7F3] dark:border-slate-800 bg-[#F4F7FF] dark:bg-[#0B1020] hover:border-slate-400'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 rounded-xl bg-[#E60000] text-white font-black text-[10px] flex items-center justify-center shrink-0">
                    airtel
                  </div>
                  <div>
                    <p className="text-xs font-bold text-[#10172A] dark:text-white leading-tight">
                      Airtel Money
                    </p>
                    <p className="text-[10px] text-[#68738B]">Instant PIN Prompt</p>
                  </div>
                </div>
                <div className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center ${
                  depositMethod === 'airtel_money' ? 'border-[#E60000] bg-[#E60000]' : 'border-slate-300'
                }`}>
                  {depositMethod === 'airtel_money' && <div className="w-1.5 h-1.5 rounded-full bg-white" />}
                </div>
              </button>
            </div>
          </div>

          {/* Phone Input */}
          <div>
            <label className="block text-[11px] font-bold text-[#68738B] dark:text-slate-400 uppercase tracking-wider mb-1.5">
              Phone Number for PIN Prompt
            </label>
            <div className="relative">
              <Smartphone className="w-4 h-4 text-[#68738B] absolute left-3 top-2.5" />
              <input
                type="tel"
                required
                value={phoneNumber}
                onChange={(e) => handlePhoneChange(e.target.value)}
                placeholder="+256 772 123 456"
                className="w-full pl-9 pr-3 py-2 rounded-xl border border-[#E1E7F3] dark:border-slate-800 bg-[#F4F7FF] dark:bg-[#0B1020] text-xs sm:text-sm font-bold text-[#10172A] dark:text-white focus:outline-none focus:border-[#FF4500]"
              />
            </div>
          </div>

          {/* Action Button */}
          <div className="pt-1">
            <button
              type="submit"
              disabled={isProcessing || depositAmount < 1000}
              className="w-full py-3 px-4 rounded-full text-white text-xs sm:text-sm font-black shadow-vyro-glow hover:opacity-95 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              style={{
                background: 'linear-gradient(110deg, #FF1E40 0%, #FF4500 38%, #FF7A00 75%, #FFAA00 100%)',
              }}
            >
              {isProcessing ? (
                <>
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Connecting to MarzPay Gateway...</span>
                </>
              ) : (
                <span>
                  Deposit UGX {depositAmount.toLocaleString()} via {depositMethod === 'mtn_momo' ? 'MTN MoMo' : 'Airtel Money'}
                </span>
              )}
            </button>
            <p className="text-center text-[10px] text-[#68738B] dark:text-slate-400 mt-2 flex items-center justify-center gap-1">
              <Lock className="w-3 h-3 text-emerald-500" />
              <span>Prompt will appear on your phone to enter your PIN</span>
            </p>
          </div>
        </form>
      </div>

      {/* REFERRAL SYSTEM */}
      <div className="bg-gradient-to-r from-[#5B4BFF]/10 via-[#8B5CF6]/10 to-[#EC4899]/10 rounded-3xl p-5 border border-[#8B5CF6]/20 shadow-sm relative overflow-hidden">
        <div className="absolute -right-4 -top-4 w-24 h-24 bg-[#8B5CF6]/20 rounded-full blur-2xl" />
        
        <div className="flex items-center gap-3 mb-2 relative z-10">
          <div className="w-8 h-8 rounded-xl bg-white dark:bg-[#111A32] shadow-sm flex items-center justify-center text-[#8B5CF6]">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-sm font-black text-[#10172A] dark:text-white leading-tight">Invite & Earn 10%</h3>
            <p className="text-[10px] text-[#68738B] dark:text-slate-400">Earn from your friend's first deposit</p>
          </div>
        </div>

        <div className="bg-white dark:bg-[#111A32] rounded-2xl p-3 border border-[#E1E7F3] dark:border-slate-800 flex items-center justify-between gap-3 relative z-10 mt-3">
          <div className="flex-1 overflow-hidden">
            <p className="text-[10px] text-[#68738B] dark:text-slate-400 uppercase tracking-wider font-bold mb-0.5">Your Referral Code</p>
            <p className="text-sm font-black text-[#10172A] dark:text-white tracking-widest">{currentUser.referralCode || 'NO_CODE'}</p>
          </div>
          <button
            onClick={() => {
              navigator.clipboard.writeText(`https://vyro.io/signup?ref=${currentUser.referralCode}`);
              setSuccessMessage('Referral link copied to clipboard!');
              setTimeout(() => setSuccessMessage(null), 3000);
            }}
            className="px-3 py-2 bg-[#F4F7FF] dark:bg-[#1A2548] text-[#8B5CF6] dark:text-[#22D3EE] text-xs font-bold rounded-xl hover:bg-[#8B5CF6]/10 transition-colors shrink-0"
          >
            Copy Link
          </button>
        </div>

        <div className="mt-3 flex justify-between items-end relative z-10">
          <div>
            <p className="text-[10px] text-[#68738B] font-bold">Referral Earnings</p>
            <p className="text-sm font-black text-emerald-600">UGX {(currentUser.referralEarningsUGX || 0).toLocaleString()}</p>
          </div>
        </div>
      </div>

      {/* 3. RECENT ACTIVITY (COMPACT) */}
      <div className="bg-white dark:bg-[#111A32] rounded-3xl p-5 border border-[#E1E7F3] dark:border-slate-800 shadow-sm">
        <h3 className="text-xs font-bold text-[#68738B] dark:text-slate-400 uppercase tracking-wider mb-3">
          Recent Activity
        </h3>

        {userTransactions.length === 0 ? (
          <p className="text-xs text-[#68738B] text-center py-3">No transactions yet.</p>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800/60">
            {userTransactions.map((txn) => {
              const isDeposit = txn.type === 'deposit';
              return (
                <div
                  key={txn.id}
                  onClick={() => setSelectedReceipt(txn)}
                  className="py-2.5 flex items-center justify-between gap-3 hover:bg-slate-50 dark:hover:bg-slate-800/30 px-2 rounded-xl transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-2.5">
                    <div
                      className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${
                        isDeposit ? 'bg-emerald-500/10 text-emerald-600' : 'bg-[#FF4500]/10 text-[#FF4500]'
                      }`}
                    >
                      {isDeposit ? <ArrowDownLeft className="w-3.5 h-3.5" /> : <ArrowUpRight className="w-3.5 h-3.5" />}
                    </div>
                    <div>
                      <p className="text-xs font-bold text-[#10172A] dark:text-white leading-tight">
                        {isDeposit ? 'Mobile Money Deposit' : (txn.campaignTitle || 'Order')}
                      </p>
                      <p className="text-[10px] text-[#68738B]">
                        {new Date(txn.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>

                  <div className="text-right">
                    <span
                      className={`text-xs font-extrabold ${
                        isDeposit ? 'text-emerald-600' : 'text-[#10172A] dark:text-white'
                      }`}
                    >
                      {isDeposit ? '+' : '-'} UGX {txn.amountUGX.toLocaleString()}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* COMPACT RECEIPT POPUP */}
      {selectedReceipt && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-[#111A32] rounded-3xl max-w-xs w-full p-5 border border-[#E1E7F3] dark:border-slate-800 shadow-2xl">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-black text-[#10172A] dark:text-white">Receipt</span>
              <button
                onClick={() => setSelectedReceipt(null)}
                className="p-1 text-[#68738B] hover:text-[#10172A] dark:hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="text-center py-3 bg-[#F4F7FF] dark:bg-[#0B1020] rounded-2xl mb-3">
              <p className="text-[10px] text-[#68738B] uppercase font-bold">Amount</p>
              <h4 className="text-xl font-black text-[#10172A] dark:text-white">
                UGX {selectedReceipt.amountUGX.toLocaleString()}
              </h4>
              <span className={`text-[9px] font-bold uppercase ${
                selectedReceipt.status === 'completed' ? 'text-emerald-600' : selectedReceipt.status === 'pending' ? 'text-amber-500' : 'text-rose-500'
              }`}>
                {selectedReceipt.status}
              </span>
            </div>

            <div className="space-y-1.5 text-xs text-[#68738B]">
              <div className="flex justify-between">
                <span>Ref:</span>
                <span className="font-mono font-bold text-[#10172A] dark:text-white">{selectedReceipt.providerReference}</span>
              </div>
              <div className="flex justify-between">
                <span>Type:</span>
                <span className="font-bold text-[#10172A] dark:text-white capitalize">{selectedReceipt.type.replace('_', ' ')}</span>
              </div>
              <div className="flex justify-between">
                <span>Date:</span>
                <span className="text-[#10172A] dark:text-white">{new Date(selectedReceipt.createdAt).toLocaleDateString()}</span>
              </div>
            </div>

            <button
              onClick={() => setSelectedReceipt(null)}
              className="w-full mt-4 py-2 rounded-full bg-slate-100 dark:bg-slate-800 text-xs font-bold text-[#10172A] dark:text-white cursor-pointer"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default WalletPage;
