import React, { useState } from 'react';
import { VyroLogo } from '../common/BrandIcons';
import { User, NotificationItem } from '../../types';
import { 
  Bell, 
  MoreHorizontal, 
  Menu, 
  X, 
  PlusCircle, 
  Wallet, 
  BarChart3, 
  ShieldCheck, 
  LogOut, 
  Sparkles,
  Smartphone,
  Monitor,
  User as UserIcon,
  HelpCircle,
  Layers
} from 'lucide-react';

interface NavbarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  currentUser: User | null;
  onLogout: () => void;
  onOpenAuth: (mode: 'login' | 'register') => void;
  notifications: NotificationItem[];
  onOpenNotifications: () => void;
  isMobileFrame: boolean;
  onToggleMobileFrame: () => void;
  isFirebaseConnected?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  currentUser,
  onLogout,
  onOpenAuth,
  notifications,
  onOpenNotifications,
  isMobileFrame,
  onToggleMobileFrame,
  isFirebaseConnected = false,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  const unreadCount = notifications.filter((n) => !n.read).length;

  const handleNav = (view: string) => {
    onNavigate(view);
    setMobileMenuOpen(false);
    setUserDropdownOpen(false);
  };

  return (
    <header className="sticky top-3 z-40 px-3 sm:px-6 w-full max-w-7xl mx-auto transition-all duration-200">
      {/* Main Rounded Navigation Bar */}
      <div
        id="vyro-nav-container"
        className="bg-white/95 dark:bg-[#111A32]/95 backdrop-blur-xl border border-[#E1E7F3] dark:border-[#7357FF]/25 rounded-2xl sm:rounded-full px-4 sm:px-6 py-2.5 sm:py-3 shadow-vyro-card flex items-center justify-between transition-colors"
      >
        {/* Left: Logo */}
        <div className="flex items-center gap-2.5">
          <VyroLogo
            size="md"
            onClick={() => handleNav('landing')}
          />
          {isFirebaseConnected && (
            <span 
              className="hidden lg:inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20"
              title="Realtime Firebase Backend Connected"
            >
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span>Live RTDB</span>
            </span>
          )}
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-1 lg:gap-1.5">
          <button
            id="nav-link-home"
            onClick={() => handleNav(currentUser ? 'dashboard' : 'landing')}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold tracking-tight transition-all ${
              currentView === 'landing' || currentView === 'dashboard'
                ? 'bg-[#7357FF]/10 text-[#7357FF] dark:bg-[#7357FF]/20 dark:text-[#22D3EE]'
                : 'text-[#10172A]/75 dark:text-slate-300 hover:text-[#7357FF] dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800/50'
            }`}
          >
            {currentUser ? 'Dashboard' : 'Home'}
          </button>

          {currentUser && (
            <>
              <button
                id="nav-link-orders"
                onClick={() => handleNav('orders')}
                className={`px-3 py-1.5 rounded-full text-xs font-semibold tracking-tight transition-all ${
                  currentView === 'orders'
                    ? 'bg-[#7357FF]/10 text-[#7357FF] dark:bg-[#7357FF]/20 dark:text-[#22D3EE]'
                    : 'text-[#10172A]/75 dark:text-slate-300 hover:text-[#7357FF] dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800/50'
                }`}
              >
                Orders
              </button>
              <button
                id="nav-link-wallet"
                onClick={() => handleNav('wallet')}
                className={`px-3 py-1.5 rounded-full text-xs font-semibold tracking-tight transition-all ${
                  currentView === 'wallet'
                    ? 'bg-[#7357FF]/10 text-[#7357FF] dark:bg-[#7357FF]/20 dark:text-[#22D3EE]'
                    : 'text-[#10172A]/75 dark:text-slate-300 hover:text-[#7357FF] dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800/50'
                }`}
              >
                Wallet
              </button>

              {currentUser.role === 'admin' && (
                <button
                  id="nav-link-admin"
                  onClick={() => handleNav('admin')}
                  className={`px-3 py-1.5 rounded-full text-xs font-bold tracking-tight transition-all flex items-center gap-1 ${
                    currentView === 'admin'
                      ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400'
                      : 'text-amber-700 dark:text-amber-400/80 hover:text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-950/30'
                  }`}
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  Admin
                </button>
              )}
            </>
          )}
        </nav>

        {/* Right Area: Controls & Mobile Actions */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Viewport Frame Toggle (Mobile Preview vs Full Desktop) */}
          <button
            id="viewport-toggle-btn"
            onClick={onToggleMobileFrame}
            title={isMobileFrame ? 'Switch to Full Desktop Width' : 'Preview in 390px Mobile Frame'}
            className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border border-[#7357FF]/25 bg-[#7357FF]/5 dark:bg-[#7357FF]/15 text-[#7357FF] dark:text-[#22D3EE] hover:bg-[#7357FF]/15 transition-colors"
          >
            {isMobileFrame ? (
              <>
                <Monitor className="w-3.5 h-3.5" />
                <span>Desktop</span>
              </>
            ) : (
              <>
                <Smartphone className="w-3.5 h-3.5" />
                <span>Mobile Frame</span>
              </>
            )}
          </button>

          {/* Quick Boost CTA for Desktop */}
          {currentUser && (
            <button
              id="header-quick-boost-btn"
              onClick={() => handleNav('new-order')}
              className="hidden lg:inline-flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-bold text-white shadow-vyro-glow hover:opacity-95 transition-all transform hover:-translate-y-0.5 active:translate-y-0"
              style={{
                background: 'linear-gradient(110deg, #5B4BFF 0%, #8B5CF6 42%, #EC4899 75%, #FF8A65 100%)',
              }}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>New Order</span>
            </button>
          )}

          {/* Notification Bell Button (only for authenticated creators) */}
          {currentUser && (
            <button
              id="nav-notification-btn"
              onClick={onOpenNotifications}
              aria-label="Notifications"
              className="relative p-2 sm:p-2.5 rounded-full hover:bg-[#F4F7FF] dark:hover:bg-slate-800 text-[#10172A]/80 dark:text-slate-300 hover:text-[#FF4500] dark:hover:text-white transition-colors cursor-pointer"
            >
              <Bell className="w-4 h-4 sm:w-5 sm:h-5" />
              {unreadCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-[#FF4500] text-white text-[10px] font-bold flex items-center justify-center border-2 border-white dark:border-[#111A32] animate-pulse">
                  {unreadCount}
                </span>
              )}
            </button>
          )}

          {/* If unauthenticated and not on landing, show Login / Signup on desktop */}
          {!currentUser && currentView !== 'landing' && (
            <div className="hidden sm:flex items-center gap-1.5 sm:gap-2">
              <button
                id="nav-login-btn"
                onClick={() => onOpenAuth('login')}
                className="px-3.5 py-1.5 rounded-full text-xs sm:text-sm font-semibold text-[#10172A] dark:text-white hover:text-[#FF4500] hover:bg-[#F4F7FF] dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                Log In
              </button>
              <button
                id="nav-register-btn"
                onClick={() => onOpenAuth('register')}
                className="px-4 py-1.5 sm:py-2 rounded-full text-xs sm:text-sm font-bold text-white shadow-vyro-glow hover:opacity-95 transition-all cursor-pointer"
                style={{
                  background: 'linear-gradient(110deg, #FF1E40 0%, #FF4500 38%, #FF7A00 75%, #FFAA00 100%)',
                }}
              >
                Sign Up
              </button>
            </div>
          )}

          {/* Drawer / Menu Toggle Button (Opens drawer where profile & navigation live) */}
          <button
            id="nav-drawer-toggle-btn"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Toggle Drawer Menu"
            className="p-2 sm:p-2.5 rounded-full hover:bg-[#F4F7FF] dark:hover:bg-slate-800 text-[#10172A] dark:text-white transition-colors cursor-pointer border border-[#E1E7F3] dark:border-[#FF4500]/25 flex items-center justify-center gap-1.5"
          >
            {mobileMenuOpen ? (
              <X className="w-5 h-5 text-[#FF4500]" />
            ) : (
              <>
                <Menu className="w-5 h-5" />
                <span className="hidden sm:inline text-xs font-bold text-[#10172A] dark:text-white">Menu</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Drawer Menu (Contains Profile Section, Navigation Links, and Account Controls) */}
      {mobileMenuOpen && (
        <div
          id="nav-drawer-menu"
          className="mt-2 bg-white dark:bg-[#111A32] rounded-3xl p-4 sm:p-5 shadow-2xl border border-[#E1E7F3] dark:border-[#FF4500]/30 animate-in fade-in slide-in-from-top-3 duration-200 max-w-md ml-auto"
        >
          {/* PROFILE SECTION INSIDE DRAWER */}
          {currentUser && (
            <div className="mb-4 p-3.5 rounded-2xl bg-[#F4F7FF] dark:bg-slate-900/80 border border-[#E1E7F3] dark:border-slate-800 flex items-center justify-between">
              <div 
                className="flex items-center gap-3 cursor-pointer"
                onClick={() => handleNav('profile')}
              >
                <img
                  src={currentUser.avatarUrl}
                  alt={currentUser.fullName}
                  className="w-11 h-11 rounded-full object-cover ring-2 ring-[#FF4500]/50 shadow-sm"
                />
                <div>
                  <p className="text-sm font-extrabold text-[#10172A] dark:text-white flex items-center gap-1.5">
                    {currentUser.fullName}
                    {currentUser.role === 'admin' && (
                      <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-500/20 text-amber-600 dark:text-amber-400">
                        Admin
                      </span>
                    )}
                  </p>
                  <p className="text-xs text-[#68738B] dark:text-slate-400">
                    @{currentUser.username}
                  </p>
                </div>
              </div>

              {/* Wallet Balance Pill */}
              <div 
                onClick={() => handleNav('wallet')}
                className="cursor-pointer text-right px-3 py-1.5 rounded-xl bg-[#FF4500]/10 dark:bg-[#FF4500]/20 border border-[#FF4500]/25 text-[#FF4500] dark:text-[#FFAA00]"
              >
                <span className="text-[10px] font-bold uppercase tracking-wider block text-[#68738B] dark:text-slate-400">Balance</span>
                <span className="text-xs font-black">UGX {currentUser.balanceUGX.toLocaleString()}</span>
              </div>
            </div>
          )}

          <div className="space-y-1">
            <button
              onClick={() => handleNav(currentUser ? 'dashboard' : 'landing')}
              className={`w-full text-left px-4 py-2.5 rounded-2xl text-sm font-bold flex items-center gap-2.5 transition-colors ${
                currentView === 'landing' || currentView === 'dashboard'
                  ? 'bg-[#FF4500]/10 text-[#FF4500] dark:text-[#FFAA00]'
                  : 'text-[#10172A] dark:text-white hover:bg-slate-50 dark:hover:bg-slate-800/50'
              }`}
            >
              <BarChart3 className="w-4 h-4 text-[#FF4500]" />
              {currentUser ? 'Dashboard' : 'Home'}
            </button>

            {currentUser ? (
              <>
                <button
                  onClick={() => handleNav('new-order')}
                  className={`w-full text-left px-4 py-2.5 rounded-2xl text-sm font-bold flex items-center gap-2.5 transition-colors ${
                    currentView === 'new-order'
                      ? 'bg-[#FF4500]/10 text-[#FF4500] dark:text-[#FFAA00]'
                      : 'text-[#10172A] dark:text-white hover:bg-slate-50 dark:hover:bg-slate-800/50'
                  }`}
                >
                  <PlusCircle className="w-4 h-4 text-[#FF4500]" />
                  New Order
                </button>
                <button
                  onClick={() => handleNav('orders')}
                  className={`w-full text-left px-4 py-2.5 rounded-2xl text-sm font-bold flex items-center gap-2.5 transition-colors ${
                    currentView === 'orders'
                      ? 'bg-[#FF4500]/10 text-[#FF4500] dark:text-[#FFAA00]'
                      : 'text-[#10172A] dark:text-white hover:bg-slate-50 dark:hover:bg-slate-800/50'
                  }`}
                >
                  <Sparkles className="w-4 h-4 text-[#FF7A00]" />
                  My Orders
                </button>
                <button
                  onClick={() => handleNav('wallet')}
                  className={`w-full text-left px-4 py-2.5 rounded-2xl text-sm font-bold flex items-center gap-2.5 transition-colors ${
                    currentView === 'wallet'
                      ? 'bg-[#FF4500]/10 text-[#FF4500] dark:text-[#FFAA00]'
                      : 'text-[#10172A] dark:text-white hover:bg-slate-50 dark:hover:bg-slate-800/50'
                  }`}
                >
                  <Wallet className="w-4 h-4 text-[#FFAA00]" />
                  Wallet & Add Funds
                </button>
                <button
                  onClick={() => handleNav('profile')}
                  className={`w-full text-left px-4 py-2.5 rounded-2xl text-sm font-bold flex items-center gap-2.5 transition-colors ${
                    currentView === 'profile'
                      ? 'bg-[#FF4500]/10 text-[#FF4500] dark:text-[#FFAA00]'
                      : 'text-[#10172A] dark:text-white hover:bg-slate-50 dark:hover:bg-slate-800/50'
                  }`}
                >
                  <UserIcon className="w-4 h-4 text-[#FF4500]" />
                  Profile & Settings
                </button>
                {currentUser.role === 'admin' && (
                  <button
                    onClick={() => handleNav('admin')}
                    className="w-full text-left px-4 py-2.5 rounded-2xl text-sm font-bold text-amber-600 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-amber-950/30 flex items-center gap-2.5"
                  >
                    <ShieldCheck className="w-4 h-4 text-amber-500" />
                    Admin Panel
                  </button>
                )}
                <div className="border-t border-[#E1E7F3] dark:border-slate-800 my-2" />
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onLogout();
                  }}
                  className="w-full text-left px-4 py-2.5 rounded-2xl text-sm font-bold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 flex items-center gap-2.5 cursor-pointer"
                >
                  <LogOut className="w-4 h-4" />
                  Sign Out
                </button>
              </>
            ) : (
              <div className="pt-2 flex flex-col gap-2">
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenAuth('login');
                  }}
                  className="w-full py-2.5 rounded-2xl border border-[#E1E7F3] dark:border-slate-700 text-[#10172A] dark:text-white text-sm font-bold text-center hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
                >
                  Log In
                </button>
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenAuth('register');
                  }}
                  className="w-full py-2.5 rounded-2xl text-white text-sm font-bold text-center shadow-vyro-glow hover:opacity-95 cursor-pointer"
                  style={{
                    background: 'linear-gradient(110deg, #FF1E40 0%, #FF4500 38%, #FF7A00 75%, #FFAA00 100%)',
                  }}
                >
                  Sign Up
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
