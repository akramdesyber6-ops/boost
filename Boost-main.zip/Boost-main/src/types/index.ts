export type Platform = 'tiktok' | 'instagram' | 'youtube' | 'facebook' | 'x' | 'telegram' | 'whatsapp';

export type CampaignGoal = 
  | 'audience_growth' 
  | 'content_reach' 
  | 'engagement' 
  | 'website_traffic' 
  | 'video_promotion' 
  | 'brand_awareness';

export type CampaignStatus = 
  | 'draft' 
  | 'awaiting_payment' 
  | 'pending_review' 
  | 'active' 
  | 'paused' 
  | 'completed' 
  | 'cancelled' 
  | 'failed';

export interface User {
  id: string;
  fullName: string;
  username: string;
  email: string;
  avatarUrl: string;
  role: 'user' | 'admin';
  balanceUGX: number;
  pendingBalanceUGX: number;
  phone?: string;
  howHeard?: string;
  themePreference?: 'light' | 'dark' | 'system';
  referralCode?: string;
  referredBy?: string;
  referralEarningsUGX?: number;
  referralsCount?: number;
  hasMadeFirstTransaction?: boolean;
  connectedAccounts?: {
    tiktok?: string;
    instagram?: string;
    youtube?: string;
    x?: string;
    facebook?: string;
    telegram?: string;
    whatsapp?: string;
  };
  notificationPreferences?: {
    email: boolean;
    campaignUpdates: boolean;
    security: boolean;
    marketing: boolean;
  };
  createdAt: string;
}

export interface Campaign {
  id: string;
  userId: string;
  userName?: string;
  goal: CampaignGoal;
  platform: Platform;
  destinationUrl: string;
  description: string;
  budgetUGX: number;
  durationDays: number;
  estimatedReach: {
    min: number;
    max: number;
    metricLabel: string;
  };
  status: CampaignStatus;
  progressPercentage: number;
  impressionsDelivered: number;
  targetImpressions: number;
  engagementsCount: number;
  createdAt: string;
  updatedAt: string;
  paymentReference?: string;
  smmOrderId?: string | number;
  serviceCategory?: string;
}

export type Order = Campaign;
export type OrderGoal = CampaignGoal;
export type OrderStatus = CampaignStatus;

export interface Transaction {
  id: string;
  userId: string;
  userName?: string;
  campaignId?: string;
  campaignTitle?: string;
  amountUGX: number;
  currency: 'UGX';
  type: 'deposit' | 'campaign_spend' | 'refund' | 'referral_bonus';
  paymentProvider: 'marzpay' | 'pesapal' | 'mtn_momo' | 'airtel_money' | 'card' | 'wallet';
  providerReference: string;
  status: 'completed' | 'pending' | 'failed';
  createdAt: string;
  phoneNumber?: string;
}

export interface NotificationItem {
  id: string;
  userId: string;
  title: string;
  message: string;
  read: boolean;
  type: 'success' | 'info' | 'warning';
  createdAt: string;
  link?: string;
}

export interface ServiceDefinition {
  id: string;
  name: string;
  platform: Platform;
  description: string;
  minBudgetUGX: number;
  ratePer1kImpressionsUGX: number;
  active: boolean;
  category: 'followers' | 'likes' | 'views' | 'comments';
}
