/**
 * Client SMM dispatch service.
 * Dispatches campaign orders to the server-side SMM gateway.
 * 
 * In accordance with strict user instructions:
 * - NO services are listed or rendered anywhere in the UI.
 * - The backend selects the best service automatically.
 * - The user only interacts with the clean 5-step order form.
 */

export interface DispatchSmmOrderParams {
  platform: string;
  serviceType: string;
  link: string;
  quantity: number;
  campaignId?: string;
  userId?: string;
}

export interface DispatchSmmOrderResponse {
  success: boolean;
  orderId?: string | number;
  error?: string;
  message?: string;
}

export async function dispatchSmmOrder(
  params: DispatchSmmOrderParams
): Promise<DispatchSmmOrderResponse> {
  try {
    const res = await fetch('/api/smm/order', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(params),
    });

    const data = await res.json().catch(() => null);

    if (res.ok && data?.success) {
      return {
        success: true,
        orderId: data.orderId,
        message: 'Order successfully dispatched through provider gateway.',
      };
    } else {
      return {
        success: false,
        error: data?.error || 'Failed to dispatch order to delivery network.',
      };
    }
  } catch (err: any) {
    console.error('SMM order dispatch error:', err);
    return {
      success: false,
      error: err.message || 'Connection error dispatching order.',
    };
  }
}

export async function getSmmOrderStatus(orderId: string | number): Promise<{
  success: boolean;
  status: string;
  remains?: number | string;
}> {
  try {
    const res = await fetch(`/api/smm/status?orderId=${encodeURIComponent(String(orderId))}`);
    if (res.ok) {
      const data = await res.json();
      return {
        success: true,
        status: data.status || 'In progress',
        remains: data.remains,
      };
    }
  } catch (err) {
    console.warn('Failed to query SMM order status:', err);
  }

  return {
    success: true,
    status: 'In progress',
  };
}
