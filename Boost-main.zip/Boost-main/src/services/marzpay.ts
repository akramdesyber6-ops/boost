/**
 * Marzpay Payment Service
 * Handles Mobile Money (MTN / Airtel) and Card deposit collections via Marzpay Gateway.
 * API Key and API Secret are safely kept in backend environment variables (Vercel / Container).
 */

export interface MarzpayDepositParams {
  amountUGX: number;
  phoneNumber: string;
  provider: 'mtn_momo' | 'airtel_money' | 'card';
  userId: string;
  userName: string;
  email?: string;
  description?: string;
}

export interface MarzpayDepositResponse {
  success: boolean;
  reference: string;
  status: 'completed' | 'pending' | 'failed';
  message: string;
  checkoutUrl?: string;
  provider: string;
  raw?: any;
}

/**
 * Format Ugandan phone number to standard international format (+256...)
 */
export function formatUgandanPhone(phone: string): string {
  const cleaned = phone.replace(/[\s\-\(\)]/g, '');
  if (cleaned.startsWith('+256')) return cleaned;
  if (cleaned.startsWith('256')) return `+${cleaned}`;
  if (cleaned.startsWith('0')) return `+256${cleaned.substring(1)}`;
  if (cleaned.length === 9) return `+256${cleaned}`;
  return phone;
}

/**
 * Detect network provider from Ugandan phone number
 */
export function detectProviderFromPhone(phone: string): 'mtn_momo' | 'airtel_money' {
  const cleaned = phone.replace(/[\s\-\(\)\+]/g, '');
  // MTN prefixes: 077, 078, 076, 25677, 25678, 25676
  if (
    cleaned.startsWith('077') ||
    cleaned.startsWith('078') ||
    cleaned.startsWith('076') ||
    cleaned.startsWith('25677') ||
    cleaned.startsWith('25678') ||
    cleaned.startsWith('25676')
  ) {
    return 'mtn_momo';
  }
  // Airtel prefixes: 070, 075, 074, 25670, 25675, 25674
  return 'airtel_money';
}

function generateUUID(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

/**
 * Initiate a Marzpay deposit transaction.
 * Calls the backend API endpoint `/api/marzpay/deposit`.
 */
export async function initiateMarzpayDeposit(
  params: MarzpayDepositParams
): Promise<MarzpayDepositResponse> {
  const formattedPhone = formatUgandanPhone(params.phoneNumber);
  const ref = generateUUID();

  try {
    const response = await fetch('/api/marzpay/deposit', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        amount: Math.round(params.amountUGX),
        currency: 'UGX',
        phone_number: formattedPhone,
        phoneNumber: formattedPhone,
        provider: params.provider,
        user_id: params.userId,
        userId: params.userId,
        user_name: params.userName,
        userName: params.userName,
        email: params.email,
        reference: ref,
        description: params.description || `VYRO Deposit - UGX ${Math.round(params.amountUGX).toLocaleString()}`,
      }),
    });

    const data = await response.json().catch(() => null);

    if (response.ok && data) {
      return {
        success: data.success !== false,
        reference: data.reference || ref,
        status: data.status || 'pending',
        message: data.message || 'Payment prompt processed successfully.',
        checkoutUrl: data.checkout_url || data.checkoutUrl,
        provider: params.provider,
        raw: data,
      };
    } else {
      const errorMsg = data?.error || data?.message || `Payment gateway responded with status ${response.status}`;
      return {
        success: false,
        reference: data?.reference || ref,
        status: 'failed',
        message: errorMsg,
        provider: params.provider,
        raw: data,
      };
    }
  } catch (err: any) {
    console.error('Marzpay deposit request failed:', err);
    return {
      success: false,
      reference: ref,
      status: 'failed',
      message: err.message || 'Network error connecting to payment gateway. Please check your internet connection.',
      provider: params.provider,
    };
  }
}

/**
 * Check whether Marzpay Gateway API keys are loaded on the server
 */
export async function checkMarzpayGatewayConfig(): Promise<{
  configured: boolean;
  gateway: string;
  baseUrl?: string;
  keyHint?: string | null;
}> {
  try {
    const res = await fetch('/api/marzpay/config');
    if (res.ok) {
      const data = await res.json();
      return {
        configured: Boolean(data.configured),
        gateway: data.gateway || 'MarzPay Uganda',
        baseUrl: data.baseUrl,
        keyHint: data.keyHint,
      };
    }
  } catch (e) {
    // API route not reachable
  }

  return {
    configured: false,
    gateway: 'MarzPay Uganda',
  };
}

/**
 * Poll or check live transaction status with MarzPay and auto-credit wallet
 */
export async function checkMarzpayTransactionStatus(
  reference: string,
  expectedAmount?: number,
  userId?: string
): Promise<{
  success: boolean;
  reference: string;
  status: 'pending' | 'completed' | 'failed' | 'amount_mismatch';
  credited?: boolean;
  alreadyCredited?: boolean;
  verifiedAmount?: number;
  expectedAmount?: number;
  receivedAmount?: number;
  newBalance?: number;
  message: string;
  data?: any;
}> {
  try {
    const params = new URLSearchParams({ reference });
    if (expectedAmount) params.append('expectedAmount', String(expectedAmount));
    if (userId) params.append('userId', userId);

    const res = await fetch(`/api/marzpay/verify?${params.toString()}`);
    if (res.ok) {
      const data = await res.json();
      return {
        success: data.success !== false,
        reference: data.reference || reference,
        status: data.status || 'pending',
        credited: Boolean(data.credited),
        alreadyCredited: Boolean(data.alreadyCredited),
        verifiedAmount: data.verifiedAmount,
        expectedAmount: data.expectedAmount,
        receivedAmount: data.receivedAmount,
        newBalance: data.newBalance,
        message: data.message || `Status: ${data.status}`,
        data: data.data,
      };
    }
  } catch (err) {
    console.warn('Failed to verify status:', err);
  }

  return {
    success: false,
    reference,
    status: 'pending',
    credited: false,
    message: 'Awaiting PIN verification on phone...',
  };
}

