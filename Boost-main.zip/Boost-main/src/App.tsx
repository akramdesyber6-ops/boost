import React, { useState, useEffect } from 'react';
import { User, Campaign, Transaction, NotificationItem, Platform } from './types';
import { 
  getCurrentUser, 
  getStoredUsers, 
  getStoredCampaigns, 
  getStoredTransactions, 
  getStoredNotifications, 
  setCurrentUser,
  updateUser,
  clearCurrentUser,
  setStoredTheme,
  setStoredUsers,
  setStoredCampaigns,
  setStoredTransactions,
  setStoredNotifications,
  cleanupMockData
} from './lib/storage';
import {
  subscribeToRealtimeCampaigns,
  subscribeToRealtimeTransactions,
  subscribeToRealtimeNotifications,
  subscribeToRealtimeUsers,
  subscribeToConnectionStatus
} from './lib/firebase';
import { Navbar } from './components/navigation/Navbar';
import { LandingPage } from './components/landing/LandingPage';
import { AuthPage } from './components/auth/AuthPage';
import { Dashboard } from './components/dashboard/Dashboard';
import { CampaignWizard } from './components/campaigns/CampaignWizard';
import { CampaignManagement } from './components/campaigns/CampaignManagement';
import { WalletPage } from './components/wallet/WalletPage';
import { AdminPanel } from './components/admin/AdminPanel';
import { ProfilePage } from './components/profile/ProfilePage';
import { NotificationsModal } from './components/common/NotificationsModal';
import { FloatingWhatsApp } from './components/common/FloatingWhatsApp';
import { Smartphone, Monitor, ShieldCheck, Sparkles, Heart } from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUserState] = useState<User | null>(null);
  const [currentView, setCurrentView] = useState<string>('landing');
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isMobileFrame, setIsMobileFrame] = useState(false);
  const [isFirebaseConnected, setIsFirebaseConnected] = useState(false);

  // Preselected parameters for wizard
  const [wizardPreselectedGoal, setWizardPreselectedGoal] = useState<string | undefined>(undefined);
  const [wizardPreselectedPlatform, setWizardPreselectedPlatform] = useState<Platform | undefined>(undefined);

  // App-wide data
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);

  // Load initial data on mount
  const refreshData = () => {
    const users = getStoredUsers();
    setAllUsers(users);
    const user = getCurrentUser();
    setCurrentUserState(user);
    setCampaigns(getStoredCampaigns());
    setTransactions(getStoredTransactions());
    setNotifications(getStoredNotifications());
  };

  useEffect(() => {
    setStoredTheme('light');
    if (typeof document !== 'undefined') {
      document.documentElement.classList.remove('dark');
    }
    
    // Purge mock data and refresh state with clean real-time data
    refreshData();
    cleanupMockData();

    // Attach real-time listeners to Firebase Realtime Database
    const unsubCampaigns = subscribeToRealtimeCampaigns((liveCampaigns) => {
      const items = liveCampaigns || [];
      setCampaigns(items);
      setStoredCampaigns(items);
    });

    const unsubTransactions = subscribeToRealtimeTransactions((liveTxns) => {
      const items = liveTxns || [];
      setTransactions(items);
      setStoredTransactions(items);
    });

    const unsubNotifications = subscribeToRealtimeNotifications((liveNotifs) => {
      const items = liveNotifs || [];
      setNotifications(items);
      setStoredNotifications(items);
    });

    const unsubUsers = subscribeToRealtimeUsers((liveUsers) => {
      const items = liveUsers || [];
      setAllUsers(items);
      setStoredUsers(items);
      setCurrentUserState((prev) => {
        if (!prev) return prev;
        const matched = items.find((u) => u.id === prev.id);
        return matched || prev;
      });
    });

    const unsubConn = subscribeToConnectionStatus((connected) => {
      setIsFirebaseConnected(connected);
    });

    return () => {
      unsubCampaigns();
      unsubTransactions();
      unsubNotifications();
      unsubUsers();
      unsubConn();
    };
  }, []);

  const handleNavigate = (view: string) => {
    setCurrentView(view);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenAuth = (mode: 'login' | 'register') => {
    setAuthMode(mode);
    setCurrentView(mode === 'register' ? 'signup' : 'login');
  };

  const handleAuthSuccess = (user: User) => {
    setCurrentUserState(user);
    refreshData();
    setCurrentView('dashboard');
  };

  const handleLogout = () => {
    clearCurrentUser();
    setCurrentUserState(null);
    setCurrentView('landing');
  };

  const handleStartCampaign = (goal?: string, platform?: Platform) => {
    if (!currentUser) {
      handleOpenAuth('register');
      return;
    }
    setWizardPreselectedGoal(goal);
    setWizardPreselectedPlatform(platform);
    setCurrentView('new-order');
  };

  const handleCampaignCreated = (newCampaign: Campaign) => {
    refreshData();
    setCurrentView('orders');
  };

  return (
    <div className="min-h-screen bg-[#F4F7FF] text-[#10172A] flex flex-col justify-between selection:bg-[#EC4899]/25 selection:text-[#7357FF]">
      {/* Top Navigation Bar */}
      <div className="pt-2 sm:pt-4">
        <Navbar
          currentView={currentView}
          onNavigate={handleNavigate}
          currentUser={currentUser}
          onLogout={handleLogout}
          onOpenAuth={handleOpenAuth}
          notifications={notifications}
          onOpenNotifications={() => setIsNotificationsOpen(true)}
          isMobileFrame={isMobileFrame}
          onToggleMobileFrame={() => setIsMobileFrame(!isMobileFrame)}
          isFirebaseConnected={isFirebaseConnected}
        />
      </div>

      {/* Main Content Area: Responsive or Mobile-Frame Simulation */}
      <main className="flex-1 w-full flex justify-center items-start pt-2 pb-2">
        {isMobileFrame ? (
          /* Mobile Device Frame for Reviewing Exact Screenshot Proportions */
          <div className="my-4 p-3 bg-[#131C35] rounded-[52px] shadow-2xl border-4 border-[#7357FF]/30 max-w-[410px] w-full transition-all">
            {/* Phone Screen Speaker & Dynamic Island */}
            <div className="flex justify-center mb-2">
              <div className="w-24 h-4 bg-black rounded-full flex items-center justify-center">
                <div className="w-2.5 h-2.5 rounded-full bg-[#7357FF]/40 mr-2" />
                <div className="w-8 h-1 bg-slate-800 rounded-full" />
              </div>
            </div>

            <div className="bg-[#F4F7FF] rounded-[42px] overflow-hidden min-h-[780px] max-h-[820px] overflow-y-auto">
              {renderCurrentView()}
            </div>

            {/* Bottom Home Indicator bar */}
            <div className="flex justify-center pt-2">
              <div className="w-32 h-1 bg-white/40 rounded-full" />
            </div>
          </div>
        ) : (
          /* Standard Full Responsive View */
          <div className="w-full">
            {renderCurrentView()}
          </div>
        )}
      </main>

      {/* Notifications Drawer */}
      {currentUser && (
        <NotificationsModal
          userId={currentUser.id}
          notifications={notifications}
          isOpen={isNotificationsOpen}
          onClose={() => setIsNotificationsOpen(false)}
          onRefresh={refreshData}
          onNavigateToCampaigns={() => handleNavigate('orders')}
        />
      )}

      {/* Floating WhatsApp Button */}
      <FloatingWhatsApp />

      {/* Global Minimalist Footer */}
      <footer className="w-full py-4 text-center text-xs text-[#68738B] border-t border-[#E1E7F3] flex items-center justify-center">
        <span>© {new Date().getFullYear()} VYRO</span>
      </footer>
    </div>
  );

  function renderCurrentView() {
    switch (currentView) {
      case 'landing':
        return (
          <LandingPage
            currentUser={currentUser}
            onGetStarted={() => {
              if (currentUser) {
                handleNavigate('dashboard');
              } else {
                handleOpenAuth('register');
              }
            }}
            onLogin={() => handleOpenAuth('login')}
            onSelectPlatformBoost={(plat) => handleStartCampaign('content_reach', plat)}
          />
        );

      case 'signup':
        return (
          <AuthPage
            initialMode="register"
            onSuccess={handleAuthSuccess}
            onCancel={() => handleNavigate('landing')}
          />
        );

      case 'login':
      case 'auth':
        return (
          <AuthPage
            initialMode={authMode}
            onSuccess={handleAuthSuccess}
            onCancel={() => handleNavigate('landing')}
          />
        );

      case 'dashboard':
        return currentUser ? (
          <Dashboard
            currentUser={currentUser}
            campaigns={campaigns}
            onStartCampaign={handleStartCampaign}
            onOpenWallet={() => handleNavigate('wallet')}
            onViewAllCampaigns={() => handleNavigate('orders')}
          />
        ) : (
          <AuthPage
            initialMode="login"
            onSuccess={handleAuthSuccess}
            onCancel={() => handleNavigate('landing')}
          />
        );

      case 'new-order':
      case 'boost':
        return currentUser ? (
          <CampaignWizard
            currentUser={currentUser}
            initialGoal={wizardPreselectedGoal}
            initialPlatform={wizardPreselectedPlatform}
            onCampaignCreated={handleCampaignCreated}
            onCancel={() => handleNavigate('dashboard')}
          />
        ) : (
          <AuthPage
            initialMode="login"
            onSuccess={handleAuthSuccess}
            onCancel={() => handleNavigate('landing')}
          />
        );

      case 'orders':
      case 'campaigns':
        return currentUser ? (
          <CampaignManagement
            currentUser={currentUser}
            campaigns={campaigns}
            onStartNewCampaign={() => handleStartCampaign()}
            onCampaignsUpdated={refreshData}
          />
        ) : (
          <AuthPage
            initialMode="login"
            onSuccess={handleAuthSuccess}
            onCancel={() => handleNavigate('landing')}
          />
        );

      case 'wallet':
        return currentUser ? (
          <WalletPage
            currentUser={currentUser}
            transactions={transactions}
            onBalanceUpdated={(updated) => {
              setCurrentUserState(updated);
              refreshData();
            }}
            onNavigateToCampaigns={() => handleNavigate('orders')}
          />
        ) : (
          <AuthPage
            initialMode="login"
            onSuccess={handleAuthSuccess}
            onCancel={() => handleNavigate('landing')}
          />
        );

      case 'profile':
        return currentUser ? (
          <ProfilePage
            currentUser={currentUser}
            onUserUpdated={(updated) => {
              setCurrentUserState(updated);
              refreshData();
            }}
          />
        ) : (
          <AuthPage
            initialMode="login"
            onSuccess={handleAuthSuccess}
            onCancel={() => handleNavigate('landing')}
          />
        );

      case 'admin':
        if (!currentUser) {
          return (
            <AuthPage
              initialMode="login"
              onSuccess={handleAuthSuccess}
              onCancel={() => handleNavigate('landing')}
            />
          );
        }
        if (currentUser.role !== 'admin') {
          return (
            <Dashboard
              currentUser={currentUser}
              campaigns={campaigns}
              onStartCampaign={handleStartCampaign}
              onOpenWallet={() => handleNavigate('wallet')}
              onViewAllCampaigns={() => handleNavigate('orders')}
            />
          );
        }
        return (
          <AdminPanel
            currentUser={currentUser}
            allUsers={allUsers}
            allCampaigns={campaigns}
            allTransactions={transactions}
            onDataUpdated={refreshData}
          />
        );

      default:
        return (
          <LandingPage
            currentUser={currentUser}
            onGetStarted={() => {
              if (currentUser) {
                handleNavigate('dashboard');
              } else {
                handleOpenAuth('register');
              }
            }}
            onLogin={() => handleOpenAuth('login')}
            onSelectPlatformBoost={(plat) => handleStartCampaign('content_reach', plat)}
          />
        );
    }
  }
}
