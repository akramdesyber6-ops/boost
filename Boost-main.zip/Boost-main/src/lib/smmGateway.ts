export * from '../../api/_lib/smmGateway';
