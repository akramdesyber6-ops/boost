import { initializeApp, getApps, getApp } from 'firebase/app';
import { getDatabase, ref, set, get, update, remove, onValue, off, DatabaseReference } from 'firebase/database';
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut, onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { getAnalytics, isSupported } from 'firebase/analytics';
import { User, Campaign, Transaction, NotificationItem } from '../types';

// Web app's Firebase configuration provided by user
export const firebaseConfig = {
  apiKey: "AIzaSyCxkDVIZF7raiIJoA6tPJt9V_1_2UiiyA0",
  authDomain: "schoolos-36793.firebaseapp.com",
  databaseURL: "https://schoolos-36793-default-rtdb.firebaseio.com",
  projectId: "schoolos-36793",
  storageBucket: "schoolos-36793.firebasestorage.app",
  messagingSenderId: "482644732779",
  appId: "1:482644732779:web:18bd75cfbce025c058ba2e",
  measurementId: "G-GRBYXCRH4C"
};

// Initialize Firebase App
export const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

// Firebase Realtime Database
export const rtdb = getDatabase(app);

// Firebase Auth
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

// Safe Analytics (Client-side browser only)
if (typeof window !== 'undefined') {
  isSupported().then((supported) => {
    if (supported) {
      try {
        getAnalytics(app);
      } catch (err) {
        console.warn('Analytics initialization skipped:', err);
      }
    }
  }).catch(() => {});
}

// RTDB References under dedicated namespace 'vyro'
const VYRO_USERS_REF = 'vyro/users';
const VYRO_CAMPAIGNS_REF = 'vyro/campaigns';
const VYRO_TRANSACTIONS_REF = 'vyro/transactions';
const VYRO_NOTIFICATIONS_REF = 'vyro/notifications';

/**
 * Purge legacy mock seed items from Firebase Realtime Database
 */
export async function purgeLegacyMockDataFromFirebase(): Promise<void> {
  try {
    const mockUserIds = ['user_1', 'admin_1'];
    const mockCampaignIds = ['cmp_101', 'cmp_102', 'cmp_103', 'cmp_104'];
    const mockTxnIds = ['txn_901', 'txn_902', 'txn_903', 'txn_904', 'txn_905'];
    const mockNotifIds = ['notif_1', 'notif_2', 'notif_3'];

    for (const uid of mockUserIds) {
      await remove(ref(rtdb, `${VYRO_USERS_REF}/${uid}`)).catch(() => {});
    }
    for (const cid of mockCampaignIds) {
      await remove(ref(rtdb, `${VYRO_CAMPAIGNS_REF}/${cid}`)).catch(() => {});
    }
    for (const tid of mockTxnIds) {
      await remove(ref(rtdb, `${VYRO_TRANSACTIONS_REF}/${tid}`)).catch(() => {});
    }
    for (const nid of mockNotifIds) {
      await remove(ref(rtdb, `${VYRO_NOTIFICATIONS_REF}/${nid}`)).catch(() => {});
    }
  } catch (error) {
    console.warn('Firebase RTDB mock cleanup notice:', error);
  }
}

/**
 * Realtime listener for Campaigns
 */
export function subscribeToRealtimeCampaigns(callback: (campaigns: Campaign[]) => void): () => void {
  const campRef = ref(rtdb, VYRO_CAMPAIGNS_REF);
  const unsubscribe = onValue(campRef, (snapshot) => {
    if (snapshot.exists()) {
      const val = snapshot.val();
      const list: Campaign[] = Object.values(val);
      // Sort newest first
      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      callback(list);
    } else {
      callback([]);
    }
  }, (error) => {
    console.warn('RTDB Campaigns subscription error:', error);
  });

  return () => off(campRef, 'value', unsubscribe);
}

/**
 * Realtime listener for Users
 */
export function subscribeToRealtimeUsers(callback: (users: User[]) => void): () => void {
  const usersRef = ref(rtdb, VYRO_USERS_REF);
  const unsubscribe = onValue(usersRef, (snapshot) => {
    if (snapshot.exists()) {
      const val = snapshot.val();
      const list: User[] = Object.values(val);
      callback(list);
    } else {
      callback([]);
    }
  }, (error) => {
    console.warn('RTDB Users subscription error:', error);
  });

  return () => off(usersRef, 'value', unsubscribe);
}

/**
 * Realtime listener for Transactions
 */
export function subscribeToRealtimeTransactions(callback: (txns: Transaction[]) => void): () => void {
  const txnsRef = ref(rtdb, VYRO_TRANSACTIONS_REF);
  const unsubscribe = onValue(txnsRef, (snapshot) => {
    if (snapshot.exists()) {
      const val = snapshot.val();
      const list: Transaction[] = Object.values(val);
      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      callback(list);
    } else {
      callback([]);
    }
  }, (error) => {
    console.warn('RTDB Transactions subscription error:', error);
  });

  return () => off(txnsRef, 'value', unsubscribe);
}

/**
 * Realtime listener for Notifications
 */
export function subscribeToRealtimeNotifications(callback: (notifs: NotificationItem[]) => void): () => void {
  const notifsRef = ref(rtdb, VYRO_NOTIFICATIONS_REF);
  const unsubscribe = onValue(notifsRef, (snapshot) => {
    if (snapshot.exists()) {
      const val = snapshot.val();
      const list: NotificationItem[] = Object.values(val);
      list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      callback(list);
    } else {
      callback([]);
    }
  }, (error) => {
    console.warn('RTDB Notifications subscription error:', error);
  });

  return () => off(notifsRef, 'value', unsubscribe);
}

/**
 * Realtime connection status listener
 */
export function subscribeToConnectionStatus(callback: (connected: boolean) => void): () => void {
  const connectedRef = ref(rtdb, '.info/connected');
  const unsubscribe = onValue(connectedRef, (snap) => {
    callback(Boolean(snap.val()));
  });
  return () => off(connectedRef, 'value', unsubscribe);
}

/**
 * Save/Update Campaign in Realtime Database
 */
export async function dbSaveCampaign(campaign: Campaign): Promise<void> {
  try {
    const itemRef = ref(rtdb, `${VYRO_CAMPAIGNS_REF}/${campaign.id}`);
    await set(itemRef, campaign);
  } catch (error) {
    console.warn('Failed to save campaign to Firebase RTDB:', error);
  }
}

/**
 * Delete Campaign from Realtime Database
 */
export async function dbDeleteCampaign(campaignId: string): Promise<void> {
  try {
    const itemRef = ref(rtdb, `${VYRO_CAMPAIGNS_REF}/${campaignId}`);
    await remove(itemRef);
  } catch (error) {
    console.warn('Failed to delete campaign from Firebase RTDB:', error);
  }
}

/**
 * Save/Update User in Realtime Database
 */
export async function dbSaveUser(user: User): Promise<void> {
  try {
    const userRef = ref(rtdb, `${VYRO_USERS_REF}/${user.id}`);
    await set(userRef, user);
  } catch (error) {
    console.warn('Failed to save user to Firebase RTDB:', error);
  }
}

/**
 * Save/Add Transaction in Realtime Database
 */
export async function dbSaveTransaction(txn: Transaction): Promise<void> {
  try {
    const txnRef = ref(rtdb, `${VYRO_TRANSACTIONS_REF}/${txn.id}`);
    await set(txnRef, txn);
  } catch (error) {
    console.warn('Failed to save transaction to Firebase RTDB:', error);
  }
}

/**
 * Update transaction status by providerReference in Realtime Database
 */
export async function dbUpdateTransactionStatus(
  reference: string,
  status: 'completed' | 'failed',
  creditedAmount?: number
): Promise<void> {
  try {
    const txnsSnap = await get(ref(rtdb, VYRO_TRANSACTIONS_REF));
    if (txnsSnap.exists()) {
      const allTxns: Record<string, Transaction> = txnsSnap.val();
      for (const [id, txn] of Object.entries(allTxns)) {
        if (txn.providerReference === reference) {
          const updates: Record<string, any> = {
            status,
            updatedAt: new Date().toISOString(),
          };
          if (creditedAmount) {
            updates.amountUGX = creditedAmount;
          }
          if (status === 'completed') {
            updates.creditedAt = new Date().toISOString();
          }
          await update(ref(rtdb, `${VYRO_TRANSACTIONS_REF}/${id}`), updates);
          break;
        }
      }
    }
  } catch (error) {
    console.warn('Failed to update transaction status in Firebase RTDB:', error);
  }
}

/**
 * Save/Add Notification in Realtime Database
 */
export async function dbSaveNotification(notif: NotificationItem): Promise<void> {
  try {
    const notifRef = ref(rtdb, `${VYRO_NOTIFICATIONS_REF}/${notif.id}`);
    await set(notifRef, notif);
  } catch (error) {
    console.warn('Failed to save notification to Firebase RTDB:', error);
  }
}

/**
 * Mark all notifications as read for a given user in Realtime Database
 */
export async function dbMarkAllNotificationsRead(userId: string): Promise<void> {
  try {
    const notifsSnap = await get(ref(rtdb, VYRO_NOTIFICATIONS_REF));
    if (notifsSnap.exists()) {
      const allNotifs: Record<string, NotificationItem> = notifsSnap.val();
      const updates: Record<string, any> = {};
      Object.entries(allNotifs).forEach(([id, notif]) => {
        if (notif.userId === userId && !notif.read) {
          updates[`${VYRO_NOTIFICATIONS_REF}/${id}/read`] = true;
        }
      });
      if (Object.keys(updates).length > 0) {
        await update(ref(rtdb), updates);
      }
    }
  } catch (error) {
    console.warn('Failed to mark notifications read in Firebase RTDB:', error);
  }
}
