import { User, Campaign, Transaction, NotificationItem, ServiceDefinition } from '../types';
import { 
  dbSaveCampaign, 
  dbDeleteCampaign, 
  dbSaveUser, 
  dbSaveTransaction, 
  dbUpdateTransactionStatus,
  dbSaveNotification, 
  dbMarkAllNotificationsRead,
  purgeLegacyMockDataFromFirebase
} from './firebase';

const USERS_KEY = 'vyro_users';
const CURRENT_USER_KEY = 'vyro_current_user_id';
const CAMPAIGNS_KEY = 'vyro_campaigns';
const TRANSACTIONS_KEY = 'vyro_transactions';
const NOTIFICATIONS_KEY = 'vyro_notifications';
const THEME_KEY = 'vyro_theme_mode';

export const SERVICES: ServiceDefinition[] = [
  {
    id: 'srv_tiktok_reach',
    name: 'TikTok Video Reach & Discovery',
    platform: 'tiktok',
    description: 'Reach authentic TikTok users interested in your content niche with native sponsored placement.',
    minBudgetUGX: 5000,
    ratePer1kImpressionsUGX: 850,
    active: true,
    category: 'views',
  },
  {
    id: 'srv_ig_reach',
    name: 'Instagram Profile & Reel Reach',
    platform: 'instagram',
    description: 'Promote Reels, Carousels, and stories to real active profiles across chosen target demographics.',
    minBudgetUGX: 10000,
    ratePer1kImpressionsUGX: 950,
    active: true,
    category: 'followers',
  },
  {
    id: 'srv_yt_views',
    name: 'YouTube Video & Shorts Promotion',
    platform: 'youtube',
    description: 'Get your long-form videos and Shorts in front of engaged high-intent viewers through native ads.',
    minBudgetUGX: 10000,
    ratePer1kImpressionsUGX: 1100,
    active: true,
    category: 'views',
  },
  {
    id: 'srv_x_engagement',
    name: 'X (Twitter) Feed Amplification',
    platform: 'x',
    description: 'Boost discussions, threads, links, and profile visibility across relevant hashtags and trends.',
    minBudgetUGX: 5000,
    ratePer1kImpressionsUGX: 900,
    active: true,
    category: 'likes',
  },
  {
    id: 'srv_fb_audience',
    name: 'Facebook Page & Post Boost',
    platform: 'facebook',
    description: 'Connect with local and regional community members, customers, and followers for real engagement.',
    minBudgetUGX: 5000,
    ratePer1kImpressionsUGX: 800,
    active: true,
    category: 'comments',
  },
];

/**
 * Cleanse any legacy mock records from browser localStorage
 */
export function purgeLegacyMockLocalStorage(): void {
  try {
    const rawUsers = localStorage.getItem(USERS_KEY);
    if (rawUsers) {
      const parsed: User[] = JSON.parse(rawUsers);
      const filtered = parsed.filter((u) => u.id !== 'user_1' && u.id !== 'admin_1');
      localStorage.setItem(USERS_KEY, JSON.stringify(filtered));
    }

    const currentId = localStorage.getItem(CURRENT_USER_KEY);
    if (currentId === 'user_1' || currentId === 'admin_1') {
      localStorage.removeItem(CURRENT_USER_KEY);
    }
    const legacyId = localStorage.getItem('boosta_current_user_id');
    if (legacyId === 'user_1' || legacyId === 'admin_1') {
      localStorage.removeItem('boosta_current_user_id');
    }

    const rawCamps = localStorage.getItem(CAMPAIGNS_KEY);
    if (rawCamps) {
      const parsed: Campaign[] = JSON.parse(rawCamps);
      const filtered = parsed.filter((c) => !c.id.startsWith('cmp_10'));
      localStorage.setItem(CAMPAIGNS_KEY, JSON.stringify(filtered));
    }

    const rawTxns = localStorage.getItem(TRANSACTIONS_KEY);
    if (rawTxns) {
      const parsed: Transaction[] = JSON.parse(rawTxns);
      const filtered = parsed.filter((t) => !t.id.startsWith('txn_90'));
      localStorage.setItem(TRANSACTIONS_KEY, JSON.stringify(filtered));
    }

    const rawNotifs = localStorage.getItem(NOTIFICATIONS_KEY);
    if (rawNotifs) {
      const parsed: NotificationItem[] = JSON.parse(rawNotifs);
      const filtered = parsed.filter((n) => n.id !== 'notif_1' && n.id !== 'notif_2' && n.id !== 'notif_3');
      localStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify(filtered));
    }
  } catch (err) {
    console.warn('Mock localStorage cleansing warning:', err);
  }
}

export function getStoredTheme(): 'light' {
  return 'light';
}

export function setStoredTheme(_mode?: 'light' | 'dark'): void {
  try {
    localStorage.removeItem(THEME_KEY);
    if (typeof document !== 'undefined') {
      document.documentElement.classList.remove('dark');
    }
  } catch {}
}

export function getStoredUsers(): User[] {
  try {
    const raw = localStorage.getItem(USERS_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function getCurrentUser(): User | null {
  purgeLegacyMockLocalStorage();
  const users = getStoredUsers();
  try {
    let currentId = localStorage.getItem(CURRENT_USER_KEY);
    if (!currentId) {
      currentId = localStorage.getItem('boosta_current_user_id');
    }
    if (currentId) {
      const found = users.find((u) => u.id === currentId);
      if (found) return found;
    }
  } catch {}
  return null;
}

export function setCurrentUser(userId: string): User | null {
  const users = getStoredUsers();
  const found = users.find((u) => u.id === userId);
  if (found) {
    try {
      localStorage.setItem(CURRENT_USER_KEY, found.id);
    } catch {}
    return found;
  }
  return null;
}

export function updateUser(updatedUser: User): void {
  const users = getStoredUsers();
  const index = users.findIndex((u) => u.id === updatedUser.id);
  if (index !== -1) {
    users[index] = updatedUser;
  } else {
    users.push(updatedUser);
  }
  try {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  } catch {}
  // Sync to Firebase Realtime Database
  dbSaveUser(updatedUser);
}

export function setStoredUsers(users: User[]): void {
  try {
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
  } catch {}
}

export function getStoredCampaigns(): Campaign[] {
  try {
    const raw = localStorage.getItem(CAMPAIGNS_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function setStoredCampaigns(campaigns: Campaign[]): void {
  try {
    localStorage.setItem(CAMPAIGNS_KEY, JSON.stringify(campaigns));
  } catch {}
}

export function saveCampaign(campaign: Campaign): void {
  const campaigns = getStoredCampaigns();
  const existingIndex = campaigns.findIndex((c) => c.id === campaign.id);
  if (existingIndex >= 0) {
    campaigns[existingIndex] = campaign;
  } else {
    campaigns.unshift(campaign);
  }
  try {
    localStorage.setItem(CAMPAIGNS_KEY, JSON.stringify(campaigns));
  } catch {}
  // Sync to Firebase Realtime Database
  dbSaveCampaign(campaign);
}

export function deleteCampaign(campaignId: string): void {
  const campaigns = getStoredCampaigns().filter((c) => c.id !== campaignId);
  try {
    localStorage.setItem(CAMPAIGNS_KEY, JSON.stringify(campaigns));
  } catch {}
  // Sync to Firebase Realtime Database
  dbDeleteCampaign(campaignId);
}

export function getStoredTransactions(): Transaction[] {
  try {
    const raw = localStorage.getItem(TRANSACTIONS_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function setStoredTransactions(transactions: Transaction[]): void {
  try {
    localStorage.setItem(TRANSACTIONS_KEY, JSON.stringify(transactions));
  } catch {}
}

export function addTransaction(transaction: Transaction): void {
  const txns = getStoredTransactions();
  txns.unshift(transaction);
  try {
    localStorage.setItem(TRANSACTIONS_KEY, JSON.stringify(txns));
  } catch {}
  // Sync to Firebase Realtime Database
  dbSaveTransaction(transaction);
}

export function updateTransactionStatus(
  reference: string,
  status: 'completed' | 'failed',
  creditedAmount?: number
): void {
  const txns = getStoredTransactions();
  let found = false;
  const updated = txns.map((t) => {
    if (t.providerReference === reference) {
      found = true;
      return {
        ...t,
        status,
        ...(creditedAmount ? { amountUGX: creditedAmount } : {}),
      };
    }
    return t;
  });

  if (found) {
    try {
      localStorage.setItem(TRANSACTIONS_KEY, JSON.stringify(updated));
    } catch {}
  }
  // Sync to Firebase Realtime Database
  dbUpdateTransactionStatus(reference, status, creditedAmount);
}

export function getStoredNotifications(): NotificationItem[] {
  try {
    const raw = localStorage.getItem(NOTIFICATIONS_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

export function setStoredNotifications(notifications: NotificationItem[]): void {
  try {
    localStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify(notifications));
  } catch {}
}

export function addNotification(notif: NotificationItem): void {
  const notifs = getStoredNotifications();
  notifs.unshift(notif);
  try {
    localStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify(notifs));
  } catch {}
  // Sync to Firebase Realtime Database
  dbSaveNotification(notif);
}

export function markAllNotificationsRead(userId: string): void {
  const notifs = getStoredNotifications();
  const updated = notifs.map((n) => (n.userId === userId ? { ...n, read: true } : n));
  try {
    localStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify(updated));
  } catch {}
  // Sync to Firebase Realtime Database
  dbMarkAllNotificationsRead(userId);
}

export function clearCurrentUser(): void {
  try {
    localStorage.removeItem(CURRENT_USER_KEY);
    localStorage.removeItem('boosta_current_user_id');
  } catch {}
}

/**
 * Purge mock data from both local storage and Firebase Realtime Database
 */
export async function cleanupMockData(): Promise<void> {
  purgeLegacyMockLocalStorage();
  await purgeLegacyMockDataFromFirebase();
}

