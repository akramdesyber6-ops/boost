async function run() {
  const url = 'https://wallet.wearemarz.com/api/v1/collect-money';
  const reqBody = {
    amount: 1000,
    phone_number: "+256772123456",
    country: "UG",
    currency: "UGX",
    reference: "4a2b6e15-8178-4389-9a25-a4b51a89c450",
    description: "Deposit UGX 1,000 to VYRO Wallet",
    callback_url: "https://vyroboost.vercel.app/api/webhooks/marzpay"
  };
  
  const headers = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    // Mock credentials to just see the schema response, it should be 401
    'Authorization': 'Basic ' + Buffer.from('pk_test_123:sk_test_123').toString('base64'),
    'x-api-key': 'pk_test_123',
    'x-api-secret': 'sk_test_123'
  };

  const res = await fetch(url, { method: 'POST', headers, body: JSON.stringify(reqBody) });
  const text = await res.text();
  console.log(`STATUS: ${res.status}`);
  console.log(`BODY: ${text}`);
}
run();
